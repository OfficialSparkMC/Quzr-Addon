package com.macekill.addon.modules.macekill;

import net.minecraft.class_1297;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2868;
import net.minecraft.class_310;

public final class Movement {
    private Movement() {}

    public static void doTpTo(class_310 mc, class_243 to, double moveDistance, boolean kehd) {
        class_243 from = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        double dist = from.method_1022(to);
        int steps = (int) Math.ceil(dist / moveDistance);
        for (int i = 1; i <= steps; i++) {
            sendMovePacket(mc, from.field_1352, from.field_1351, from.field_1350);
        }
        sendMovePacket(mc, to.field_1352, to.field_1351, to.field_1350);
        if (kehd) {
            mc.field_1724.method_30634(to.field_1352, to.field_1351, to.field_1350);
        }
    }

    public static void sendMovePacket(class_310 mc, double x, double y, double z) {
        if (mc.method_1562() == null) return;
        mc.method_1562().method_52787(new class_2828.class_2829(x, y, z, false, false));
    }

    public static void sendRotations(class_310 mc, int count) {
        if (mc.method_1562() == null) return;
        for (int i = 0; i < count; i++) {
            mc.method_1562().method_52787(new class_2828.class_2831(
                mc.field_1724.method_36454(), mc.field_1724.method_36455(), mc.field_1724.method_24828(), false));
        }
    }

    public static void sendSlotPacket(class_310 mc, int slot) {
        if (mc.method_1562() == null) return;
        mc.method_1562().method_52787(new class_2868(slot));
    }

    public static void attackEntity(class_310 mc, class_1297 target) {
        if (mc.method_1562() == null) return;
        mc.method_1562().method_52787(class_2824.method_34206(target, mc.field_1724.method_5715()));
    }
}
