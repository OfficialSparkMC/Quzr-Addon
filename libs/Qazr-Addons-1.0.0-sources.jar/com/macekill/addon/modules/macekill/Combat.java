package com.macekill.addon.modules.macekill;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_310;

public final class Combat {
    private Combat() {}

    public static boolean executeAttack(class_310 mc, Config config,
                                        class_1309 target, class_243 targetPos) {
        if (target == null || mc.method_1562() == null) {
            return true;
        }

        List<String> rawHeights;
        boolean armorDestroyed;
        if (config.enableArmorDestroy() && needsArmorDestroy(target, config.ignoreArmorValue())) {
            rawHeights = config.destroyHeights();
            armorDestroyed = false;
        } else {
            rawHeights = config.killHeights();
            armorDestroyed = true;
        }

        List<Double> heights = parseHeights(rawHeights);
        if (heights.isEmpty()) {
            heights.add(20.0);
        }

        int oldSlot = Inventory.switchToMace(mc);
        if (oldSlot == -1) {
            return armorDestroyed;
        }

        try {
            class_243 basePos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());

            for (double h : heights) {
                class_2338 vclipHole = findVclipHole(mc,
                    mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), h);
                class_243 vclipPos = class_243.method_24955(vclipHole);

                Movement.doTpTo(mc, vclipPos, config.moveDistance(), config.kehd());
                Movement.sendMovePacket(mc, targetPos.field_1352, targetPos.field_1351 + 0.5, targetPos.field_1350);
                Movement.sendMovePacket(mc, basePos.field_1352, basePos.field_1351, basePos.field_1350);

                if (config.swingHand()) {
                    mc.field_1724.method_6104(class_1268.field_5808);
                }
                Movement.attackEntity(mc, target);
            }
        } finally {
            if (config.autoTotem()) {
                int totemSlot = Inventory.findTotemSlot(mc);
                if (totemSlot != -1) {
                    Inventory.setSelectedSlot(mc.field_1724.method_31548(), totemSlot);
                    Movement.sendSlotPacket(mc, totemSlot);
                } else {
                    Inventory.switchBack(mc, oldSlot);
                }
            } else {
                Inventory.switchBack(mc, oldSlot);
            }
        }
        return armorDestroyed;
    }

    public static class_2338 findVclipHole(class_310 mc,
                                         double x, double y, double z, double vclip) {
        class_2338 base = class_2338.method_49637(x, y, z);
        if (vclip <= 0.0) {
            return base;
        }

        int bx = base.method_10263();
        int by = base.method_10264();
        int bz = base.method_10260();
        int targetY = by + (int) vclip;
        class_2338.class_2339 mutable = new class_2338.class_2339();

        for (int cy = targetY; cy >= by; cy--) {
            mutable.method_10103(bx, cy, bz);
            if (!Targeting.isSafeBlock(mc, mutable)) continue;
            mutable.method_10103(bx, cy + 1, bz);
            if (!Targeting.isSafeBlock(mc, mutable)) continue;
            return new class_2338(bx, cy, bz);
        }
        return base;
    }

    public static boolean needsArmorDestroy(class_1309 entity, int ignoreArmorValue) {
        if (!(entity instanceof class_1657 player)) {
            return false;
        }
        int count = 0;
        for (int i = 36; i <= 39; i++) {
            if (player.method_31548().method_5438(i).method_7960()) continue;
            count++;
        }
        return count > ignoreArmorValue;
    }

    public static List<Double> parseHeights(List<String> raw) {
        List<Double> list = new ArrayList<>();
        for (String s : raw) {
            try {
                double v = Double.parseDouble(s.trim());
                if (v > 0.0) {
                    list.add(v);
                }
            } catch (NumberFormatException ignored) {
            }
        }
        return list;
    }
}
