package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import com.macekill.addon.utils.CreativeGiveUtil;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_124;
import net.minecraft.class_1320;
import net.minecraft.class_1322;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1887;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_5250;
import net.minecraft.class_5251;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_9274;
import net.minecraft.class_9285;
import net.minecraft.class_9304;
import net.minecraft.class_9334;
import java.util.List;
import java.util.Optional;

/**
 * 创造模式物品生成器 (通用物品, 药水已移至 CustomPotionModule)
 * 使用 Meteor StringListSetting 管理附魔和属性
 * 附魔和属性条目支持任意多个（无硬编码上限）
 * 附魔等级范围: 0 ~ Long.MAX_VALUE (64位)
 */
public class CreativeGiveModule extends Module {
    private final class_310 mc = class_310.method_1551();

    public CreativeGiveModule() {
        super(MaceKillAddon.CATEGORY, "物品生成器",
            "创造模式通用物品生成 - 类型化组件\n" +
            "附魔列表格式: 附魔ID:等级 (如 minecraft:sharpness:10)\n" +
            "属性列表格式: 属性ID|值|槽位 (如 generic.attack_damage|1000|MAINHAND)\n" +
            "槽位: MAINHAND, OFFHAND, HAND, HEAD, CHEST, LEGS, FEET, ARMOR, ANY\n" +
            "提示: 药水请使用「药水生成器」模块");
    }

    public enum Preset {
        NONE, DAMAGE_SWORD, DAMAGE_ARMOR, TOTEM
    }

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Preset> preset = sg.add(new EnumSetting.Builder<Preset>()
        .name("快捷预设").defaultValue(Preset.NONE).build()
    );

    private final Setting<String> itemId = sg.add(new StringSetting.Builder()
        .name("物品ID").defaultValue("minecraft:diamond_sword").build()
    );

    private final Setting<Integer> count = sg.add(new IntSetting.Builder()
        .name("数量").defaultValue(1).min(1).max(64).sliderMax(64).build()
    );

    private final Setting<Boolean> enableName = sg.add(new BoolSetting.Builder()
        .name("自定义名称").defaultValue(false).build()
    );

    private final Setting<String> customName = sg.add(new StringSetting.Builder()
        .name("名称文本")
        .description("支持颜色代码: 输入 &6金色 &c红色 &a绿色 &b浅蓝 &9蓝 &d粉 &e黄 &f白 &0黑 等\n" +
                     "& 加一个字母 = 颜色, &l=粗体 &o=斜体 &n=下划线 &m=删除线 &k=混淆\n" +
                     "示例: &6&lQazr1234 &c&l神剑")
        .defaultValue("&6&lQazr1234 &c&l测试剑").build()
    );

    private final Setting<List<String>> enchantments = sg.add(new StringListSetting.Builder()
        .name("附魔列表")
        .description("每行一个，格式: 附魔ID:等级 (附魔ID可省略 minecraft: 前缀, 等级支持任意64位整数)")
        .defaultValue(List.of("minecraft:sharpness:10"))
        .build()
    );

    private final Setting<List<String>> attributes = sg.add(new StringListSetting.Builder()
        .name("属性列表")
        .description("每行一个，格式: 属性ID|值|槽位\n" +
                     "属性ID可省略 minecraft: 前缀\n" +
                     "槽位: MAINHAND, OFFHAND, HAND, HEAD, CHEST, LEGS, FEET, ARMOR, ANY")
        .defaultValue(List.of("generic.attack_damage|1000|MAINHAND"))
        .build()
    );

    private final Setting<Boolean> continuous = sg.add(new BoolSetting.Builder()
        .name("连续生成").defaultValue(false).build()
    );

    @Override
    public void onActivate() {
        if (mc.field_1724 == null || mc.field_1687 == null) { toggle(); return; }
        if (!mc.field_1724.method_31549().field_7477) {
            CreativeGiveUtil.warn("需要创造模式!"); toggle(); return;
        }
        CreativeGiveUtil.resetError();
        generateAndGive();
        if (!continuous.get()) toggle();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (!continuous.get() || mc.field_1724 == null) return;
        if (!mc.field_1724.method_31549().field_7477) { toggle(); return; }
        generateAndGive();
    }

    private void generateAndGive() {
        Preset p = preset.get();
        if (p != Preset.NONE) { genPreset(p); return; }

        class_1792 item = resolveItem(itemId.get());
        if (item == class_1802.field_8162) { CreativeGiveUtil.warn("未找到物品: " + itemId.get()); return; }

        class_1799 stack = new class_1799(item, count.get());

        if (enableName.get()) {
            stack.method_57379(class_9334.field_49631, parseName(customName.get()));
        }

        for (String entry : enchantments.get()) {
            applyEnchantFromString(stack, entry);
        }
        for (String entry : attributes.get()) {
            applyAttrFromString(stack, entry);
        }

        if (CreativeGiveUtil.give(stack)) {
            CreativeGiveUtil.info("已生成 " + stack.method_7947() + "x " + itemId.get());
        }
    }

    /** 解析 & 或 § 颜色代码为带样式的 Text (italic=false 确保显示) */
    private class_2561 parseName(String raw) {
        if (raw == null || raw.isEmpty()) return class_2561.method_43470("");
        class_5250 out = class_2561.method_43473();
        StringBuilder buf = new StringBuilder();
        net.minecraft.class_2583 curStyle = net.minecraft.class_2583.field_24360.method_10978(false);
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            // 同时支持 & 和 § 作为颜色前缀
            if ((c == '&' || c == '§') && i + 1 < raw.length()) {
                if (buf.length() > 0) {
                    out.method_10852(class_2561.method_43470(buf.toString()).method_10862(curStyle));
                    buf.setLength(0);
                }
                char code = Character.toLowerCase(raw.charAt(++i));
                class_124 f = class_124.method_544(code);
                if (f != null) {
                    if (f == class_124.field_1067) curStyle = curStyle.method_10982(!curStyle.method_10984());
                    else if (f == class_124.field_1056) curStyle = curStyle.method_10978(!curStyle.method_10966());
                    else if (f == class_124.field_1073) curStyle = curStyle.method_30938(!curStyle.method_10965());
                    else if (f == class_124.field_1055) curStyle = curStyle.method_36140(!curStyle.method_10986());
                    else if (f == class_124.field_1051) curStyle = curStyle.method_36141(!curStyle.method_10987());
                    else if (f.method_543()) curStyle = curStyle.method_27703(class_5251.method_27718(f));
                }
            } else {
                buf.append(c);
            }
        }
        if (buf.length() > 0) {
            out.method_10852(class_2561.method_43470(buf.toString()).method_10862(curStyle));
        }
        return out;
    }

    /* ==================== 附魔 (格式: id:level) ==================== */
    private void applyEnchantFromString(class_1799 stack, String entry) {
        if (entry == null) return;
        String s = entry.trim();
        if (s.isEmpty()) return;
        int idx = s.lastIndexOf(':');
        if (idx <= 0) { CreativeGiveUtil.warn("附魔格式错误: " + s + " (应为 id:level)"); return; }
        String id = s.substring(0, idx);
        String levelStr = s.substring(idx + 1);
        long level;
        try { level = Long.parseLong(levelStr.trim()); }
        catch (Exception e) { CreativeGiveUtil.warn("附魔等级解析错误: " + levelStr); return; }

        try {
            class_2960 enchId = class_2960.method_12829(id.contains(":") ? id : "minecraft:" + id);
            if (enchId == null) { CreativeGiveUtil.warn("附魔ID错误: " + id); return; }
            Optional<class_6880.class_6883<class_1887>> ref = enchantmentRegistry().method_10223(enchId);
            if (ref.isEmpty()) { CreativeGiveUtil.warn("附魔未找到: " + id); return; }

            int safeLevel = (int) Math.min(level, Integer.MAX_VALUE);
            class_9304 current = stack.method_58695(
                class_9334.field_49633, class_9304.field_49385);
            class_9304.class_9305 builder = new class_9304.class_9305(current);
            builder.method_57550(ref.get(), safeLevel);
            stack.method_57379(class_9334.field_49633, builder.method_57549());
        } catch (Exception e) {
            CreativeGiveUtil.warn("附魔失败 [" + id + "]: " + e.getMessage());
        }
    }

    /* ==================== 属性 (格式: id|amount|slot) ==================== */
    private void applyAttrFromString(class_1799 stack, String entry) {
        if (entry == null) return;
        String s = entry.trim();
        if (s.isEmpty()) return;
        String[] parts = s.split("\\|");
        if (parts.length < 2) { CreativeGiveUtil.warn("属性格式错误: " + s + " (应为 id|值|槽位)"); return; }
        String id = parts[0].trim();
        String amountStr = parts[1].trim();
        String slotStr = parts.length >= 3 ? parts[2].trim().toUpperCase() : "ANY";
        double amount;
        try { amount = Double.parseDouble(amountStr); }
        catch (Exception e) { CreativeGiveUtil.warn("属性值解析错误: " + amountStr); return; }

        try {
            class_2960 attrId = class_2960.method_12829(id.contains(":") ? id : "minecraft:" + id);
            if (attrId == null) { CreativeGiveUtil.warn("属性ID错误: " + id); return; }
            Optional<class_6880.class_6883<class_1320>> ref = attributeRegistry().method_10223(attrId);
            if (ref.isEmpty()) { CreativeGiveUtil.warn("属性未找到: " + id); return; }

            class_1322 modifier = new class_1322(
                class_2960.method_60655("qazr1234", "mod_" + System.nanoTime()),
                amount,
                class_1322.class_1323.field_6328
            );
            class_9274 slot = parseSlot(slotStr);
            class_9285 current = stack.method_58695(
                class_9334.field_49636, class_9285.field_49326);
            class_9285 updated = current.method_57484(ref.get(), modifier, slot);
            stack.method_57379(class_9334.field_49636, updated);
        } catch (Exception e) {
            CreativeGiveUtil.warn("属性失败 [" + id + "]: " + e.getMessage());
        }
    }

    private class_9274 parseSlot(String s) {
        try {
            return class_9274.valueOf(s);
        } catch (Exception e) {
            CreativeGiveUtil.warn("未知槽位: " + s + " (使用ANY)"); return class_9274.field_49216;
        }
    }

    @SuppressWarnings("unchecked")
    private class_2378<class_1887> enchantmentRegistry() {
        return (class_2378<class_1887>) (class_2378<?>) mc.field_1687.method_30349()
            .method_46759(class_7924.field_41265).orElseThrow();
    }

    @SuppressWarnings("unchecked")
    private class_2378<class_1320> attributeRegistry() {
        return (class_2378<class_1320>) (class_2378<?>) mc.field_1687.method_30349()
            .method_46759(class_7924.field_41251).orElseThrow();
    }

    /* ==================== 预设 ==================== */
    private void genPreset(Preset p) {
        switch (p) {
            case DAMAGE_SWORD -> genDamageSword();
            case DAMAGE_ARMOR -> genDamageArmor();
            case TOTEM -> genTotem();
        }
    }

    private void genDamageSword() {
        class_1799 stack = new class_1799(class_1802.field_22022, 1);
        stack.method_57379(class_9334.field_49631,
            class_2561.method_43470("Qazr1234 伤害神剑").method_27695(class_124.field_1054, class_124.field_1067));

        Optional<class_6880.class_6883<class_1320>> dmgAttr =
            attributeRegistry().method_10223(class_2960.method_60654("generic.attack_damage"));
        if (dmgAttr.isPresent()) {
            class_1322 mod = new class_1322(
                class_2960.method_60655("qazr1234", "dmg"), 137891.0,
                class_1322.class_1323.field_6328);
            class_9285 current = stack.method_58695(
                class_9334.field_49636, class_9285.field_49326);
            stack.method_57379(class_9334.field_49636,
                current.method_57484(dmgAttr.get(), mod, class_9274.field_49217));
        }
        if (CreativeGiveUtil.give(stack))
            CreativeGiveUtil.info("伤害神剑(137891)已生成");
    }

    private void genDamageArmor() {
        class_1792[] pieces = {class_1802.field_22027, class_1802.field_22028,
                         class_1802.field_22029, class_1802.field_22030};
        class_9274[] groups = {class_9274.field_49223, class_9274.field_49222,
                                          class_9274.field_49221, class_9274.field_49220};

        Optional<class_6880.class_6883<class_1320>> armor =
            attributeRegistry().method_10223(class_2960.method_60654("generic.armor"));
        Optional<class_6880.class_6883<class_1320>> toughness =
            attributeRegistry().method_10223(class_2960.method_60654("generic.armor_toughness"));
        Optional<class_6880.class_6883<class_1320>> kb =
            attributeRegistry().method_10223(class_2960.method_60654("generic.knockback_resistance"));

        for (int i = 0; i < pieces.length; i++) {
            class_1799 stack = new class_1799(pieces[i], 1);
            stack.method_57379(class_9334.field_49631,
                class_2561.method_43470("Qazr1234 伤害神甲").method_27695(class_124.field_1076, class_124.field_1067));
            class_9285 comp = stack.method_58695(
                class_9334.field_49636, class_9285.field_49326);
            if (armor.isPresent())
                comp = comp.method_57484(armor.get(),
                    new class_1322(class_2960.method_60655("qazr1234", "armor" + i), 137891.0,
                        class_1322.class_1323.field_6328), groups[i]);
            if (toughness.isPresent())
                comp = comp.method_57484(toughness.get(),
                    new class_1322(class_2960.method_60655("qazr1234", "tough" + i), 137891.0,
                        class_1322.class_1323.field_6328), groups[i]);
            if (kb.isPresent())
                comp = comp.method_57484(kb.get(),
                    new class_1322(class_2960.method_60655("qazr1234", "kb" + i), 1.0,
                        class_1322.class_1323.field_6328), groups[i]);
            stack.method_57379(class_9334.field_49636, comp);
            CreativeGiveUtil.give(stack);
        }
        CreativeGiveUtil.info("伤害神甲全套(137891)已生成");
    }

    private void genTotem() {
        class_1799 stack = new class_1799(class_1802.field_8288, 1);
        stack.method_57379(class_9334.field_49631,
            class_2561.method_43470("Qazr1234 不死图腾").method_27695(class_124.field_1065, class_124.field_1067));
        if (CreativeGiveUtil.give(stack))
            CreativeGiveUtil.info("不死图腾已生成");
    }

    /* ==================== 工具 ==================== */
    private class_1792 resolveItem(String id) {
        String fullId = id.contains(":") ? id : "minecraft:" + id;
        class_2960 identifier = class_2960.method_12829(fullId);
        return identifier != null ? class_7923.field_41178.method_63535(identifier) : class_1802.field_8162;
    }
}
