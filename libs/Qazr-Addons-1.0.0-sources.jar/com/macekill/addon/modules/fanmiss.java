package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2828;

/**
 * 防空刀 — 重锤反空刀，通过快速VClip闪烁防止服务器判定空刀
 */
public class fanmiss extends Module {

    // ==================== 设置 ====================
    private final SettingGroup sgMain = settings.getDefaultGroup();

    private final Setting<Double> detectRange = sgMain.add(new DoubleSetting.Builder()
            .name("范围").description("检测附近玩家的范围")
            .defaultValue(6).min(1).max(20).sliderRange(1, 20).build()
    );

    private final Setting<Double> riseHeight = sgMain.add(new DoubleSetting.Builder()
            .name("高度").description("VClip闪烁高度")
            .defaultValue(10).min(1).max(50).sliderRange(1, 50).build()
    );

    // ==================== 状态 ====================
    private class_1657 nearestPlayer;

    public fanmiss() {
        super(MaceKillAddon.CATEGORY, "fanmiss", "防空刀 - 防止重锤空刀，快速VClip闪烁");
    }

    @Override
    public void onDeactivate() {
        nearestPlayer = null;
    }

    // ==================== Tick ====================

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null) return;

        nearestPlayer = findNearestPlayer();
        if (nearestPlayer == null) return;

        double h = riseHeight.get();
        double startY = mc.field_1724.method_23318();

        // 快速向上闪烁：10个包
        for (int i = 1; i <= 10; i++) {
            double y = startY + (h / 10.0) * i;
            mc.method_1562().method_52787(
                    new class_2828.class_2829(mc.field_1724.method_23317(), y, mc.field_1724.method_23321(),
                            false, false));
        }

        // 快速向下闪烁：10个包
        for (int i = 1; i <= 10; i++) {
            double y = startY + h - (h / 10.0) * i;
            mc.method_1562().method_52787(
                    new class_2828.class_2829(mc.field_1724.method_23317(), y, mc.field_1724.method_23321(),
                            false, false));
        }

        // 回到原位
        mc.method_1562().method_52787(
                new class_2828.class_2829(mc.field_1724.method_23317(), startY, mc.field_1724.method_23321(),
                        mc.field_1724.method_24828(), false));
    }

    // ==================== 目标查找 ====================

    private class_1657 findNearestPlayer() {
        if (mc.field_1687 == null || mc.field_1724 == null) return null;
        double rangeSq = detectRange.get() * detectRange.get();
        class_1657 best = null;
        double bestDist = Double.MAX_VALUE;

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1657 p)) continue;
            if (p == mc.field_1724 || !p.method_5805()) continue;
            if (!Friends.get().shouldAttack(p)) continue;

            double distSq = mc.field_1724.method_5858(p);
            if (distSq > rangeSq) continue;

            if (distSq < bestDist) {
                bestDist = distSq;
                best = p;
            }
        }
        return best;
    }

    // ==================== HUD信息 ====================

    @Override
    public String getInfoString() {
        if (nearestPlayer != null && mc.field_1724 != null) {
            double dist = mc.field_1724.method_5739(nearestPlayer);
            return String.format("%s %.1fm", nearestPlayer.method_5477().getString(), dist);
        }
        return "无目标";
    }
}
