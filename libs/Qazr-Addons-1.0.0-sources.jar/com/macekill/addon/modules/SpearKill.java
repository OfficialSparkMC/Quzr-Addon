package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2596;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2868;
import net.minecraft.network.packet.c2s.play.*;
import java.lang.reflect.Field;
import java.util.*;

/**
 * 长矛杀戮 - Blink/Lunge 攻击模块
 * 来自 InvincibleMachineGun 的 SpearKill
 *
 * 【Blink 模式】：冻结移动包 → 接近目标 → 一次性释放所有包（瞬移效果）
 * 【Lunge 模式】：利用长矛蓄力冲刺攻击
 *
 * 工作原理：
 * 1. Blink：玩家正常移动但发包被拦截，存在本地队列中；
 *    当到达指定距离时，一次性发送所有积攒的移动包，
 *    服务端看到的是瞬间移动，实现"闪现"到目标面前。
 * 2. Lunge：长矛蓄力满后，先瞬移到目标上方（FromAbove），
 *    然后释放蓄力，利用动量冲刺穿入目标完成攻击。
 *
 * 支持全部 7 种长矛变体：木 / 石 / 铜 / 铁 / 金 / 钻石 / 下界合金
 */
public class SpearKill extends Module {

    // ==================== 长矛全7种变体 ====================
    private static final Set<class_1792> SPEARS = Set.of(
            class_1802.field_63384, class_1802.field_63385, class_1802.field_63386,
            class_1802.field_63387, class_1802.field_63388,
            class_1802.field_63389, class_1802.field_63390
    );

    // ==================== 枚举 ====================
    private enum Mode { Blink, Lunge }
    private enum LungeMode { Normal, FromAbove, Auto }
    public enum TargetListMode { Off, Whitelist }

    // ==================== 设置组 ====================
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgBlink = settings.createGroup("Blink");
    private final SettingGroup sgLunge = settings.createGroup("Lunge");
    private final SettingGroup sgTarget = settings.createGroup("目标");

    // ---- 通用 ----
    private final Setting<Mode> mode = sgGeneral.add(new EnumSetting.Builder<Mode>()
            .name("模式").description("Blink=闪现, Lunge=冲刺")
            .defaultValue(Mode.Blink).build()
    );

    private final Setting<Double> maxrange = sgGeneral.add(new DoubleSetting.Builder()
            .name("范围").description("检测目标的最大距离")
            .defaultValue(50).min(1).max(200).sliderRange(1, 128).build()
    );

    private final Setting<Boolean> nonofall = sgGeneral.add(new BoolSetting.Builder()
            .name("防摔落").description("攻击时临时启用 NoFall").defaultValue(true).build()
    );

    // ---- Blink ----
    private final Setting<Double> flushRange = sgBlink.add(new DoubleSetting.Builder()
            .name("释放距离").description("距离目标多远时释放所有移动包（实现瞬移）")
            .defaultValue(2.0).min(0.5).max(10).sliderRange(0.5, 10)
            .visible(() -> mode.get() == Mode.Blink).build()
    );

    private final Setting<Double> maxFlushRange = sgBlink.add(new DoubleSetting.Builder()
            .name("最大闪现距离").description("超过此距离即使没到释放距离也强制释放")
            .defaultValue(25).min(5).max(100).sliderRange(5, 100)
            .visible(() -> mode.get() == Mode.Blink).build()
    );

    private final Setting<Double> blinkDistanceBoost = sgBlink.add(new DoubleSetting.Builder()
            .name("距离加成").description("额外增加闪现距离").defaultValue(2)
            .min(0).max(10).sliderRange(0, 10)
            .visible(() -> mode.get() == Mode.Blink).build()
    );

    // ---- Lunge ----
    private final Setting<LungeMode> lungeMode = sgLunge.add(new EnumSetting.Builder<LungeMode>()
            .name("冲刺方向").description("Normal=正面, FromAbove=从上方, Auto=优先从上方")
            .defaultValue(LungeMode.FromAbove)
            .visible(() -> mode.get() == Mode.Lunge).build()
    );

    private final Setting<Double> aboveHeight = sgLunge.add(new DoubleSetting.Builder()
            .name("上方高度").description("从目标上方多高的位置发起冲刺")
            .defaultValue(10).min(1).max(50).sliderRange(1, 50)
            .visible(() -> mode.get() == Mode.Lunge && lungeMode.get() != LungeMode.Normal)
            .build()
    );

    private final Setting<Double> lungeStrength = sgLunge.add(new DoubleSetting.Builder()
            .name("冲刺强度").description("冲刺力度倍数").defaultValue(1.5)
            .min(0.5).max(5).sliderRange(0.5, 5)
            .visible(() -> mode.get() == Mode.Lunge).build()
    );

    private final Setting<Boolean> stop = sgLunge.add(new BoolSetting.Builder()
            .name("攻击前停止").description("冲刺前在目标面前短暂停顿，看起来更自然")
            .defaultValue(true)
            .visible(() -> mode.get() == Mode.Lunge).build()
    );

    private final Setting<Double> stopDistance = sgLunge.add(new DoubleSetting.Builder()
            .name("停止距离").description("在距目标多远时停顿").defaultValue(3)
            .min(0.5).max(10).sliderRange(0.5, 10)
            .visible(() -> mode.get() == Mode.Lunge && stop.get()).build()
    );

    // ---- 目标 ----
    private final Setting<TargetListMode> targetListMode = sgTarget.add(new EnumSetting.Builder<TargetListMode>()
            .name("列表模式").defaultValue(TargetListMode.Off).build()
    );

    private final Setting<String> targetList = sgTarget.add(new StringSetting.Builder()
            .name("目标列表").description("逗号分隔").defaultValue("")
            .visible(() -> targetListMode.get() != TargetListMode.Off).build()
    );

    private final Setting<Boolean> ignoreFriends = sgTarget.add(new BoolSetting.Builder()
            .name("忽略好友").defaultValue(true).build()
    );

    // ==================== 状态 ====================
    private final List<class_2596<?>> packetQueue = new ArrayList<>();
    private static Field selectedSlotField;
    private boolean isBlinking;
    private boolean isFlushing;
    private class_243 startPos;
    private boolean wasCharging;
    private double lastTargetDistance;
    private class_1297 currentTarget;

    public SpearKill() {
        super(MaceKillAddon.CATEGORY, "SpearKill", "长矛杀戮 - Blink/Lunge 攻击");
    }

    @Override
    public void onActivate() {
        resetState();
    }

    @Override
    public void onDeactivate() {
        mc.field_1690.field_1904.method_23481(false);
        if (isBlinking) flushPackets();
        resetState();
    }

    private void resetState() {
        isBlinking = false;
        isFlushing = false;
        wasCharging = false;
        lastTargetDistance = Double.MAX_VALUE;
        currentTarget = null;
        synchronized (packetQueue) { packetQueue.clear(); }
    }

    // ==================== Tick ====================

    @EventHandler
    private void onPreTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        if (mode.get() == Mode.Blink) {
            tickBlink();
        } else {
            tickLunge();
        }
    }

    // ========== Blink 逻辑 ==========
    //
    // Blink 模式工作流程：
    // 1. 找到目标，开始拦截所有 PlayerMoveC2SPacket（本地积攒，不让服务端知道你在移动）
    // 2. 本地正常走向目标，到达 释放距离(flushRange) 后触发释放
    // 3. 切换到长矛 → 蓄力 → 蓄满后一次性 flush 所有积攒的移动包
    //    服务端瞬间收到所有包，看到的是"瞬移"到目标面前
    // 4. 发送 PlayerInteractEntityC2SPacket.attack 完成攻击
    //    同时释放蓄力触发长矛冲刺，造成额外伤害
    // 5. 如果超出 最大闪现距离(maxFlushRange) 仍未接近目标 → 取消并 flush 包

    private void tickBlink() {
        if (!isBlinking) {
            currentTarget = findTarget();
            if (currentTarget == null) return;
            startBlink();
        }

        lastTargetDistance = mc.field_1724.method_5858(currentTarget);

        double dist = Math.sqrt(lastTargetDistance);
        double flushDist = flushRange.get();
        double maxDist = maxFlushRange.get() + blinkDistanceBoost.get();

        if (dist <= flushDist) {
            // 进入释放距离，切换到长矛并蓄力
            if (!isFlushing) {
                switchToSpear();
                mc.field_1690.field_1904.method_23481(true);
                isFlushing = true;
            }

            // 蓄力满 → 释放所有积攒包 + 攻击
            if (mc.field_1724.method_6048() >= getSpearChargeTicks()) {
                mc.field_1690.field_1904.method_23481(false);
                flushPackets();   // 释放积攒的移动包 → 服务端看到瞬移
                attackTarget();   // 发送攻击包
                resetState();
            }
        } else if (dist > maxDist && startPos != null) {
            // 超出最大闪现范围 → 取消本次闪现
            mc.field_1690.field_1904.method_23481(false);
            flushPackets();
            resetState();
        }
    }

    private void startBlink() {
        isBlinking = true;
        startPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        lastTargetDistance = mc.field_1724.method_5858(currentTarget);
        synchronized (packetQueue) { packetQueue.clear(); }
    }

    private void flushPackets() {
        if (mc.method_1562() == null) return;

        // ★ 必须先在发送任何包之前关闭 Blink，
        //    否则 onSendPacket 会把发出去的包重新捕获回队列，导致 ConcurrentModificationException 崩溃
        isBlinking = false;
        isFlushing = false;

        // 面向目标
        if (currentTarget != null) {
            float yaw = getYawTo(currentTarget);
            float pitch = getPitchTo(currentTarget);
            mc.method_1562().method_52787(
                    new class_2828.class_2831(yaw, pitch, mc.field_1724.method_24828(), false));
        }

        // 一次性释放所有积攒的移动包 → 服务端看到的是瞬间传送
        synchronized (packetQueue) {
            for (class_2596<?> p : packetQueue) {
                mc.method_1562().method_52787(p);
            }
            packetQueue.clear();
        }
    }

    private void attackTarget() {
        if (mc.method_1562() == null || currentTarget == null) return;
        mc.method_1562().method_52787(
                class_2824.method_34206(currentTarget, mc.field_1724.method_5715()));
    }

    // ========== Lunge 逻辑 ==========
    //
    // Lunge 模式工作流程：
    // 1. 找到目标，切换到长矛
    // 2. 面向目标旋转
    // 3. FromAbove 模式：VClip 瞬移到目标上方，视角垂直朝下(pitch=-90)
    //    Normal 模式：在目标正面停止(可选)
    // 4. 蓄力长矛
    // 5. 蓄力满后 release → 长矛冲刺穿入目标造成伤害
    //    - FromAbove：从头顶俯冲而下，利用重力+冲刺最大化伤害
    //    - Normal：水平冲刺穿过目标
    // 6. 冲刺强度(lungeStrength) 通过设置额外的移动包来增加冲刺距离

    private void tickLunge() {
        currentTarget = findTarget();
        if (currentTarget == null) return;

        if (!isUsingSpear()) {
            switchToSpear();
            return;
        }

        boolean useAbove = lungeMode.get() == LungeMode.FromAbove
                || (lungeMode.get() == LungeMode.Auto);

        if (useAbove && !wasCharging) {
            class_243 abovePos = findAbovePos(currentTarget);
            if (abovePos != null && mc.field_1724.method_5858(currentTarget) > 2) {
                // VClip 瞬移到目标上方
                for (double y = mc.field_1724.method_23318(); y < abovePos.field_1351; y += 8) {
                    mc.method_1562().method_52787(
                            new class_2828.class_2829(abovePos.field_1352,
                                    Math.min(y + 8, abovePos.field_1351), abovePos.field_1350, false, false));
                }
            }
            // 视角垂直朝下 → 让长矛冲刺方向朝下穿过目标
            mc.method_1562().method_52787(
                    new class_2828.class_2831(getYawTo(currentTarget), -90.0f, false, false));
        } else {
            // Normal 模式：水平面向目标
            rotateToTarget(currentTarget);
        }

        // 可选：在目标面前停顿（更自然）
        if (stop.get()) {
            double dist = mc.field_1724.method_5858(currentTarget);
            if (dist > stopDistance.get() * stopDistance.get()) return;
        }

        // 开始蓄力长矛
        if (!mc.field_1690.field_1904.method_1434()) {
            mc.field_1690.field_1904.method_23481(true);
            wasCharging = true;
        }

        // 蓄力满 → 释放冲刺 + 发送额外移动包增强冲刺距离
        if (mc.field_1724.method_6048() >= getSpearChargeTicks()) {
            mc.field_1690.field_1904.method_23481(false);

            // 额外冲刺移动包 → 增强长矛冲刺效果
            double strength = lungeStrength.get() - 1.0;
            if (strength > 0 && currentTarget != null) {
                class_243 dir = new class_243(
                        currentTarget.method_23317() - mc.field_1724.method_23317(),
                        0,
                        currentTarget.method_23321() - mc.field_1724.method_23321()
                ).method_1029().method_1021(strength * 2);
                class_243 through = new class_243(
                        currentTarget.method_23317() + dir.field_1352,
                        currentTarget.method_23318(),
                        currentTarget.method_23321() + dir.field_1350);
                mc.method_1562().method_52787(
                        new class_2828.class_2829(through.field_1352, through.field_1351, through.field_1350, false, false));
            }

            resetState();
        }
    }

    private class_243 findAbovePos(class_1297 target) {
        double h = aboveHeight.get();
        class_2338 targetPos = target.method_24515();

        // 从设定高度向下扫描，找到第一个头脚都是空气的安全位置
        for (int yOff = (int) h; yOff > 0; yOff--) {
            class_2338 pos = new class_2338(targetPos.method_10263(), targetPos.method_10264() + yOff, targetPos.method_10260());
            if (isSafePosition(pos)) {
                return new class_243(target.method_23317(), pos.method_10264(), target.method_23321());
            }
        }
        return null;
    }

    private boolean isSafePosition(class_2338 pos) {
        if (mc.field_1687 == null) return false;
        return mc.field_1687.method_8320(pos).method_26215()
                && mc.field_1687.method_8320(pos.method_10084()).method_26215();
    }

    // ==================== 发包拦截 ====================

    @EventHandler
    private void onSendPacket(PacketEvent.Send event) {
        if (!isBlinking) return;
        if (event.packet instanceof class_2828 movePacket) {
            synchronized (packetQueue) {
                packetQueue.add(movePacket);
            }
            event.cancel();
        }
    }

    // ==================== 目标查找 ====================

    private class_1297 findTarget() {
        if (mc.field_1687 == null || mc.field_1724 == null) return null;

        class_1297 best = null;
        double bestDist = Double.MAX_VALUE;
        double range = maxrange.get();

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1309 le)) continue;
            if (le.method_29504()) continue;
            if (e == mc.field_1724) continue;
            if (!isValidTarget(e)) continue;

            double dist = mc.field_1724.method_5858(e);
            if (dist < range * range && dist < bestDist) {
                bestDist = dist;
                best = e;
            }
        }
        return best;
    }

    private boolean isValidTarget(class_1297 entity) {
        if (!(entity instanceof class_1309 le)) return false;
        if (le.method_29504()) return false;

        if (entity instanceof class_1657 player) {
            if (player.method_7325()) return false;
            if (ignoreFriends.get() && Friends.get().isFriend(player)) return false;
        }

        // 名单过滤
        if (targetListMode.get() == TargetListMode.Whitelist && entity instanceof class_1657 p) {
            Set<String> names = parseNameList();
            if (!names.isEmpty() && !names.contains(p.method_5477().getString())) return false;
        }

        return true;
    }

    private Set<String> parseNameList() {
        Set<String> set = new HashSet<>();
        for (String s : targetList.get().split(",")) {
            String t = s.trim();
            if (!t.isEmpty()) set.add(t);
        }
        return set;
    }

    // ==================== 工具 ====================

    private boolean isUsingSpear() {
        class_1799 stack = mc.field_1724.method_6047();
        return SPEARS.contains(stack.method_7909());
    }

    private void switchToSpear() {
        if (isUsingSpear()) return;
        for (int i = 0; i < 9; i++) {
            if (SPEARS.contains(mc.field_1724.method_31548().method_5438(i).method_7909())) {
                setSelectedSlot(i);
                mc.method_1562().method_52787(new class_2868(i));
                return;
            }
        }
    }

    private void setSelectedSlot(int slot) {
        try {
            if (selectedSlotField == null) {
                selectedSlotField = class_1661.class.getDeclaredField("selectedSlot");
                selectedSlotField.setAccessible(true);
            }
            selectedSlotField.setInt(mc.field_1724.method_31548(), slot);
        } catch (Exception ignored) {}
    }

    private int getSpearChargeTicks() {
        // 长矛满蓄力大约需要 10 tick（20 tick/秒 × 0.5秒）
        return 10;
    }

    private void rotateToTarget(class_1297 target) {
        mc.method_1562().method_52787(
                new class_2828.class_2831(getYawTo(target), getPitchTo(target),
                        mc.field_1724.method_24828(), false));
    }

    private float getYawTo(class_1297 target) {
        double dx = target.method_23317() - mc.field_1724.method_23317();
        double dz = target.method_23321() - mc.field_1724.method_23321();
        return (float) Math.toDegrees(Math.atan2(-dx, dz));
    }

    private float getPitchTo(class_1297 target) {
        double dx = target.method_23317() - mc.field_1724.method_23317();
        double dy = target.method_23320() - mc.field_1724.method_23320();
        double dz = target.method_23321() - mc.field_1724.method_23321();
        double dist = Math.sqrt(dx * dx + dz * dz);
        return (float) -Math.toDegrees(Math.atan2(dy, dist));
    }

    @Override
    public String getInfoString() {
        return mode.get() == Mode.Blink
                ? (isBlinking ? "闪现中" : "就绪")
                : "冲刺";
    }
}
