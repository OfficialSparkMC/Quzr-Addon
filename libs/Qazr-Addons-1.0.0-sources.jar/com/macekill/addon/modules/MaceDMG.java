package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.ChatUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_1934;
import net.minecraft.class_2561;
import net.minecraft.class_2828;
import net.minecraft.class_310;

public class MaceDMG extends Module {
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> fakeHeight = sgGeneral.add(new DoubleSetting.Builder()
        .name("伪造高度")
        .description("MaceDMG发送的高空位置高度(sqrt值,如√500≈22.36)")
        .defaultValue(22.36)
        .min(1.0).max(50.0).sliderMax(35.0)
        .build()
    );

    private final Setting<Integer> attackInterval = sgGeneral.add(new IntSetting.Builder()
        .name("攻击间隔")
        .description("攻击间隔(毫秒, 最小25ms)")
        .defaultValue(55)
        .min(25).max(2000).sliderMax(500)
        .build()
    );

    private final Setting<Boolean> globalDetection = sgGeneral.add(new BoolSetting.Builder()
        .name("全局攻击检测")
        .description("ON:拦截所有攻击事件自动触发 | OFF:仅玩家手动左键攻击时触发")
        .defaultValue(true)
        .build()
    );

    private final Setting<Boolean> autoSwitch = sgGeneral.add(new BoolSetting.Builder()
        .name("自动切换重锤")
        .description("背包中有重锤时自动切换到主手")
        .defaultValue(true)
        .build()
    );

    private final Setting<Integer> normalPackets = sgGeneral.add(new IntSetting.Builder()
        .name("正常包数量")
        .description("高空包之前发送的正常位置包数量(参考Wurst:4)")
        .defaultValue(4)
        .min(1).max(10).sliderMax(8)
        .build()
    );

    private final Setting<Boolean> chatInfo = sgGeneral.add(new BoolSetting.Builder()
        .name("聊天信息")
        .description("在聊天栏显示触发信息")
        .defaultValue(false)
        .build()
    );

    // ---- 内部状态 ----
    private long lastAttackTime;
    private float lastCooldown;

    public MaceDMG() {
        super(MaceKillAddon.CATEGORY, "平地重锤",
            "手持重锤攻击时伪造高度打出满伤害.\n" +
            "支持全局攻击检测(自动劫持攻击事件)或手动触发.");
    }

    @Override
    public void onActivate() {
        lastAttackTime = 0;
        lastCooldown = 0;
        if (chatInfo.get()) info("§a平地重锤已启动! 伪造高度=" + String.format("%.1f", fakeHeight.get()) + " 全局检测=" + (globalDetection.get() ? "ON" : "OFF"));
    }

    @Override
    public void onDeactivate() {
        if (chatInfo.get()) info("§c平地重锤已关闭!");
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        class_310 mc = class_310.method_1551();
        class_1657 player = mc.field_1724;

        if (player == null || mc.field_1687 == null) return;
        if (mc.field_1761.method_2920() == class_1934.field_9219) return;

        // 自动切换重锤
        if (autoSwitch.get() && !isHoldingMace(player)) {
            switchToMace(mc);
        }

        if (!isHoldingMace(player)) return;

        // 攻击检测
        boolean shouldAttack = false;

        if (globalDetection.get()) {
            // 全局模式: 检测攻击冷却是否刚刚重置(任何来源的攻击)
            float currentCooldown = player.method_7261(0);
            if (lastCooldown > 0.5f && currentCooldown < 0.01f) {
                shouldAttack = true;
            }
            lastCooldown = currentCooldown;
        } else {
            // 手动模式: 仅当玩家按下攻击键
            if (mc.field_1690.field_1886.method_1436()) {
                shouldAttack = true;
            }
        }

        if (!shouldAttack) return;

        // 频率控制(毫秒间隔)
        long now = System.currentTimeMillis();
        if (lastAttackTime == 0) lastAttackTime = now;
        long elapsed = now - lastAttackTime;
        if (elapsed < attackInterval.get()) return;
        lastAttackTime = now;

        performMaceDMG(mc);
    }

    private void performMaceDMG(class_310 mc) {
        class_1657 player = mc.field_1724;
        double height = fakeHeight.get();

        // 5包攻击序列: 4正常(onGround=true) + 1高空(onGround=false) + fallDistance归零
        for (int i = 0; i < normalPackets.get(); i++) {
            sendFakeY(mc, 0);
        }
        sendFakeY_air(mc, Math.sqrt(height));
        mc.field_1724.field_6017 = 0;

        if (chatInfo.get()) {
            info("§b触发MaceDMG | height=" + String.format("%.1f", Math.sqrt(height)));
        }
    }

    private void sendFakeY(class_310 mc, double offset) {
        mc.field_1724.field_3944.method_52787(
            new class_2828.class_2829(
                mc.field_1724.method_23317(), mc.field_1724.method_23318() + offset, mc.field_1724.method_23321(),
                true, mc.field_1724.field_5976
            )
        );
    }

    /** 高空包: onGround=false, 让服务器记录坠落距离用于重锤伤害计算 */
    private void sendFakeY_air(class_310 mc, double offset) {
        mc.field_1724.field_3944.method_52787(
            new class_2828.class_2829(
                mc.field_1724.method_23317(), mc.field_1724.method_23318() + offset, mc.field_1724.method_23321(),
                false, mc.field_1724.field_5976
            )
        );
    }

    private boolean isHoldingMace(class_1657 player) {
        return player.method_6047().method_31574(class_1802.field_49814)
            || player.method_6079().method_31574(class_1802.field_49814);
    }

    private void switchToMace(class_310 mc) {
        class_1657 player = mc.field_1724;
        if (player.method_6047().method_31574(class_1802.field_49814)) return;
        if (player.method_6079().method_31574(class_1802.field_49814)) return;

        for (int i = 0; i < 9; i++) {
            if (player.method_31548().method_5438(i).method_31574(class_1802.field_49814)) {
                setSelectedSlot(player, i);
                return;
            }
        }

        for (int i = 9; i < 36; i++) {
            if (player.method_31548().method_5438(i).method_31574(class_1802.field_49814)) {
                int syncId = player.field_7498.field_7763;
                int selected = getSelectedSlot(player);
                mc.field_1761.method_2906(syncId, i, selected, net.minecraft.class_1713.field_7791, player);
                return;
            }
        }
    }

    private void setSelectedSlot(class_1657 player, int slot) {
        try {
            java.lang.reflect.Field f = net.minecraft.class_1661.class.getDeclaredField("selectedSlot");
            f.setAccessible(true);
            f.setInt(player.method_31548(), slot);
        } catch (Exception ignored) {}
    }

    private int getSelectedSlot(class_1657 player) {
        try {
            java.lang.reflect.Field f = net.minecraft.class_1661.class.getDeclaredField("selectedSlot");
            f.setAccessible(true);
            return f.getInt(player.method_31548());
        } catch (Exception ignored) {}
        return 0;
    }

    private void info(String msg) {
        ChatUtils.sendMsg(class_2561.method_43470("§8[§b平地重锤§8] §f" + msg));
    }
}
