package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.*;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1792;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2338.class_2339;
import net.minecraft.class_2350;
import net.minecraft.class_2356;
import net.minecraft.class_243;
import net.minecraft.class_2521;
import net.minecraft.class_2680;
import net.minecraft.class_3486;
import java.lang.management.ManagementFactory;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.*;

/**
 * 矿物追踪 — Wurst TunnelHack 风格。
 * 路径: 折线形, X/Z优先对齐 → 飞行垂直 → 挖掘 → 返回隧道层。
 */
public class AutoMineModule extends Module {

    /* ==================== Settings ==================== */
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Double> scanRange = sgGeneral.add(new DoubleSetting.Builder()
        .name("扫描范围").description("搜索矿石的最大半径(格)")
        .defaultValue(64.0).min(8.0).max(256.0).sliderMax(128.0).build());

    private final Setting<Boolean> autoMine = sgGeneral.add(new BoolSetting.Builder()
        .name("自动挖矿").description("自动寻路+挖掘")
        .defaultValue(true).build());

    private final Setting<Integer> minY = sgGeneral.add(new IntSetting.Builder()
        .name("最低Y层").description("此层数及以下的方块不会被向下挖掘")
        .defaultValue(-64).min(-64).max(320).build());

    private final Setting<Integer> stuckTime = sgGeneral.add(new IntSetting.Builder()
        .name("卡住判定").description("多久不动算卡住(tick)")
        .defaultValue(60).min(10).max(200).build());

    private final Setting<Integer> abandonThreshold = sgGeneral.add(new IntSetting.Builder()
        .name("放弃阈值").description("上一个矿挖完后超时未到达则黑名单3分钟(tick)")
        .defaultValue(200).min(20).max(1200).build());

    private final Setting<Integer> safeDistance = sgGeneral.add(new IntSetting.Builder()
        .name("安全距离").description("躲避流体的最小距离(格)")
        .defaultValue(5).min(2).max(15).build());

    private final Setting<Boolean> avoidCaves = sgGeneral.add(new BoolSetting.Builder()
        .name("躲避洞穴").description("隧道避开天然空气/洞穴(会降低寻路成功率)")
        .defaultValue(false).build());

    private final Setting<Boolean> filterDangerOres = sgGeneral.add(new BoolSetting.Builder()
        .name("排除危险区矿物").description("不挖掘安全距离内靠近流体/洞穴的矿物")
        .defaultValue(true).build());

    private final Setting<Boolean> chatInfo = sgGeneral.add(new BoolSetting.Builder()
        .name("聊天信息").description("在聊天栏输出状态")
        .defaultValue(false).build());

    /* 矿石过滤 */
    private final SettingGroup sgOres = settings.createGroup("矿物列表");
    private final Setting<Boolean> mineCoal        = sgOres.add(new BoolSetting.Builder().name("煤矿").defaultValue(true).build());
    private final Setting<Boolean> mineIron        = sgOres.add(new BoolSetting.Builder().name("铁矿").defaultValue(true).build());
    private final Setting<Boolean> mineCopper      = sgOres.add(new BoolSetting.Builder().name("铜矿").defaultValue(true).build());
    private final Setting<Boolean> mineGold        = sgOres.add(new BoolSetting.Builder().name("金矿").defaultValue(true).build());
    private final Setting<Boolean> mineRedstone    = sgOres.add(new BoolSetting.Builder().name("红石矿").defaultValue(true).build());
    private final Setting<Boolean> mineLapis       = sgOres.add(new BoolSetting.Builder().name("青金石").defaultValue(true).build());
    private final Setting<Boolean> mineDiamond     = sgOres.add(new BoolSetting.Builder().name("钻石矿").defaultValue(true).build());
    private final Setting<Boolean> mineEmerald     = sgOres.add(new BoolSetting.Builder().name("绿宝石").defaultValue(true).build());
    private final Setting<Boolean> mineNetherQuartz= sgOres.add(new BoolSetting.Builder().name("下界石英").defaultValue(true).build());
    private final Setting<Boolean> mineNetherGold  = sgOres.add(new BoolSetting.Builder().name("下界金矿").defaultValue(true).build());
    private final Setting<Boolean> mineAncientDebris=sgOres.add(new BoolSetting.Builder().name("远古残骸").defaultValue(true).build());

    /* 渲染 */
    private final SettingGroup sgRender = settings.createGroup("渲染");
    private final Setting<Boolean> renderOres = sgRender.add(new BoolSetting.Builder()
        .name("渲染矿石").defaultValue(true).build());
    private final Setting<SettingColor> oreColor = sgRender.add(new ColorSetting.Builder()
        .name("矿石颜色").defaultValue(new SettingColor(255, 255, 0, 200)).visible(renderOres::get).build());
    private final Setting<SettingColor> targetColor = sgRender.add(new ColorSetting.Builder()
        .name("目标颜色").defaultValue(new SettingColor(0, 255, 0, 200)).build());
    private final Setting<SettingColor> pathColor = sgRender.add(new ColorSetting.Builder()
        .name("路径颜色").defaultValue(new SettingColor(100, 200, 255, 180)).build());

    /* ==================== 状态 ==================== */
    private enum Phase { IDLE, WALK_XZ, FLY_UP, DIG_DOWN, MINE_ORE, RETURN_TO_TUNNEL }

    private final Set<class_2338> orePositions = new HashSet<>();
    private class_2338 currentTarget;       // 当前目标矿石
    private final List<class_2338> waypoints = new ArrayList<>(); // 折线路径节点
    private int wpIndex;                  // 当前路径节点索引
    private Phase phase = Phase.IDLE;
    private int scanCooldown = 60; // 每3秒扫描一次, 降低卡顿
    private int tickCounter;

    // 隧道挖掘
    private class_2338 breakingPos;         // 正在挖掘的方块
    private int breakTicks;
    private int stuckTicks;
    private boolean isStuck;
    private class_2338 lastPos;
    private int targetLockTime;           // 锁定同一个矿石的tick数(性能保护)

    // 垂直
    private int tunnelY;                  // 隧道层 Y (飞行前记录, 挖完矿返回此层)
    private boolean wasFlying;

    // 性能保护
    private Method getCpuLoadMethod;       // getProcessCpuLoad 反射方法(可能为null)
    private int cpuCheckTick;              // CPU检查计数器
    private long perfPauseUntil;           // 性能保护暂停到何时(ms)

    // 黑名单
    private final Map<class_2338, Long> abandonBlacklist = new HashMap<>();
    private final Map<class_2338, Long> dugPositions = new HashMap<>(); // 已挖掘位置, 1分钟过期
    private long lastOreMinedTime;

    private static Field selectedSlotField;

    /* ==================== 构造 & 生命周期 ==================== */
    public AutoMineModule() {
        super(MaceKillAddon.CATEGORY, "矿物追踪", "Wurst TunnelHack风格: 折线寻路+飞行垂直+自动挖掘");
    }

    @Override public void onActivate() {
        orePositions.clear(); currentTarget = null; waypoints.clear();
        wpIndex = 0; phase = Phase.IDLE; scanCooldown = 60; tickCounter = 0;
        breakingPos = null; breakTicks = 0; stuckTicks = 0; isStuck = false;
        targetLockTime = 0;
        abandonBlacklist.clear(); dugPositions.clear(); lastOreMinedTime = 0;
        lastPos = mc.field_1724 != null ? mc.field_1724.method_24515() : null;
        wasFlying = mc.field_1724 != null && mc.field_1724.method_31549().field_7479;
        // 反射获取 CPU 监控方法(安全降级)
        try {
            getCpuLoadMethod = ManagementFactory.getOperatingSystemMXBean()
                .getClass().getMethod("getProcessCpuLoad");
        } catch (Exception ignored) {
            getCpuLoadMethod = null;
        }
    }

    @Override public void onDeactivate() {
        orePositions.clear(); waypoints.clear();
        releaseControls();
        // 恢复原始飞行状态
        if (!wasFlying) {
            mc.field_1724.method_31549().field_7479 = false;
            mc.field_1724.method_31549().field_7478 = false;
        }
    }

    @Override public String getInfoString() {
        if (isStuck) return "清理...";
        if (phase == Phase.WALK_XZ && currentTarget != null) return "→" + currentTarget.method_23854();
        if (phase == Phase.FLY_UP) return "飞行上升...";
        if (phase == Phase.DIG_DOWN) return "阶梯下降...";
        if (phase == Phase.MINE_ORE) return "挖掘矿石...";
        if (phase == Phase.RETURN_TO_TUNNEL) return "返回隧道...";
        return orePositions.size() + " ore(s)";
    }

    /* ==================== 主循环 ==================== */
    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        // 死亡自动关闭
        if (mc.field_1724.method_29504() || mc.field_1724.method_6032() <= 0) {
            toggle();
            return;
        }

        tickCounter++;

        // 清理过期黑名单
        if (tickCounter % 100 == 0) {
            long now = System.currentTimeMillis();
            abandonBlacklist.entrySet().removeIf(e -> e.getValue() < now);
            dugPositions.entrySet().removeIf(e -> e.getValue() < now);
        }

        // 扫描
        if (scanCooldown-- <= 0) { scanCooldown = 60; scan(); }
        orePositions.removeIf(p -> {
            class_2680 s = mc.field_1687.method_8320(p);
            return !isTargetOre(s.method_26204()) || s.method_26215();
        });

        // 更新最近矿石
        class_2338 nearest = orePositions.isEmpty() ? null : orePositions.stream()
            .filter(p -> !abandonBlacklist.containsKey(p))
            .filter(p -> !dugPositions.containsKey(p))
            .min(Comparator.comparingDouble(p -> p.method_19770(mc.field_1724.method_33571()))).orElse(null);

        // 目标矿石被挖掉 → 记录时间
        if (currentTarget != null) {
            class_2680 ts = mc.field_1687.method_8320(currentTarget);
            if (!isTargetOre(ts.method_26204()) || ts.method_26215()) {
                lastOreMinedTime = System.currentTimeMillis();
                currentTarget = null; waypoints.clear(); wpIndex = 0; phase = Phase.IDLE;
                targetLockTime = 0;
                breakingPos = null; breakTicks = 0;
                returnIfFlying();
                notify("矿石已采掘完毕");
            }
        }

        // 放弃阈值
        if (currentTarget != null && lastOreMinedTime > 0) {
            long elapsed = System.currentTimeMillis() - lastOreMinedTime;
            if (elapsed > abandonThreshold.get() * 50L) {
                blacklistWithNeighbors(currentTarget);
                orePositions.remove(currentTarget);
                currentTarget = null; waypoints.clear(); wpIndex = 0; phase = Phase.IDLE;
                lastOreMinedTime = 0; // 重置, 避免每tick触发
                returnIfFlying();
                notify("放弃目标,黑名单3分钟");
            }
        }

        // 锁定新目标
        if (currentTarget == null && nearest != null) {
            currentTarget = nearest;
            targetLockTime = 0;
            planWaypoints();
            if (waypoints.isEmpty()) {
                currentTarget = null;
            } else if (autoMine.get()) {
                wpIndex = 0;
                // 检查是否在同Y层
                int pY = mc.field_1724.method_24515().method_10264();
                if (Math.abs(currentTarget.method_10264() - pY) <= 1) {
                    phase = Phase.WALK_XZ;
                } else if (currentTarget.method_10264() != pY) {
                    phase = Phase.WALK_XZ; // 先平走到XZ位置
                }
            }
        }

        // 卡住检测
        class_2338 curPos = mc.field_1724.method_24515();
        if (lastPos != null && curPos.equals(lastPos)) stuckTicks++;
        else { stuckTicks = 0; isStuck = false; }
        lastPos = curPos;
        if (stuckTicks >= stuckTime.get()) isStuck = true;

        // 卡住清理
        if (isStuck) { doClearing(); return; }

        // 如果手动关闭了自动挖矿, 仅扫描
        if (!autoMine.get() || currentTarget == null) return;

        // 性能保护暂停: 禁止寻路, 等待恢复
        if (perfPauseUntil > 0) {
            if (System.currentTimeMillis() < perfPauseUntil) return;
            perfPauseUntil = 0; cpuCheckTick = 0;
            notify("寻路已恢复");
        }

        // CPU实时监测: 每100tick检查进程CPU负载
        if (getCpuLoadMethod != null && ++cpuCheckTick >= 100) {
            cpuCheckTick = 0;
            try {
                double cpuLoad = (Double) getCpuLoadMethod.invoke(
                    ManagementFactory.getOperatingSystemMXBean());
                if (cpuLoad > 0.8) { // CPU > 80%
                    if (currentTarget != null) {
                        blacklistWithNeighbors(currentTarget);
                        orePositions.remove(currentTarget);
                    }
                    currentTarget = null; waypoints.clear(); wpIndex = 0; phase = Phase.IDLE;
                    targetLockTime = 0; lastOreMinedTime = 0;
                    breakingPos = null; breakTicks = 0;
                    mc.field_1761.method_2925();
                    perfPauseUntil = System.currentTimeMillis() + 5_000L;
                    notify(String.format("CPU过载(%.0f%%),暂停5秒", cpuLoad * 100));
                    return;
                }
            } catch (Exception ignored) {}
        }

        // 性能保护: 锁定同一个矿石超过60秒 → 强制黑名单
        if (++targetLockTime > 1200) {
            blacklistWithNeighbors(currentTarget);
            orePositions.remove(currentTarget);
            currentTarget = null; waypoints.clear(); wpIndex = 0; phase = Phase.IDLE;
            targetLockTime = 0; lastOreMinedTime = 0;
            breakingPos = null; breakTicks = 0;
            mc.field_1761.method_2925();
            notify("无法接近,黑名单3分钟");
            return;
        }

        // 分阶段处理
        switch (phase) {
            case WALK_XZ   -> { disableFlight(); walkXZPhase(); }
            case FLY_UP    -> { enableFlight(); flyUpPhase(); }
            case DIG_DOWN  -> { disableFlight(); digDownPhase(); }
            case MINE_ORE  -> { disableFlight(); mineOrePhase(); }
            case RETURN_TO_TUNNEL -> returnToTunnelPhase();
        }
    }

    /* ==================== 路径规划: 折线节点 + 寻路避障 ==================== */
    private void planWaypoints() {
        waypoints.clear();
        class_2338 from = mc.field_1724.method_24515();
        class_2338 to = currentTarget;

        // 终点选相邻空气位置
        to = findAirAdjacent(to);

        tunnelY = from.method_10264(); // 记录隧道层

        // XZ 水平寻路(躲避危险)
        class_2338 hTarget = new class_2338(to.method_10263(), tunnelY, to.method_10260());
        List<class_2338> hPath = findHorizontalPath(from, hTarget);
        // 过滤危险节点
        waypoints.addAll(hPath);
        waypoints.removeIf(wp -> isDangerZone(wp, tunnelY)); // 移除任何进入危险区的节点

        // 垂直差
        if (to.method_10264() != tunnelY) {
            waypoints.add(to); // 最终目标
        }

        if (!waypoints.isEmpty() && waypoints.get(0).equals(from))
            waypoints.remove(0); // 移除起点

        // 终检: 路径为空或无效则放弃
        if (waypoints.isEmpty()) {
            blacklistAndNext("无法规划安全路径");
            return;
        }

        wpIndex = 0;
    }

    /* ==================== A* 水平寻路 ==================== */

    /** 4方向 A*: 在XZ平面寻路, 躲避流体/洞穴, 输出折线节点 */
    private List<class_2338> findHorizontalPath(class_2338 from, class_2338 to) {
        int y = from.method_10264();
        // 4方向: 北/南/西/东, 无对角线
        int[][] dirs = {{0,1},{0,-1},{1,0},{-1,0}};

        Map<Long, Float> gScore = new HashMap<>();
        Map<Long, Long> parent = new HashMap<>();
        PriorityQueue<Node> open = new PriorityQueue<>();

        long startKey = key(from);
        long goalKey = key(to);
        gScore.put(startKey, 0f);
        open.offer(new Node(startKey, 0, heuristic(from, to)));

        int maxExpand = 6000, expanded = 0;
        long goalFound = -1;

        while (!open.isEmpty() && expanded < maxExpand) {
            Node cur = open.poll();
            if (cur.key == goalKey) { goalFound = cur.key; break; }
            expanded++;

            class_2338 cp = unkey(cur.key, y);
            // 跳过危险区(起点可豁免)
            if (!cp.equals(from) && isDangerZone(cp, y)) continue;

            for (int[] d : dirs) {
                class_2338 np = cp.method_10069(d[0], 0, d[1]);
                long nk = key(np);
                if (isDangerZone(np, y)) continue;

                float tentativeG = gScore.getOrDefault(cur.key, Float.MAX_VALUE) + 1f;
                if (tentativeG < gScore.getOrDefault(nk, Float.MAX_VALUE)) {
                    gScore.put(nk, tentativeG);
                    parent.put(nk, cur.key);
                    open.offer(new Node(nk, tentativeG, tentativeG + heuristic(np, to)));
                }
            }
        }

        // 重构路径
        List<class_2338> path = new ArrayList<>();
        if (goalFound < 0) {
            // A*失败 → 回退到直线(逐格检测危险)
            return fallbackPath(from, to, y);
        }

        long pKey = goalFound;
        while (pKey != startKey) {
            class_2338 bp = unkey(pKey, y);
            // 折线过滤: 只保留拐点
            path.add(bp);
            pKey = parent.getOrDefault(pKey, startKey);
        }
        path.add(from);
        Collections.reverse(path);

        // 折线压缩: 移除可直线到达的冗余节点
        return compressPath(path, y);
    }

    /** 折线压缩: 如果从 A 可以直接走到 C (无危险), 则删除中间节点 B */
    private List<class_2338> compressPath(List<class_2338> path, int y) {
        if (path.size() <= 2) return path;
        List<class_2338> result = new ArrayList<>();
        result.add(path.get(0));
        int anchor = 0;
        for (int i = 2; i < path.size(); i++) {
            if (!canWalkStraight(path.get(anchor), path.get(i), y)) {
                result.add(path.get(i - 1));
                anchor = i - 1;
            }
        }
        result.add(path.get(path.size() - 1));
        return result;
    }

    /** 检查A到B之间的直线是否安全(单向,无危险区) */
    private boolean canWalkStraight(class_2338 a, class_2338 b, int y) {
        int dx = Integer.signum(b.method_10263() - a.method_10263());
        int dz = Integer.signum(b.method_10260() - a.method_10260());
        if (dx != 0 && dz != 0) return false; // 禁止对角线
        if (dx == 0 && dz == 0) return true;
        int steps = dx != 0 ? Math.abs(b.method_10263() - a.method_10263()) : Math.abs(b.method_10260() - a.method_10260());
        for (int i = 1; i <= steps; i++) {
            if (isDangerZone(a.method_10069(dx * i, 0, dz * i), y)) return false;
        }
        return true;
    }

    /** A*失败时的回退: 逐格走直线+危险区跳过 */
    private List<class_2338> fallbackPath(class_2338 from, class_2338 to, int y) {
        List<class_2338> path = new ArrayList<>();
        path.add(from);
        int dx = Integer.signum(to.method_10263() - from.method_10263());
        int dz = Integer.signum(to.method_10260() - from.method_10260());
        int stepsX = Math.abs(to.method_10263() - from.method_10263());
        int stepsZ = Math.abs(to.method_10260() - from.method_10260());

        // 先X
        for (int i = 1; i <= stepsX; i++) {
            class_2338 p = from.method_10069(dx * i, 0, 0);
            if (!isDangerZone(p, y)) path.add(p);
            else {
                // 尝试Z侧移绕行
                for (int s = 1; s <= 4; s++) {
                    class_2338 det = p.method_10069(0, 0, s);
                    if (!isDangerZone(det, y)) { path.add(det); path.add(det.method_10069(dx, 0, 0)); break; }
                    det = p.method_10069(0, 0, -s);
                    if (!isDangerZone(det, y)) { path.add(det); path.add(det.method_10069(dx, 0, 0)); break; }
                }
            }
        }
        class_2338 afterX = new class_2338(to.method_10263(), y, from.method_10260());
        // 再Z
        for (int i = 1; i <= stepsZ; i++) {
            class_2338 p = afterX.method_10069(0, 0, dz * i);
            if (!isDangerZone(p, y)) path.add(p);
            else {
                for (int s = 1; s <= 4; s++) {
                    class_2338 det = p.method_10069(s, 0, 0);
                    if (!isDangerZone(det, y)) { path.add(det); path.add(det.method_10069(0, 0, dz)); break; }
                    det = p.method_10069(-s, 0, 0);
                    if (!isDangerZone(det, y)) { path.add(det); path.add(det.method_10069(0, 0, dz)); break; }
                }
            }
        }
        return path;
    }

    /** 检测2格高隧道是否进入危险区域(流体+可选洞穴) */
    private boolean isDangerZone(class_2338 pos, int yLevel) {
        int safeR = safeDistance.get();
        int minY = this.minY.get();
        boolean checkCaves = avoidCaves.get();
        for (int dx = -safeR; dx <= safeR; dx++)
            for (int dy = -1; dy <= 2; dy++)
                for (int dz = -safeR; dz <= safeR; dz++) {
                    class_2338 check = pos.method_10069(dx, yLevel + dy, dz);
                    if (check.method_10264() <= minY) continue;
                    class_2680 s = mc.field_1687.method_8320(check);
                    if (isFluid(s)) return true;
                    if (checkCaves && s.method_26215()) return true;
                }
        return false;
    }

    private long key(class_2338 p) { return ((long)p.method_10263() << 32) | (p.method_10260() & 0xFFFFFFFFL); }
    private class_2338 unkey(long k, int y) { return new class_2338((int)(k >> 32), y, (int)k); }
    private float heuristic(class_2338 a, class_2338 b) {
        return Math.abs(a.method_10263() - b.method_10263()) + Math.abs(a.method_10260() - b.method_10260());
    }
    private static class Node implements Comparable<Node> {
        long key; float g, f;
        Node(long key, float g, float f) { this.key = key; this.g = g; this.f = f; }
        public int compareTo(Node o) { return Float.compare(f, o.f); }
    }

    private class_2338 findAirAdjacent(class_2338 ore) {
        // 找矿石周围最近的空气位置
        class_2338 best = ore;
        double bestDist = Double.MAX_VALUE;
        class_243 eye = mc.field_1724 != null ? mc.field_1724.method_33571() : class_243.field_1353;
        for (class_2350 d : class_2350.values()) {
            class_2338 adj = ore.method_10093(d);
            if (mc.field_1687.method_8320(adj).method_26215() || isReplaceable(mc.field_1687.method_8320(adj))) {
                double dist = adj.method_19770(eye);
                if (dist < bestDist) { bestDist = dist; best = adj; }
            }
        }
        // 如果没有相邻空气，选最近的方向
        if (bestDist == Double.MAX_VALUE) {
            for (class_2350 d : class_2350.values()) {
                double dist = ore.method_10093(d).method_19770(eye);
                if (dist < bestDist) { bestDist = dist; best = ore.method_10093(d); }
            }
        }
        return best;
    }

    /* ==================== 阶段1: 水平隧道挖掘 ==================== */
    private void walkXZPhase() {
        if (wpIndex >= waypoints.size()) {
            // 水平路径走完, 判断垂直方向
            int pY = mc.field_1724.method_24515().method_10264();
            int tY = currentTarget.method_10264();
            if (tY > pY + 1) {
                phase = Phase.FLY_UP;
                enableFlight();
                return;
            }
            if (tY < pY - 1) {
                phase = Phase.DIG_DOWN;
                return;
            }
            // Y已对齐 → 直接挖矿
            phase = Phase.MINE_ORE;
            return;
        }

        class_2338 wp = waypoints.get(wpIndex);
        class_2338 feet = mc.field_1724.method_24515();

        // 是否已到达当前节点 (X/Z对齐)
        boolean atZ = feet.method_10260() == wp.method_10260();
        boolean atX = feet.method_10263() == wp.method_10263();
        if (atX && atZ) {
            wpIndex++;
            // 检查下一个节点是否安全
            if (wpIndex < waypoints.size() && isDangerZone(waypoints.get(wpIndex), feet.method_10264())) {
                planWaypoints();
                if (waypoints.isEmpty() || wpIndex >= waypoints.size()) {
                    blacklistAndNext("下一节点不安全");
                    return;
                }
                wpIndex = 0;
            }
            return;
        }

        // 此段是X方向还是Z方向
        boolean xSeg = wp.method_10263() != feet.method_10263() && wp.method_10260() == feet.method_10260();
        boolean zSeg = wp.method_10260() != feet.method_10260() && wp.method_10263() == feet.method_10263();

        if (!xSeg && !zSeg) {
            wpIndex++; return; // 意外情况, 跳过
        }

        int stepX = xSeg ? Integer.signum(wp.method_10263() - feet.method_10263()) : 0;
        int stepZ = zSeg ? Integer.signum(wp.method_10260() - feet.method_10260()) : 0;
        class_243 faceTarget = new class_243(feet.method_10263() + stepX + 0.5, feet.method_10264() + 0.5, feet.method_10260() + stepZ + 0.5);

        // 朝向目标方向
        face(faceTarget);

        // Wurst TunnelHack: 检查前进方向2格高方块
        class_2338 frontLow = feet.method_10069(stepX, 0, stepZ);
        class_2338 frontHigh = frontLow.method_10084();

        if (frontLow.method_10264() <= minY.get() || frontHigh.method_10264() <= minY.get()) {
            blacklistAndNext("到达最低Y层限制"); return;
        }

        // 找到需要挖掘的方块 (Wurst: dig box in front)
        List<class_2338> toDig = new ArrayList<>();
        if (isBlocking(mc.field_1687.method_8320(frontLow))) toDig.add(frontLow);
        if (isBlocking(mc.field_1687.method_8320(frontHigh))) toDig.add(frontHigh);

        // 安全检查: 下一步位置是否进入危险区
        boolean frontDanger = isDangerZone(frontLow, feet.method_10264());
        if (frontDanger) {
            // 是固体墙且危险 → 不挖, 重新规划
            if (isBlocking(mc.field_1687.method_8320(frontLow))) {
                blacklistBlock(frontLow);
            }
            planWaypoints();
            if (waypoints.isEmpty() || wpIndex >= waypoints.size()) {
                blacklistAndNext("路径进入危险区");
                return;
            }
            wpIndex = 0;
            mc.field_1690.field_1894.method_23481(false);
            return;
        }

        // Wurst: 如果已指定breakingPos, 继续挖它
        if (breakingPos != null) {
            toDig.clear();
            toDig.add(breakingPos);
        }

        if (!toDig.isEmpty()) {
            // 有方块需要挖 → 停止移动, 挖掘
            class_2338 dig = toDig.get(0); // 优先脚部再头部
            // 如果在挖第二个方块(top priority is the one closest)
            if (toDig.size() == 2) {
                double dLow = mc.field_1724.method_33571().method_1025(class_243.method_24953(frontLow));
                double dHigh = mc.field_1724.method_33571().method_1025(class_243.method_24953(frontHigh));
                dig = dLow < dHigh ? frontLow : frontHigh;
            }
            doDigBlock(dig);
        } else {
            // 无障碍 → 前进
            breakingPos = null;
            breakTicks = 0;
            mc.field_1761.method_2925();
            mc.field_1690.field_1894.method_23481(true);
        }
    }

    /* ==================== 阶段2A: 竖井上升 (挖掘头顶到矿石之间的所有方块) ==================== */
    private void flyUpPhase() {
        class_2338 feet = mc.field_1724.method_24515();
        int tY = currentTarget.method_10264();

        if (feet.method_10264() >= tY - 1) {
            disableFlight();
            phase = Phase.MINE_ORE;
            return;
        }

        // 挖掘从头顶到矿石之间的所有阻挡方块
        for (int dy = 1; dy <= (tY - feet.method_10264() + 1); dy++) {
            class_2338 check = new class_2338(feet.method_10263(), feet.method_10264() + dy, feet.method_10260());
            if (check.method_10264() <= minY.get()) { blacklistAndNext("到达最低Y层"); return; }
            if (isBlocking(mc.field_1687.method_8320(check))) {
                face(class_243.method_24953(check));
                doDigBlock(check);
                enableFlight(); // 飞行悬空挖掘
                return;
            }
        }

        // 无障碍 → 飞行上升
        enableFlight();
        class_243 vel = mc.field_1724.method_18798();
        mc.field_1724.method_18800(vel.field_1352, 0.5, vel.field_1350);
    }

    /* ==================== 阶段2B: 竖井下降 (挖掘脚底到矿石之间的所有方块) ==================== */
    private void digDownPhase() {
        class_2338 feet = mc.field_1724.method_24515();
        int tY = currentTarget.method_10264();

        if (feet.method_10264() <= tY + 1) {
            phase = Phase.MINE_ORE;
            return;
        }

        // 挖掘从脚底到矿石之间的所有阻挡方块
        for (int dy = 1; dy <= (feet.method_10264() - tY); dy++) {
            class_2338 check = new class_2338(feet.method_10263(), feet.method_10264() - dy, feet.method_10260());
            if (check.method_10264() <= minY.get()) { blacklistAndNext("到达最低Y层"); return; }
            if (isBlocking(mc.field_1687.method_8320(check))) {
                face(class_243.method_24953(check));
                doDigBlock(check);
                return;
            }
        }

        // 无障碍 → 走下一步
        mc.field_1690.field_1894.method_23481(true);
        mc.field_1690.field_1832.method_23481(true);
    }

    /* ==================== 阶段3: 挖掘矿石 ==================== */
    private void mineOrePhase() {
        class_2338 ore = currentTarget;
        if (ore == null) { phase = Phase.IDLE; return; }

        class_2680 s = mc.field_1687.method_8320(ore);
        if (!isTargetOre(s.method_26204()) || s.method_26215()) {
            // 矿石已消失
            lastOreMinedTime = System.currentTimeMillis();
            currentTarget = null; waypoints.clear(); wpIndex = 0;
            targetLockTime = 0;
            breakingPos = null; breakTicks = 0;
            mc.field_1761.method_2925();
            phase = Phase.RETURN_TO_TUNNEL;
            return;
        }

        // Wurst BlockBreaker: 如果已在挖掘同一矿石, 继续进度
        if (breakingPos != null && breakingPos.equals(ore)) {
            if (breakTicks++ > 200) { blacklistBlock(ore); breakingPos = null; breakTicks = 0; mc.field_1761.method_2925(); planWaypoints(); return; }
            mc.field_1761.method_2902(ore, bestFace(ore));
            face(class_243.method_24953(ore));
            return;
        }

        // 开始新挖掘
        face(class_243.method_24953(ore));
        switchToPick();
        doDigBlock(ore);
    }

    /* ==================== 阶段4: 返回隧道层 ==================== */
    private void returnToTunnelPhase() {
        int pY = mc.field_1724.method_24515().method_10264();

        if (Math.abs(pY - tunnelY) <= 1) {
            disableFlight();
            phase = Phase.IDLE;
            return;
        }

        if (pY < tunnelY) {
            // 需要上升 → 飞行
            enableFlight();
            class_243 vel = mc.field_1724.method_18798();
            mc.field_1724.method_18800(vel.field_1352, 0.5, vel.field_1350);
        } else {
            // 需要下降 → 走台阶(不飞行)
            disableFlight();
            class_2338 below = mc.field_1724.method_24515().method_10074();
            if (isBlocking(mc.field_1687.method_8320(below))) {
                face(class_243.method_24953(below));
                doDigBlock(below);
            } else {
                mc.field_1690.field_1894.method_23481(true);
            }
        }
    }

    /* ==================== 挖掘单个方块 (Wurst BlockBreaker 风格) ==================== */
    private void doDigBlock(class_2338 pos) {
        class_2680 s = mc.field_1687.method_8320(pos);
        if (s.method_26215() || isReplaceable(s) || isUnbreakable(s.method_26204()) || isFluid(s)) {
            breakingPos = null; breakTicks = 0;
            mc.field_1761.method_2925();
            return;
        }

        // 危险区预检: 不挖靠近流体的方块
        if (isDangerZone(pos, pos.method_10264())) {
            blacklistBlock(pos);
            breakingPos = null; breakTicks = 0;
            mc.field_1761.method_2925();
            waypoints.clear();
            planWaypoints();
            if (waypoints.size() > 0) wpIndex = 0;
            return;
        }

        // 切换挖掘目标时重置计数
        if (breakingPos != null && !breakingPos.equals(pos)) {
            breakTicks = 0;
            mc.field_1761.method_2925();
        }
        breakingPos = pos;
        dugPositions.put(pos, System.currentTimeMillis() + 60_000L); // 1分钟后过期
        face(class_243.method_24953(pos));
        switchToPick();

        // Wurst: 选择最佳面
        class_2350 bestSide = bestFace(pos);

        if (breakTicks > 300) {
            // 超时 → 跳过
            blacklistBlock(pos);
            breakingPos = null; breakTicks = 0;
            mc.field_1761.method_2925();
            waypoints.clear(); wpIndex = 0;
            planWaypoints();
            if (!waypoints.isEmpty()) wpIndex = 1;
            return;
        }

        // 首帧 attackBlock 发起挖掘, 后续帧 updateProgress 推进
        if (breakTicks == 0) {
            mc.field_1761.method_2910(pos, bestSide);
        }
        mc.field_1761.method_2902(pos, bestSide);
        mc.field_1724.method_6104(class_1268.field_5808);

        breakTicks++;
    }

    /* ==================== 卡住清理 ==================== */
    private void doClearing() {
        class_2338 pp = mc.field_1724.method_24515();
        List<class_2338> nearby = new ArrayList<>();
        int minYLev = minY.get();

        for (int dx = -1; dx <= 1; dx++)
            for (int dy = -1; dy <= 2; dy++)
                for (int dz = -1; dz <= 1; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    class_2338 pos = pp.method_10069(dx, dy, dz);
                    if (pos.method_10264() <= minYLev) continue;
                    class_2680 s = mc.field_1687.method_8320(pos);
                    if (!s.method_26215() && s.method_26204().method_36555() >= 0
                        && !isUnbreakable(s.method_26204()) && !isFluid(s))
                        nearby.add(pos);
                }

        if (nearby.isEmpty()) { isStuck = false; stuckTicks = 0; return; }

        nearby.sort(Comparator.comparingDouble(p -> p.method_19770(mc.field_1724.method_33571())));
        class_2338 dig = nearby.get(0);
        face(class_243.method_24953(dig));
        switchToPick();
        mc.field_1761.method_2902(dig, bestFace(dig));
        mc.field_1724.method_6104(class_1268.field_5808);

        // 挖掉后卡住重置
        if (mc.field_1687.method_8320(dig).method_26215()) { isStuck = false; stuckTicks = 0; }
    }

    /* ==================== 扫描 ==================== */
    private void scan() {
        class_1937 world = mc.field_1687;
        class_2338 pp = mc.field_1724.method_24515();
        int r = (int) Math.ceil(scanRange.get()), rSq = r * r;
        int minYLev = minY.get();
        boolean filterDanger = filterDangerOres.get();
        class_2339 m = new class_2339();
        for (int dx = -r; dx <= r; dx++) {
            int dx2 = dx * dx;
            for (int dy = -r; dy <= r; dy++) {
                int dxy2 = dx2 + dy * dy;
                if (dxy2 > rSq) continue;
                for (int dz = -r; dz <= r; dz++) {
                    if (dxy2 + dz * dz > rSq) continue;
                    m.method_10103(pp.method_10263() + dx, pp.method_10264() + dy, pp.method_10260() + dz);
                    if (m.method_10264() <= minYLev) continue;
                    if (abandonBlacklist.containsKey(m)) continue;
                    if (dugPositions.containsKey(m)) continue;
                    class_2680 s = world.method_8320(m);
                    if (!isTargetOre(s.method_26204())) continue;
                    if (s.method_26214(world, m) < 0) continue;
                    if (filterDanger && isOreNearFluid(m)) continue;
                    orePositions.add(m.method_10062());
                }
            }
        }
    }

    /** 检查矿物是否在流体安全距离内 */
    private boolean isOreNearFluid(class_2338 ore) {
        int safeR = safeDistance.get();
        for (int dx = -safeR; dx <= safeR; dx++)
            for (int dy = -safeR; dy <= safeR; dy++)
                for (int dz = -safeR; dz <= safeR; dz++) {
                    if (dx == 0 && dy == 0 && dz == 0) continue;
                    class_2338 check = ore.method_10069(dx, dy, dz);
                    if (isFluid(mc.field_1687.method_8320(check))) return true;
                }
        return false;
    }

    /* ==================== 矿石判定 ==================== */
    private boolean isTargetOre(class_2248 b) {
        if (b == class_2246.field_10418        || b == class_2246.field_29219)         return mineCoal.get();
        if (b == class_2246.field_10212        || b == class_2246.field_29027)         return mineIron.get();
        if (b == class_2246.field_27120      || b == class_2246.field_29221)       return mineCopper.get();
        if (b == class_2246.field_10571        || b == class_2246.field_29026)         return mineGold.get();
        if (b == class_2246.field_10080    || b == class_2246.field_29030)     return mineRedstone.get();
        if (b == class_2246.field_10090       || b == class_2246.field_29028)        return mineLapis.get();
        if (b == class_2246.field_10442     || b == class_2246.field_29029)      return mineDiamond.get();
        if (b == class_2246.field_10013     || b == class_2246.field_29220)      return mineEmerald.get();
        if (b == class_2246.field_10213) return mineNetherQuartz.get();
        if (b == class_2246.field_23077)   return mineNetherGold.get();
        if (b == class_2246.field_22109)     return mineAncientDebris.get();
        return false;
    }

    private boolean isUnbreakable(class_2248 b) {
        return b == class_2246.field_9987 || b == class_2246.field_10499 || b == class_2246.field_10525
            || b == class_2246.field_10395 || b == class_2246.field_10263
            || b == class_2246.field_10465 || b == class_2246.field_16540 || b == class_2246.field_10369;
    }

    /* ==================== 辅助 ==================== */
    private void face(class_243 t) {
        class_243 e = mc.field_1724.method_33571();
        double dx = t.field_1352 - e.field_1352, dy = t.field_1351 - e.field_1351, dz = t.field_1350 - e.field_1350;
        double h = Math.sqrt(dx * dx + dz * dz);
        mc.field_1724.method_36456((float) Math.toDegrees(Math.atan2(-dx, dz)));
        mc.field_1724.method_36457((float) -Math.toDegrees(Math.atan2(dy, h)));
    }

    /** Wurst: 选最佳攻击面 */
    private class_2350 bestFace(class_2338 pos) {
        class_243 eye = mc.field_1724.method_33571();
        class_243 c = class_243.method_24953(pos);
        class_243 d = c.method_1020(eye).method_1029();
        double best = -2; class_2350 r = class_2350.field_11036;
        for (class_2350 dir : class_2350.values()) {
            double dot = d.method_1026(class_243.method_24954(dir.method_62675()));
            if (dot > best) { best = dot; r = dir; }
        }
        return r;
    }

    private boolean isBlocking(class_2680 s) {
        if (s.method_26215() || s.method_45474() || isFluid(s)) return false;
        return s.method_51367() || s.method_26204().method_36555() >= 0;
    }

    private boolean isReplaceable(class_2680 s) {
        return s.method_45474() || s.method_26204() instanceof class_2521
            || s.method_26204() instanceof class_2356;
    }

    private boolean isFluid(class_2680 s) {
        return s.method_26227().method_15767(class_3486.field_15518) || s.method_26227().method_15767(class_3486.field_15517);
    }

    private void blacklistAndNext(String reason) {
        if (currentTarget != null) {
            blacklistWithNeighbors(currentTarget);
            orePositions.remove(currentTarget);
        }
        currentTarget = null; waypoints.clear(); wpIndex = 0; phase = Phase.IDLE;
        targetLockTime = 0;
        breakingPos = null; breakTicks = 0;
        returnIfFlying();
        if (chatInfo.get()) notify(reason + ", 黑名单3分钟");
    }

    private void blacklistBlock(class_2338 pos) {
        abandonBlacklist.put(pos, System.currentTimeMillis() + 180_000L);
    }

    private void blacklistWithNeighbors(class_2338 center) {
        long expire = System.currentTimeMillis() + 180_000L;
        for (int dx = -2; dx <= 2; dx++)
            for (int dy = -2; dy <= 2; dy++)
                for (int dz = -2; dz <= 2; dz++) {
                    if (Math.abs(dx) + Math.abs(dy) + Math.abs(dz) > 2) continue;
                    class_2338 pos = center.method_10069(dx, dy, dz);
                    if (orePositions.contains(pos)) abandonBlacklist.put(pos, expire);
                }
    }

    private void enableFlight() {
        mc.field_1724.method_31549().field_7479 = true;
        mc.field_1724.method_31549().field_7478 = true;
    }

    private void disableFlight() {
        if (!wasFlying) {
            mc.field_1724.method_31549().field_7479 = false;
            mc.field_1724.method_31549().field_7478 = false;
        }
    }

    private void returnIfFlying() {
        if (phase == Phase.FLY_UP || phase == Phase.RETURN_TO_TUNNEL) phase = Phase.RETURN_TO_TUNNEL;
    }

    private void notify(String msg) {
        if (mc.field_1724 != null)
            mc.field_1724.method_7353(net.minecraft.class_2561.method_43470("§8[§6矿物追踪§8] §f" + msg), true);
    }

    private void releaseControls() {
        mc.field_1690.field_1894.method_23481(false); mc.field_1690.field_1881.method_23481(false);
        mc.field_1690.field_1913.method_23481(false); mc.field_1690.field_1849.method_23481(false);
        mc.field_1690.field_1903.method_23481(false); mc.field_1690.field_1832.method_23481(false);
        mc.field_1690.field_1886.method_23481(false);
    }

    /* ==================== 工具切换 (Wurst AutoTool) ==================== */
    private void switchToPick() {
        if (isPickaxe(mc.field_1724.method_6047().method_7909())) return;
        for (int i = 0; i < 9; i++)
            if (isPickaxe(mc.field_1724.method_31548().method_5438(i).method_7909())) {
                setSelectedSlot(mc.field_1724.method_31548(), i);
                return;
            }
    }

    private void setSelectedSlot(class_1661 inv, int slot) {
        try {
            if (selectedSlotField == null) {
                selectedSlotField = class_1661.class.getDeclaredField("selectedSlot");
                selectedSlotField.setAccessible(true);
            }
            selectedSlotField.setInt(inv, slot);
        } catch (Exception ignored) {}
    }

    private boolean isPickaxe(class_1792 i) {
        return i == class_1802.field_8647 || i == class_1802.field_8387 || i == class_1802.field_8403
            || i == class_1802.field_8335 || i == class_1802.field_8377 || i == class_1802.field_22024;
    }

    /* ==================== 渲染 ==================== */
    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (mc.field_1687 == null) return;

        // 所有矿石
        if (renderOres.get())
            for (class_2338 p : orePositions)
                if (isTargetOre(mc.field_1687.method_8320(p).method_26204()))
                    event.renderer.box(p, oreColor.get(), oreColor.get(), ShapeMode.Both, 0);

        // 当前目标
        if (currentTarget != null && isTargetOre(mc.field_1687.method_8320(currentTarget).method_26204()))
            event.renderer.box(currentTarget, targetColor.get(), targetColor.get(), ShapeMode.Both, 0);

        // 路径节点
        if (!waypoints.isEmpty()) {
            for (int i = wpIndex; i < waypoints.size(); i++) {
                class_2338 p = waypoints.get(i);
                event.renderer.box(p, pathColor.get(), pathColor.get(), ShapeMode.Lines, 0);
                if (i > 0) {
                    class_243 a = class_243.method_24953(waypoints.get(i - 1));
                    class_243 b = class_243.method_24953(p);
                    event.renderer.line(a.field_1352, a.field_1351, a.field_1350, b.field_1352, b.field_1351, b.field_1350, pathColor.get());
                }
            }
        }
    }
}
