package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import com.macekill.addon.modules.macekill.Inventory;
import com.macekill.addon.modules.macekill.Movement;
import com.macekill.addon.modules.macekill.Targeting;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_243;

/**
 * 新TP重锤 — xintpmace
 *
 * 逻辑：
 * Tick 中找最近目标 → 预测位置 → 分步传送到目标旁 → VClip起跳 → 多高度攻击 → 返回
 * 简洁版，无破甲/图腾绕过等复杂逻辑
 */
public class XinTpMace extends Module {

    private final SettingGroup sgMain = settings.getDefaultGroup();

    private final Setting<Double> range = sgMain.add(new DoubleSetting.Builder()
            .name("范围").description("目标检测范围")
            .defaultValue(20.0).min(1.0).max(200.0).sliderRange(1.0, 128.0).build());

    private final Setting<Integer> predictTicks = sgMain.add(new IntSetting.Builder()
            .name("预测tick").description("预测未来位置的tick数")
            .defaultValue(5).min(1).sliderMax(20).build());

    private final Setting<Double> maxStep = sgMain.add(new DoubleSetting.Builder()
            .name("最大步长").description("传送分段步长")
            .defaultValue(8.0).min(1.0).max(128.0).sliderRange(1.0, 128.0).build());

    private final Setting<Integer> cooldown = sgMain.add(new IntSetting.Builder()
            .name("冷却").description("攻击冷却(tick)")
            .defaultValue(10).min(0).max(40).sliderMax(40).build());

    private final Setting<List<String>> heights = sgMain.add(new StringListSetting.Builder()
            .name("高度列表").description("VClip攻击使用的高度列表")
            .defaultValue("10", "20", "30").build());

    private final Setting<Boolean> swingHand = sgMain.add(new BoolSetting.Builder()
            .name("挥手").description("攻击时挥手").defaultValue(false).build());

    private final Setting<Boolean> onlyPlayers = sgMain.add(new BoolSetting.Builder()
            .name("仅玩家").description("仅攻击玩家").defaultValue(true).build());

    // 状态
    private int cooldownTicks;
    private class_243 originalPos;

    public XinTpMace() {
        super(MaceKillAddon.CATEGORY, "xintpmace", "新TP重锤 - 预测传送+多高度VClip攻击");
    }

    @Override
    public void onDeactivate() {
        cooldownTicks = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null) return;

        if (cooldownTicks > 0) { cooldownTicks--; return; }

        class_1309 target = findTarget();
        if (target == null) return;

        originalPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        class_243 predicted = Targeting.predictPosition(mc, target, true, predictTicks.get());

        int oldSlot = Inventory.switchToMace(mc);
        if (oldSlot == -1) return;

        try {
            // 传送到目标旁
            Movement.doTpTo(mc, predicted, maxStep.get(), false);

            // 多高度VClip攻击
            for (String hStr : heights.get()) {
                double h;
                try { h = Double.parseDouble(hStr.trim()); }
                catch (NumberFormatException e) { continue; }
                if (h <= 0) continue;

                // VClip 起跳
                class_243 current = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
                class_243 jumpPos = new class_243(predicted.field_1352, predicted.field_1351 + h, predicted.field_1350);
                Movement.doTpTo(mc, jumpPos, maxStep.get(), false);

                // 下落并攻击
                class_243 attackPos = new class_243(predicted.field_1352, predicted.field_1351 + 0.5, predicted.field_1350);
                Movement.sendMovePacket(mc, attackPos.field_1352, attackPos.field_1351, attackPos.field_1350);

                if (swingHand.get()) mc.field_1724.method_6104(class_1268.field_5808);
                Movement.attackEntity(mc, target);
            }
        } finally {
            Inventory.switchBack(mc, oldSlot);
        }

        // 返回原位
        if (originalPos != null) {
            Movement.doTpTo(mc, originalPos, maxStep.get(), false);
        }

        cooldownTicks = cooldown.get();
    }

    private class_1309 findTarget() {
        if (mc.field_1687 == null || mc.field_1724 == null) return null;
        double rangeSq = range.get() * range.get();
        class_1309 best = null;
        double bestDist = Double.MAX_VALUE;

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1309 le) || !le.method_5805() || le == mc.field_1724) continue;
            double distSq = mc.field_1724.method_5858(le);
            if (distSq > rangeSq) continue;
            if (onlyPlayers.get() && !(le instanceof class_1657)) continue;
            if (le instanceof class_1657 p) {
                if (p.method_68878() || p.method_7325() || !Friends.get().shouldAttack(p)) continue;
            }
            if (distSq < bestDist) { bestDist = distSq; best = le; }
        }
        return best;
    }

    @Override
    public String getInfoString() {
        if (cooldownTicks > 0) return "CD " + cooldownTicks;
        return "就绪";
    }
}
