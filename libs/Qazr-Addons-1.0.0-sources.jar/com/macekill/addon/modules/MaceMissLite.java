package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import com.macekill.addon.modules.macekill.Combat;
import com.macekill.addon.modules.macekill.Inventory;
import com.macekill.addon.modules.macekill.Movement;
import com.macekill.addon.modules.macekill.SortPriority;
import com.macekill.addon.modules.macekill.Targeting;
import java.util.*;
import java.util.function.Predicate;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;

/**
 * 重锤导弹精简版 — MaceMissLite
 *
 * 核心特性：
 * - 强制忽略按键：按住跳过当前目标
 * - dv1/dv2 双偏移值控制攻击角度
 * - 破甲模式 + 击杀模式双路攻击流程
 * - 预测位置/碰撞箱
 * - 毫秒计时器
 * - 渲染方块框
 */
public class MaceMissLite extends Module {

    /* ========== MSTimer — 毫秒级计时器 ========== */
    private static class MSTimer {
        private long lastMS;
        boolean hasPassed(long ms) {
            return System.currentTimeMillis() - lastMS >= ms;
        }
        void reset() { lastMS = System.currentTimeMillis(); }
    }

    /* ========== 设置 ========== */
    private final SettingGroup sgMain = settings.getDefaultGroup();
    private final SettingGroup sgTarget = settings.createGroup("目标");
    private final SettingGroup sgArmor = settings.createGroup("破甲");

    // 通用
    private final Setting<Double> range = sgMain.add(new DoubleSetting.Builder()
            .name("范围").description("检测范围")
            .defaultValue(20.0).min(1.0).max(200.0).sliderRange(1.0, 128.0).build());

    private final Setting<Double> moveDistance = sgMain.add(new DoubleSetting.Builder()
            .name("移动步长").description("每个移动包的最大距离")
            .defaultValue(8.0).min(1.0).max(128.0).sliderRange(1.0, 128.0).build());

    private final Setting<List<String>> killHeights = sgMain.add(new StringListSetting.Builder()
            .name("击杀高度").description("击杀攻击使用的高度列表")
            .defaultValue("10", "20", "30").build());

    private final Setting<Integer> attackDelay = sgMain.add(new IntSetting.Builder()
            .name("攻击延迟").description("攻击间隔(tick)")
            .defaultValue(10).min(0).max(40).sliderMax(40).build());

    private final Setting<Boolean> predict = sgMain.add(new BoolSetting.Builder()
            .name("预测位置").description("预测目标未来位置").defaultValue(true).build());

    private final Setting<Integer> predictTicks = sgMain.add(new IntSetting.Builder()
            .name("预测tick").description("预测tick数")
            .defaultValue(5).min(1).sliderMax(20).visible(predict::get).build());

    // dv偏移
    private final Setting<Double> dv1 = sgMain.add(new DoubleSetting.Builder()
            .name("偏移dv1").description("第一次攻击的水平偏移")
            .defaultValue(0.0).min(0).max(10).sliderMax(5).build());

    private final Setting<Double> dv2 = sgMain.add(new DoubleSetting.Builder()
            .name("偏移dv2").description("第二次攻击的水平偏移")
            .defaultValue(0.0).min(0).max(10).sliderMax(5).build());

    private final Setting<Boolean> swingHand = sgMain.add(new BoolSetting.Builder()
            .name("挥手").description("攻击时挥手").defaultValue(false).build());

    // 强制忽略
    private final Setting<Boolean> forceIgnore = sgMain.add(new BoolSetting.Builder()
            .name("强制忽略").description("启用以跳过当前目标").defaultValue(false).build());

    // 目标
    private final Setting<Boolean> targetPlayers = sgTarget.add(new BoolSetting.Builder()
            .name("玩家").description("攻击玩家").defaultValue(true).build());

    private final Setting<Boolean> targetHostiles = sgTarget.add(new BoolSetting.Builder()
            .name("敌对生物").description("攻击敌对生物").defaultValue(true).build());

    private final Setting<Boolean> targetAnimals = sgTarget.add(new BoolSetting.Builder()
            .name("动物").description("攻击动物").defaultValue(true).build());

    private final Setting<SortPriority> sortPriority = sgTarget.add(new EnumSetting.Builder<SortPriority>()
            .name("排序方式").description("目标排序方式")
            .defaultValue(SortPriority.DISTANCE).build());

    // 破甲
    private final Setting<Boolean> destroyArmor = sgArmor.add(new BoolSetting.Builder()
            .name("破甲").description("先破甲再击杀").defaultValue(false).build());

    private final Setting<Integer> ignoreValue = sgArmor.add(new IntSetting.Builder()
            .name("破甲阈值").description("目标剩余护甲≤此值时改用击杀")
            .defaultValue(0).min(0).max(4).sliderMax(4)
            .visible(destroyArmor::get).build());

    private final Setting<List<String>> destroyHeights = sgArmor.add(new StringListSetting.Builder()
            .name("破甲高度").description("破甲攻击使用的高度")
            .defaultValue("30", "60").visible(destroyArmor::get).build());

    // 渲染
    private final Setting<Boolean> renderBox = sgMain.add(new BoolSetting.Builder()
            .name("渲染方块").description("渲染目标方块框").defaultValue(true).build());

    private final Setting<SettingColor> boxColor = sgMain.add(new ColorSetting.Builder()
            .name("方块颜色").description("渲染颜色")
            .defaultValue(new SettingColor(255, 0, 0, 100)).build());

    /* ========== 状态 ========== */
    private final MSTimer attackTimer = new MSTimer();
    private class_1309 currentTarget;
    private int attackIndex;
    private int delayTicks;
    private Phase phase = Phase.IDLE;
    private class_243 originalPos;

    private enum Phase { IDLE, DELAY }

    public MaceMissLite() {
        super(MaceKillAddon.CATEGORY, "MaceMissLite", "重锤导弹精简版 - 双偏移+强制忽略+破甲");
    }

    @Override
    public void onDeactivate() {
        currentTarget = null;
        attackIndex = 0;
        delayTicks = 0;
        phase = Phase.IDLE;
    }

    /* ========== Tick ========== */

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        switch (phase) {
            case IDLE -> {
                if (delayTicks > 0) { delayTicks--; return; }
                tickIdle();
            }
            case DELAY -> {
                delayTicks--;
                if (delayTicks <= 0) {
                    phase = Phase.IDLE;
                    attackIndex = 0;
                }
            }
        }
    }

    private void tickIdle() {
        updateTarget();
        if (currentTarget == null) return;
        if (isAboutToBeIgnored()) {
            currentTarget = null;
            return;
        }
        doAura();
        delayTicks = attackDelay.get();
        phase = Phase.DELAY;
    }

    // ========== 目标更新 ==========

    private void updateTarget() {
        List<class_1309> validTargets = new ArrayList<>();
        double rangeSq = range.get() * range.get();

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1309 le) || !le.method_5805() || le == mc.field_1724) continue;
            if (mc.field_1724.method_5858(le) > rangeSq) continue;
            if (!targetCheck(le)) continue;
            validTargets.add(le);
        }

        if (validTargets.isEmpty()) { currentTarget = null; return; }

        validTargets.sort((a, b) -> switch (sortPriority.get()) {
            case DISTANCE ->
                Double.compare(mc.field_1724.method_5858(a), mc.field_1724.method_5858(b));
            case HEALTH ->
                Float.compare(a.method_6032(), b.method_6032());
            case ANGLE -> {
                class_243 look = mc.field_1724.method_5828(1.0f);
                class_243 eye = mc.field_1724.method_33571();
                double aDot = look.method_1026(a.method_33571().method_1020(eye).method_1029());
                double bDot = look.method_1026(b.method_33571().method_1020(eye).method_1029());
                yield Double.compare(bDot, aDot);
            }
        });
        currentTarget = validTargets.get(0);
    }

    private boolean targetCheck(class_1309 entity) {
        if (entity instanceof class_1657 p) {
            if (p.method_68878() || p.method_7325() || !Friends.get().shouldAttack(p)) return false;
            return targetPlayers.get();
        }
        if (entity instanceof class_1588) return targetHostiles.get();
        if (entity instanceof class_1429) return targetAnimals.get();
        return false;
    }

    // ========== 攻击流程 ==========

    private void doAura() {
        if (currentTarget == null || mc.method_1562() == null) return;

        originalPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());

        if (destroyArmor.get() && currentTarget instanceof class_1657 p && !isNaked(p)) {
            doDestroyArmor();
        } else {
            doTpAura(killHeights.get());
        }
    }

    private void doDestroyArmor() {
        doTpAura(destroyHeights.get());
    }

    private void doTpAura(List<String> rawHeights) {
        List<Double> heights = Combat.parseHeights(rawHeights);
        if (heights.isEmpty()) heights.add(20.0);

        int oldSlot = Inventory.switchToMace(mc);
        if (oldSlot == -1) return;

        try {
            class_243 targetPos = Targeting.predictPosition(mc, currentTarget, predict.get(), predictTicks.get());
            class_243 basePos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());

            for (int i = 0; i < heights.size(); i++) {
                double h = heights.get(i);
                // 应用 dv 偏移
                if (i == 0 && dv1.get() > 0) targetPos = applyDv(targetPos, dv1.get());
                if (i == 1 && dv2.get() > 0) targetPos = applyDv(targetPos, dv2.get());

                class_2338 vclipHole = Combat.findVclipHole(mc,
                        mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), h);
                class_243 vclipPos = class_243.method_24955(vclipHole);

                Movement.doTpTo(mc, vclipPos, moveDistance.get(), false);
                Movement.sendMovePacket(mc, targetPos.field_1352, targetPos.field_1351 + 0.5, targetPos.field_1350);
                Movement.sendMovePacket(mc, basePos.field_1352, basePos.field_1351, basePos.field_1350);

                if (swingHand.get()) mc.field_1724.method_6104(class_1268.field_5808);
                Movement.attackEntity(mc, currentTarget);
            }
        } finally {
            Inventory.switchBack(mc, oldSlot);
        }
    }

    private class_243 applyDv(class_243 pos, double offset) {
        double angle = Math.random() * Math.PI * 2;
        return new class_243(
                pos.field_1352 + Math.cos(angle) * offset,
                pos.field_1351,
                pos.field_1350 + Math.sin(angle) * offset);
    }

    // ========== 判定 ==========

    private boolean isAboutToBeIgnored() {
        return forceIgnore.get();
    }

    private boolean isNaked(class_1657 player) {
        return Combat.needsArmorDestroy(player, ignoreValue.get()) == false;
        // needsArmorDestroy returns count > ignoreValue → 需要破甲
        // 所以 !needsArmorDestroy = 护甲 <= ignoreValue = 已经破甲 → isNaked
    }

    // ========== 渲染 ==========

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (!renderBox.get() || currentTarget == null) return;
        class_238 box = currentTarget.method_5829();
        event.renderer.box(box, boxColor.get(), boxColor.get(), ShapeMode.Both, 0);
    }

    @Override
    public String getInfoString() {
        if (currentTarget == null) return "无目标";
        if (phase == Phase.DELAY) return "CD " + delayTicks;
        String name = currentTarget instanceof class_1657 p ? p.method_5477().getString()
                : currentTarget.method_5864().method_5897().getString();
        return name;
    }
}
