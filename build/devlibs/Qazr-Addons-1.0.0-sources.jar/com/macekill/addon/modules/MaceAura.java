package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import com.macekill.addon.modules.macekill.Combat;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.block.BlockState;
import net.minecraft.block.Blocks;
import net.minecraft.entity.Entity;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.PlayerInteractEntityC2SPacket;
import net.minecraft.network.packet.c2s.play.PlayerMoveC2SPacket;
import net.minecraft.network.packet.c2s.play.UpdateSelectedSlotC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.BlockPos;
import net.minecraft.util.math.Vec3d;

import java.lang.reflect.Field;
import java.util.*;

/**
 * 重锤光环 — MaceAura
 *
 * 核心特性：
 * - 位置缓存 (Map<BlockPos, Boolean>) 避免重复计算
 * - 图腾绕过：多次小高度攻击消耗图腾后再用完整高度击杀
 * - 偏移攻击：水平/垂直偏移，不精确站在目标头顶
 * - 高度递增：每次攻击递增高度，生成不同落点
 * - 垃圾包：每个高度发送多个移动包扰乱反作弊
 * - BlockPos.Mutable：减少 GC 压力
 */
public class MaceAura extends Module {
    private static Field selectedSlotField;
    private int maceSwapBackSlot = -1;

    /* ========== 设置 ========== */
    private final SettingGroup sgMain = settings.getDefaultGroup();
    private final SettingGroup sgTotem = settings.createGroup("Totem Bypass");
    private final SettingGroup sgOffset = settings.createGroup("Offset");

    private final Setting<Double> range = sgMain.add(new DoubleSetting.Builder()
            .name("Range").description("Target detection range")
            .defaultValue(20.0).min(1.0).max(200.0).sliderRange(1.0, 128.0).build());

    private final Setting<Boolean> onlyPlayers = sgMain.add(new BoolSetting.Builder()
            .name("Players Only").description("Only attack players").defaultValue(true).build());

    private final Setting<Boolean> swingArm = sgMain.add(new BoolSetting.Builder()
            .name("Swing Arm").description("Swing arm when attacking").defaultValue(false).build());

    private final Setting<Integer> fallHeight = sgMain.add(new IntSetting.Builder()
            .name("Attack Height").description("Base fall height")
            .defaultValue(30).min(1).max(170).sliderRange(1, 170).build());

    private final Setting<Integer> spamPackets = sgMain.add(new IntSetting.Builder()
            .name("Spam Packets").description("Extra move packets sent per height")
            .defaultValue(2).min(0).max(20).sliderMax(10).build());

    private final Setting<Integer> attackDelay = sgMain.add(new IntSetting.Builder()
            .name("Attack Delay").description("Attack interval in ticks")
            .defaultValue(10).min(0).max(40).sliderMax(40).build());

    private final Setting<Boolean> useOffset = sgOffset.add(new BoolSetting.Builder()
            .name("Use Offset").description("Don't land exactly above the target").defaultValue(false).build());

    private final Setting<Double> horizontalOffset = sgOffset.add(new DoubleSetting.Builder()
            .name("Horizontal Offset").description("Horizontal offset amount")
            .defaultValue(1.5).min(0).max(10).sliderMax(5)
            .visible(useOffset::get).build());

    private final Setting<Double> yOffset = sgOffset.add(new DoubleSetting.Builder()
            .name("Vertical Offset").description("Extra vertical height offset")
            .defaultValue(0.5).min(0).max(5).sliderMax(5)
            .visible(useOffset::get).build());

    private final Setting<Boolean> bypassTotem = sgTotem.add(new BoolSetting.Builder()
            .name("Totem Bypass").description("Drain totems with escalating-height hits and kill - all hits fire in ONE smash (required to beat AutoTotem)").defaultValue(false).build());

    private final Setting<Integer> attackCount = sgTotem.add(new IntSetting.Builder()
            .name("Totem Attacks").description("How many escalating hits to fire in the single smash (use >= 2 to oneshot AutoTotem)")
            .defaultValue(3).min(1).max(198).sliderMax(198)
            .visible(bypassTotem::get).build());

    private final Setting<Integer> heightIncrement = sgTotem.add(new IntSetting.Builder()
            .name("Height Increment").description("Height added per hit (must be > 0 so each hit deals strictly more damage, bypassing invulnerability)")
            .defaultValue(2).min(1).max(50).sliderMax(50)
            .visible(bypassTotem::get).build());

    /* ========== 状态 ========== */
    private final Map<BlockPos, Boolean> positionCache = new HashMap<>();
    private final BlockPos.Mutable mutablePos = new BlockPos.Mutable();
    private int remainingCooldown;
    private int totemAttackIndex;

    public MaceAura() {
        super(MaceKillAddon.CATEGORY, "MaceAura", "Mace aura - auto attack with totem bypass+offsets+position caching");
    }

    @Override
    public void onActivate() {
        remainingCooldown = 0;
        totemAttackIndex = 0;
        positionCache.clear();
    }

    @Override
    public void onDeactivate() {
        positionCache.clear();
    }

    /* ========== Tick ========== */

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.player == null || mc.world == null) return;
        if (remainingCooldown > 0) { remainingCooldown--; return; }

        LivingEntity target = findNearestTarget();
        if (target == null) return;

        boolean killed = executeAttack(target);
        if (killed) {
            totemAttackIndex = 0;
            positionCache.clear();
        }

        remainingCooldown = attackDelay.get();
    }

    // ========== 目标查找 ==========

    private LivingEntity findNearestTarget() {
        if (mc.world == null || mc.player == null) return null;
        double rangeSq = range.get() * range.get();
        LivingEntity best = null;
        double bestDist = Double.MAX_VALUE;

        for (Entity e : mc.world.getEntities()) {
            if (!(e instanceof LivingEntity le) || !le.isAlive() || le == mc.player) continue;
            double distSq = mc.player.squaredDistanceTo(le);
            if (distSq > rangeSq) continue;
            if (onlyPlayers.get() && !(le instanceof PlayerEntity)) continue;
            if (le instanceof PlayerEntity p) {
                if (p.isCreative() || p.isSpectator() || !Friends.get().shouldAttack(p)) continue;
            }
            if (distSq < bestDist) { bestDist = distSq; best = le; }
        }
        return best;
    }

    // ========== 攻击执行 ==========

    private boolean executeAttack(LivingEntity target) {
        if (mc.getNetworkHandler() == null) return false;

        // 切换到重锤
        int oldSlot = switchToMace();
        if (oldSlot == -1) return false;

        try {
            Vec3d originalPos = new Vec3d(mc.player.getX(), mc.player.getY(), mc.player.getZ());

            if (bypassTotem.get() && target instanceof PlayerEntity) {
                // 图腾绕过：多轮递增高度攻击
                return executeTotemBypass(target, originalPos);
            } else {
                // 正常击杀
                return executeKill(target, originalPos, fallHeight.get());
            }
        } finally {
            switchBack(oldSlot);
        }
    }

    private boolean executeTotemBypass(LivingEntity target, Vec3d originalPos) {
        int count = attackCount.get();

        // AutoTotem re-equips between ticks, so every strictly-escalating hit MUST land in a
        // single smash (one executeTotemBypass call). Spread the heights across the REAL
        // headroom above the target so each hit deals strictly more damage (critical in caves
        // / under a roof - otherwise they all collapse onto the ceiling and only pop one totem).
        int clearance = getMaxHeightAbovePlayer(new Vec3d(target.getX(), target.getY(), target.getZ()), 319);
        List<String> all = Combat.totemBypassHeights(count - 1, clearance);
        if (all.isEmpty()) {
            error("Not enough headroom above target for a mace smash (need open space / taller cave)");
            return false;
        } else if (all.size() < count) {
            error("Limited headroom - can only pop ~%d totems here", all.size() - 1);
        }
        for (String s : all) {
            try {
                int h = Integer.parseInt(s.trim());
                doSingleAttack(target, originalPos, h);
            } catch (NumberFormatException ignored) {}
        }
        return true;
    }

    private boolean executeKill(LivingEntity target, Vec3d originalPos, int height) {
        return doSingleAttack(target, originalPos, height);
    }

    private boolean doSingleAttack(LivingEntity target, Vec3d originalPos, int height) {
        if (mc.getNetworkHandler() == null) return false;

        Vec3d targetPos = new Vec3d(target.getX(), target.getY(), target.getZ());
        if (useOffset.get()) {
            targetPos = getOffset(targetPos);
        }

        // 计算安全起跳高度
        int safeHeight = getMaxHeightAbovePlayer(targetPos, height);
        if (safeHeight < 2) {
            return false; // 头顶是实心屋顶、没有起跳空间 -> 不攻击，避免卡在天上
        }
        Vec3d jumpPos = new Vec3d(targetPos.x, targetPos.y + safeHeight, targetPos.z);

        // 升空 + 发垃圾包
        sendMovePacketWithSpam(new Vec3d(mc.player.getX(), mc.player.getY(), mc.player.getZ()), jumpPos);

        // 下落
        Vec3d attackPos = new Vec3d(targetPos.x, targetPos.y + 0.5, targetPos.z);
        sendMovePacketWithSpam(jumpPos, attackPos);

        if (swingArm.get()) mc.player.swingHand(Hand.MAIN_HAND);
        attackEntity(target);

        return true;
    }

    // ========== 位置计算 ==========

    /** 获取偏移后的位置 */
    private Vec3d getOffset(Vec3d pos) {
        double hOff = horizontalOffset.get();
        double yOff = yOffset.get();
        // 随机水平方向
        double angle = Math.random() * Math.PI * 2;
        return new Vec3d(
                pos.x + Math.cos(angle) * hOff,
                pos.y + yOff,
                pos.z + Math.sin(angle) * hOff);
    }

    /** 计算目标上方最大安全高度（从目标向上扫描，遇到实心屋顶即停，绝不穿顶到屋外天空） */
    private int getMaxHeightAbovePlayer(Vec3d targetPos, int maxHeight) {
        int bx = (int) Math.floor(targetPos.x);
        int bz = (int) Math.floor(targetPos.z);
        int by = (int) Math.floor(targetPos.y);
        int top = by + maxHeight;
        top = Math.min(top, 319);

        for (int cy = by + 1; cy <= top; cy++) {
            mutablePos.set(bx, cy, bz);
            if (!isSafePosition(mutablePos)) {
                // 屋顶：取屋顶下方连通的空气（需要 2 格空气）
                if (cy - 1 <= by) return 0;
                mutablePos.set(bx, cy - 1, bz);
                if (!isSafePosition(mutablePos)) return 0;
                return cy - 1 - by;
            }
        }
        return top - by;
    }

    private boolean isSafePosition(BlockPos pos) {
        return positionCache.computeIfAbsent(pos.toImmutable(), p -> {
            BlockState state = mc.world.getBlockState(p);
            // 空气或树叶（可穿过树叶升到树冠上方的天空）才视为安全；液体/蛛网/实心方块不安全
            return (state.isAir() || state.getBlock() instanceof net.minecraft.block.LeavesBlock)
                    && state.getFluidState().isEmpty()
                    && !state.isOf(Blocks.COBWEB);
        });
    }

    // ========== 发包 ==========

    private void sendMovePacketWithSpam(Vec3d from, Vec3d to) {
        double dist = from.distanceTo(to);
        int steps = Math.max(1, (int) Math.ceil(dist / 8.0));
        double stepX = (to.x - from.x) / steps;
        double stepY = (to.y - from.y) / steps;
        double stepZ = (to.z - from.z) / steps;

        int spam = spamPackets.get();
        for (int i = 1; i <= steps; i++) {
            double x = from.x + stepX * i;
            double y = from.y + stepY * i;
            double z = from.z + stepZ * i;
            mc.getNetworkHandler().sendPacket(
                    new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, false));
            // 发垃圾包
            for (int s = 0; s < spam; s++) {
                mc.getNetworkHandler().sendPacket(
                        new PlayerMoveC2SPacket.PositionAndOnGround(x, y, z, false, false));
            }
        }
    }

    private void attackEntity(Entity target) {
        if (mc.getNetworkHandler() == null) return;
        mc.getNetworkHandler().sendPacket(
                PlayerInteractEntityC2SPacket.attack(target, mc.player.isSneaking()));
    }

    // ========== 物品切换 ==========

    private int switchToMace() {
        if (mc.player == null) return -1;
        PlayerInventory inv = mc.player.getInventory();
        int cur = getSelectedSlot();
        maceSwapBackSlot = -1;
        if (inv.getStack(cur).getItem() == Items.MACE) return cur;
        for (int i = 0; i < 9; i++) {
            if (inv.getStack(i).getItem() != Items.MACE) continue;
            if (i != cur) {
                setSelectedSlot(i);
                mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(i));
            }
            return cur;
        }
        // Mace in the main inventory / offhand -> move it into the selected hotbar slot.
        FindItemResult mace = InvUtils.find(Items.MACE);
        if (mace.found()) {
            int src = mace.slot();
            InvUtils.move().from(src).to(cur);
            maceSwapBackSlot = src;
        }
        return cur;
    }

    private void switchBack(int slot) {
        if (slot < 0 || slot >= 9) return;
        if (maceSwapBackSlot >= 0) {
            InvUtils.move().from(slot).to(maceSwapBackSlot);
            maceSwapBackSlot = -1;
            return;
        }
        setSelectedSlot(slot);
        mc.getNetworkHandler().sendPacket(new UpdateSelectedSlotC2SPacket(slot));
    }

    private int getSelectedSlot() {
        try {
            if (selectedSlotField == null) {
                selectedSlotField = PlayerInventory.class.getDeclaredField("selectedSlot");
                selectedSlotField.setAccessible(true);
            }
            return selectedSlotField.getInt(mc.player.getInventory());
        } catch (Exception e) { return 0; }
    }

    private void setSelectedSlot(int slot) {
        try {
            if (selectedSlotField == null) {
                selectedSlotField = PlayerInventory.class.getDeclaredField("selectedSlot");
                selectedSlotField.setAccessible(true);
            }
            selectedSlotField.setInt(mc.player.getInventory(), slot);
        } catch (Exception ignored) {}
    }

    @Override
    public String getInfoString() {
        if (remainingCooldown > 0) return "CD " + remainingCooldown;
        return bypassTotem.get() ? "Totem Bypass" : "Ready";
    }
}
