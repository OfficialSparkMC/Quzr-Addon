package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_2885;
import net.minecraft.class_3965;
import net.minecraft.network.packet.c2s.play.*;
import java.lang.reflect.Field;
import java.util.*;

/**
 * 潜影盒刷取 - Qazr 风格快速循环放置/挖掘潜影盒
 *
 * 逻辑：
 * 1. 激活时记录准星指向方块的上方作为操作位置
 * 2. 每 tick 高速检测：
 *    - 空气/可替换 → 切潜影盒 → 放置
 *    - 潜影盒方块 → 切镐子 → 瞬间挖掘
 * 3. 镐子优先选择耐久高于阈值的，潜影盒循环替换到槽位
 * 4. 槽位切换纯反射（Qazr 风格），无 UpdateSelectedSlot 包
 */
public class AutoShulkerBox extends Module {

    /* ==================== 潜影盒全17种变体 ==================== */
    private static final Set<class_2248> SHULKER_BOX_BLOCKS = Set.of(
            class_2246.field_10603,
            class_2246.field_10199, class_2246.field_10407,
            class_2246.field_10063, class_2246.field_10203,
            class_2246.field_10600, class_2246.field_10275,
            class_2246.field_10051, class_2246.field_10140,
            class_2246.field_10320, class_2246.field_10532,
            class_2246.field_10268, class_2246.field_10605,
            class_2246.field_10373, class_2246.field_10055,
            class_2246.field_10068, class_2246.field_10371
    );

    private static final Set<class_1792> SHULKER_BOX_ITEMS = Set.of(
            class_1802.field_8545,
            class_1802.field_8722, class_1802.field_8380,
            class_1802.field_8050, class_1802.field_8829,
            class_1802.field_8271, class_1802.field_8548,
            class_1802.field_8520, class_1802.field_8627,
            class_1802.field_8451, class_1802.field_8213,
            class_1802.field_8816, class_1802.field_8350,
            class_1802.field_8584, class_1802.field_8461,
            class_1802.field_8676, class_1802.field_8268
    );

    private static final Set<class_1792> PICKAXES = Set.of(
            class_1802.field_8647, class_1802.field_8387, class_1802.field_8403,
            class_1802.field_8335, class_1802.field_8377, class_1802.field_22024
    );

    /* ==================== 反射 ==================== */
    private static Field selectedSlotField;

    /* ==================== 设置 ==================== */
    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Integer> hotbarSlot = sgGeneral.add(new IntSetting.Builder()
            .name("Shulker Slot")
            .description("Hotbar slot of the shulker box (0-8)")
            .defaultValue(0).min(0).max(8).build()
    );

    private final Setting<Integer> durabilityThreshold = sgGeneral.add(new IntSetting.Builder()
            .name("Pickaxe Durability Threshold")
            .description("Only use pickaxes with durability above this value")
            .defaultValue(1).min(1).max(10000).sliderRange(1, 5000).build()
    );

    private final Setting<Boolean> cycleBoxes = sgGeneral.add(new BoolSetting.Builder()
            .name("Cycle Shulkers")
            .description("Auto-swap the next shulker box into the slot after breaking one")
            .defaultValue(true).build()
    );

    /* ==================== 状态 ==================== */
    private class_2338 targetPos;
    private int lastPickSlot = -1;
    private boolean wasPlacing;

    public AutoShulkerBox() {
        super(MaceKillAddon.CATEGORY, "AutoShulkerBox", "Shulker box farmer");
    }

    @Override
    public void onActivate() {
        if (mc.field_1765 != null && mc.field_1765.method_17783() == class_239.class_240.field_1332) {
            targetPos = ((class_3965) mc.field_1765).method_17777().method_10084();
        }
        lastPickSlot = -1;
        wasPlacing = false;
    }

    @Override
    public void onDeactivate() {
        targetPos = null;
        lastPickSlot = -1;
        mc.field_1761.method_2925();
        mc.field_1690.field_1904.method_23481(false);
    }

    /* ==================== Tick 高速循环 ==================== */

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null) return;
        if (targetPos == null) return;

        class_2680 state = mc.field_1687.method_8320(targetPos);

        if (state.method_26215() || state.method_45474()) {
            // —— 放置潜影盒 ——
            ensureShulkerBoxInHand();
            placeBlock();
            wasPlacing = true;
        } else if (isShulkerBoxBlock(state)) {
            // —— 挖掘潜影盒 ——
            if (wasPlacing) {
                // 刚放置完，下一个 tick 再挖（给服务端一帧确认）
                wasPlacing = false;
                return;
            }
            ensurePickaxeInHand();
            breakBlock();
            if (cycleBoxes.get()) cycleShulkerBox();
            wasPlacing = false;
        }
    }

    // ==================== 方块操作 ====================

    /**
     * 放置：在 targetPos 放置潜影盒
     * 面向下方方块顶部，发送 PlayerInteractBlockC2SPacket
     */
    private void placeBlock() {
        if (mc.method_1562() == null) return;
        class_2350 face = class_2350.field_11036;
        class_2338 against = targetPos.method_10074();
        class_243 hitVec = new class_243(against.method_10263() + 0.5, against.method_10264() + 1.0, against.method_10260() + 0.5);
        class_3965 hitResult = new class_3965(hitVec, face, against, false);

        mc.method_1562().method_52787(
                new class_2885(class_1268.field_5808, hitResult, 0));
    }

    /**
     * 挖掘：START_DESTROY_BLOCK + STOP_DESTROY_BLOCK 同一 tick 瞬间破坏
     * Qazr 风格：额外发送 player.swingHand
     */
    private void breakBlock() {
        if (mc.method_1562() == null) return;
        class_2338 pos = targetPos;
        class_2350 face = bestFace(pos);

        mc.method_1562().method_52787(
                new class_2846(class_2846.class_2847.field_12968, pos, face, 0));
        mc.method_1562().method_52787(
                new class_2846(class_2846.class_2847.field_12973, pos, face, 0));
        mc.field_1724.method_6104(class_1268.field_5808);
    }

    /** 计算最佳攻击面（距离眼睛最近的方块面） */
    private class_2350 bestFace(class_2338 pos) {
        class_243 eye = mc.field_1724.method_33571();
        class_243 center = class_243.method_24953(pos);
        class_243 dir = center.method_1020(eye).method_1029();

        class_2350 best = class_2350.field_11036;
        double bestDot = -2;
        for (class_2350 d : class_2350.values()) {
            double dot = dir.method_1026(class_243.method_24954(d.method_62675()));
            if (dot > bestDot) { bestDot = dot; best = d; }
        }
        return best;
    }

    // ==================== 物品切换（Qazr 风格：纯反射，不发 UpdateSelectedSlot 包） ====================

    /** 确保主手持有潜影盒：优先配置槽位，否则搜快捷栏，最后从背包移动 */
    private void ensureShulkerBoxInHand() {
        if (isShulkerBox(mc.field_1724.method_6047())) return;

        int slot = hotbarSlot.get();
        if (isShulkerBox(mc.field_1724.method_31548().method_5438(slot))) {
            setSelectedSlot(slot);
            return;
        }

        // 搜快捷栏其他槽位
        for (int i = 0; i < 9; i++) {
            if (isShulkerBox(mc.field_1724.method_31548().method_5438(i))) {
                setSelectedSlot(i);
                return;
            }
        }

        // 从背包(9-35)移动到配置槽位
        for (int i = 9; i < 36; i++) {
            if (isShulkerBox(mc.field_1724.method_31548().method_5438(i))) {
                swapSlots(i, slot);
                setSelectedSlot(slot);
                return;
            }
        }
    }

    /** 确保主手持有镐子：搜快捷栏第一个耐久 >= 阈值的镐子 */
    private void ensurePickaxeInHand() {
        if (isPickaxe(mc.field_1724.method_6047().method_7909())
                && getDurability(mc.field_1724.method_6047()) >= durabilityThreshold.get()) {
            return;
        }

        int threshold = durabilityThreshold.get();

        // 复用上次位置
        if (lastPickSlot >= 0 && lastPickSlot < 9) {
            class_1799 s = mc.field_1724.method_31548().method_5438(lastPickSlot);
            if (isPickaxe(s.method_7909()) && getDurability(s) >= threshold) {
                setSelectedSlot(lastPickSlot);
                return;
            }
        }

        // 遍历快捷栏
        for (int i = 0; i < 9; i++) {
            class_1799 s = mc.field_1724.method_31548().method_5438(i);
            if (isPickaxe(s.method_7909()) && getDurability(s) >= threshold) {
                lastPickSlot = i;
                setSelectedSlot(i);
                return;
            }
        }
    }

    /**
     * 循环潜影盒：将背包中的下一个潜影盒移到配置槽位
     * 优先主背包(9-35)，其次快捷栏其他槽位
     */
    private void cycleShulkerBox() {
        int slot = hotbarSlot.get();
        class_1661 inv = mc.field_1724.method_31548();

        if (isShulkerBox(inv.method_5438(slot))) return;

        for (int i = 9; i < 36; i++) {
            if (isShulkerBox(inv.method_5438(i))) {
                swapSlots(i, slot);
                return;
            }
        }
        for (int i = 0; i < 9; i++) {
            if (i != slot && isShulkerBox(inv.method_5438(i))) {
                swapSlots(i, slot);
                return;
            }
        }
    }

    /**
     * 背包物品交换：ClickSlotC2SPacket SWAP
     */
    private void swapSlots(int from, int to) {
        if (mc.method_1562() == null || mc.field_1724 == null) return;
        try {
            mc.field_1761.method_2906(
                    mc.field_1724.field_7498.field_7763,
                    from, to, class_1713.field_7791, mc.field_1724);
        } catch (Exception ignored) {}
    }

    // ==================== 反射（Qazr 风格：纯 setInt，无 UpdateSelectedSlot） ====================

    private int getSelectedSlot() {
        try {
            if (selectedSlotField == null) {
                selectedSlotField = class_1661.class.getDeclaredField("selectedSlot");
                selectedSlotField.setAccessible(true);
            }
            return selectedSlotField.getInt(mc.field_1724.method_31548());
        } catch (Exception e) {
            return -1;
        }
    }

    private void setSelectedSlot(int slot) {
        try {
            if (selectedSlotField == null) {
                selectedSlotField = class_1661.class.getDeclaredField("selectedSlot");
                selectedSlotField.setAccessible(true);
            }
            selectedSlotField.setInt(mc.field_1724.method_31548(), slot);
        } catch (Exception ignored) {}
    }

    // ==================== 判定 ====================

    private boolean isShulkerBox(class_1799 stack) {
        return SHULKER_BOX_ITEMS.contains(stack.method_7909());
    }

    private boolean isShulkerBoxBlock(class_2680 state) {
        return SHULKER_BOX_BLOCKS.contains(state.method_26204());
    }

    private boolean isPickaxe(class_1792 item) {
        return PICKAXES.contains(item);
    }

    private int getDurability(class_1799 stack) {
        if (!stack.method_7963()) return Integer.MAX_VALUE;
        return stack.method_7936() - stack.method_7919();
    }

    @Override
    public String getInfoString() {
        if (targetPos == null) return "No target";
        class_2680 s = mc.field_1687 != null ? mc.field_1687.method_8320(targetPos) : null;
        if (s == null) return targetPos.method_23854();
        return s.method_26215() ? "Placing" : "Mining";
    }
}
