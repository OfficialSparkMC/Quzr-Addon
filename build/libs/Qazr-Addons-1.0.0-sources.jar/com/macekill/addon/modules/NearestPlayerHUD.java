package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import net.minecraft.class_1297;
import net.minecraft.class_1657;

/**
 * 最近玩家HUD — 在屏幕上显示最近玩家的名字和距离
 */
public class NearestPlayerHUD extends Module {

    // ==================== 设置 ====================
    private final SettingGroup sgMain = settings.getDefaultGroup();

    private final Setting<Double> range = sgMain.add(new DoubleSetting.Builder()
            .name("Range").description("Detection range")
            .defaultValue(100).min(1).max(500).sliderRange(1, 500).build()
    );

    public NearestPlayerHUD() {
        super(MaceKillAddon.CATEGORY, "NearestPlayerHUD", "Shows nearest player info");
    }

    // ==================== HUD信息 ====================

    @Override
    public String getInfoString() {
        if (mc.field_1724 == null || mc.field_1687 == null) return "None";

        double rangeSq = range.get() * range.get();
        class_1657 nearest = null;
        double bestDist = Double.MAX_VALUE;

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1657 p)) continue;
            if (p == mc.field_1724 || !p.method_5805()) continue;

            double distSq = mc.field_1724.method_5858(p);
            if (distSq > rangeSq) continue;

            if (distSq < bestDist) {
                bestDist = distSq;
                nearest = p;
            }
        }

        if (nearest == null) return "None";

        double dist = mc.field_1724.method_5739(nearest);
        return String.format("%s %.1f", nearest.method_5477().getString(), dist);
    }
}
