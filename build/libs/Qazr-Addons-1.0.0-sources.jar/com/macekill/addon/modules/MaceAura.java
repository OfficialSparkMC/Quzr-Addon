package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1802;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2868;
import java.lang.reflect.Field;
import java.util.*;

/**
 * 重锤光环 — MaceAura
 *
 * 核心特性：
 * - 位置缓存 (Map<BlockPos, Boolean>) 避免重复计算
 * - 图腾绕过：多次小高度攻击消耗图腾后再用完整高度击杀
 * - 偏移攻击：水平/垂直偏移，不精确站在目标头顶
 * - 高度递增：每次攻击递增高度，生成不同落点
 * - 垃圾包：每个高度发送多个移动包扰乱反作弊
 * - BlockPos.Mutable：减少 GC 压力
 */
public class MaceAura extends Module {
    private static Field selectedSlotField;
    private int maceSwapBackSlot = -1;

    /* ========== 设置 ========== */
    private final SettingGroup sgMain = settings.getDefaultGroup();
    private final SettingGroup sgTotem = settings.createGroup("Totem Bypass");
    private final SettingGroup sgOffset = settings.createGroup("Offset");

    private final Setting<Double> range = sgMain.add(new DoubleSetting.Builder()
            .name("Range").description("Target detection range")
            .defaultValue(20.0).min(1.0).max(200.0).sliderRange(1.0, 128.0).build());

    private final Setting<Boolean> onlyPlayers = sgMain.add(new BoolSetting.Builder()
            .name("Players Only").description("Only attack players").defaultValue(true).build());

    private final Setting<Boolean> swingArm = sgMain.add(new BoolSetting.Builder()
            .name("Swing Arm").description("Swing arm when attacking").defaultValue(false).build());

    private final Setting<Integer> fallHeight = sgMain.add(new IntSetting.Builder()
            .name("Attack Height").description("Base fall height")
            .defaultValue(30).min(1).max(170).sliderRange(1, 170).build());

    private final Setting<Integer> spamPackets = sgMain.add(new IntSetting.Builder()
            .name("Spam Packets").description("Extra move packets sent per height")
            .defaultValue(2).min(0).max(20).sliderMax(10).build());

    private final Setting<Integer> attackDelay = sgMain.add(new IntSetting.Builder()
            .name("Attack Delay").description("Attack interval in ticks")
            .defaultValue(10).min(0).max(40).sliderMax(40).build());

    private final Setting<Boolean> useOffset = sgOffset.add(new BoolSetting.Builder()
            .name("Use Offset").description("Don't land exactly above the target").defaultValue(false).build());

    private final Setting<Double> horizontalOffset = sgOffset.add(new DoubleSetting.Builder()
            .name("Horizontal Offset").description("Horizontal offset amount")
            .defaultValue(1.5).min(0).max(10).sliderMax(5)
            .visible(useOffset::get).build());

    private final Setting<Double> yOffset = sgOffset.add(new DoubleSetting.Builder()
            .name("Vertical Offset").description("Extra vertical height offset")
            .defaultValue(0.5).min(0).max(5).sliderMax(5)
            .visible(useOffset::get).build());

    private final Setting<Boolean> bypassTotem = sgTotem.add(new BoolSetting.Builder()
            .name("Totem Bypass").description("Drain totems with escalating-height hits and kill - all hits fire in ONE smash (required to beat AutoTotem)").defaultValue(false).build());

    private final Setting<Integer> attackCount = sgTotem.add(new IntSetting.Builder()
            .name("Totem Attacks").description("How many escalating hits to fire in the single smash (use >= 2 to oneshot AutoTotem)")
            .defaultValue(3).min(1).max(198).sliderMax(198)
            .visible(bypassTotem::get).build());

    private final Setting<Integer> heightIncrement = sgTotem.add(new IntSetting.Builder()
            .name("Height Increment").description("Height added per hit (must be > 0 so each hit deals strictly more damage, bypassing invulnerability)")
            .defaultValue(2).min(1).max(50).sliderMax(50)
            .visible(bypassTotem::get).build());

    /* ========== 状态 ========== */
    private final Map<class_2338, Boolean> positionCache = new HashMap<>();
    private final class_2338.class_2339 mutablePos = new class_2338.class_2339();
    private int remainingCooldown;
    private int totemAttackIndex;

    public MaceAura() {
        super(MaceKillAddon.CATEGORY, "MaceAura", "Mace aura - auto attack with totem bypass+offsets+position caching");
    }

    @Override
    public void onActivate() {
        remainingCooldown = 0;
        totemAttackIndex = 0;
        positionCache.clear();
    }

    @Override
    public void onDeactivate() {
        positionCache.clear();
    }

    /* ========== Tick ========== */

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (remainingCooldown > 0) { remainingCooldown--; return; }

        class_1309 target = findNearestTarget();
        if (target == null) return;

        boolean killed = executeAttack(target);
        if (killed) {
            totemAttackIndex = 0;
            positionCache.clear();
        }

        remainingCooldown = attackDelay.get();
    }

    // ========== 目标查找 ==========

    private class_1309 findNearestTarget() {
        if (mc.field_1687 == null || mc.field_1724 == null) return null;
        double rangeSq = range.get() * range.get();
        class_1309 best = null;
        double bestDist = Double.MAX_VALUE;

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1309 le) || !le.method_5805() || le == mc.field_1724) continue;
            double distSq = mc.field_1724.method_5858(le);
            if (distSq > rangeSq) continue;
            if (onlyPlayers.get() && !(le instanceof class_1657)) continue;
            if (le instanceof class_1657 p) {
                if (p.method_68878() || p.method_7325() || !Friends.get().shouldAttack(p)) continue;
            }
            if (distSq < bestDist) { bestDist = distSq; best = le; }
        }
        return best;
    }

    // ========== 攻击执行 ==========

    private boolean executeAttack(class_1309 target) {
        if (mc.method_1562() == null) return false;

        // 切换到重锤
        int oldSlot = switchToMace();
        if (oldSlot == -1) return false;

        try {
            class_243 originalPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());

            if (bypassTotem.get() && target instanceof class_1657) {
                // 图腾绕过：多轮递增高度攻击
                return executeTotemBypass(target, originalPos);
            } else {
                // 正常击杀
                return executeKill(target, originalPos, fallHeight.get());
            }
        } finally {
            switchBack(oldSlot);
        }
    }

    private boolean executeTotemBypass(class_1309 target, class_243 originalPos) {
        int count = attackCount.get();
        int increment = heightIncrement.get();
        int baseHeight = fallHeight.get();

        // AutoTotem re-equips between ticks, so every strictly-escalating hit MUST land in a
        // single smash (one executeAttack call). Sending all hits here guarantees the target
        // has no chance to re-equip and gets oneshot.
        for (int i = 0; i < count; i++) {
            int h = baseHeight + i * increment;
            doSingleAttack(target, originalPos, h);
        }
        return true;
    }

    private boolean executeKill(class_1309 target, class_243 originalPos, int height) {
        return doSingleAttack(target, originalPos, height);
    }

    private boolean doSingleAttack(class_1309 target, class_243 originalPos, int height) {
        if (mc.method_1562() == null) return false;

        class_243 targetPos = new class_243(target.method_23317(), target.method_23318(), target.method_23321());
        if (useOffset.get()) {
            targetPos = getOffset(targetPos);
        }

        // 计算安全起跳高度
        int safeHeight = getMaxHeightAbovePlayer(targetPos, height);
        if (safeHeight < 2) {
            return false; // 头顶是实心屋顶、没有起跳空间 -> 不攻击，避免卡在天上
        }
        class_243 jumpPos = new class_243(targetPos.field_1352, targetPos.field_1351 + safeHeight, targetPos.field_1350);

        // 升空 + 发垃圾包
        sendMovePacketWithSpam(new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()), jumpPos);

        // 下落
        class_243 attackPos = new class_243(targetPos.field_1352, targetPos.field_1351 + 0.5, targetPos.field_1350);
        sendMovePacketWithSpam(jumpPos, attackPos);

        if (swingArm.get()) mc.field_1724.method_6104(class_1268.field_5808);
        attackEntity(target);

        return true;
    }

    // ========== 位置计算 ==========

    /** 获取偏移后的位置 */
    private class_243 getOffset(class_243 pos) {
        double hOff = horizontalOffset.get();
        double yOff = yOffset.get();
        // 随机水平方向
        double angle = Math.random() * Math.PI * 2;
        return new class_243(
                pos.field_1352 + Math.cos(angle) * hOff,
                pos.field_1351 + yOff,
                pos.field_1350 + Math.sin(angle) * hOff);
    }

    /** 计算目标上方最大安全高度（从目标向上扫描，遇到实心屋顶即停，绝不穿顶到屋外天空） */
    private int getMaxHeightAbovePlayer(class_243 targetPos, int maxHeight) {
        int bx = (int) Math.floor(targetPos.field_1352);
        int bz = (int) Math.floor(targetPos.field_1350);
        int by = (int) Math.floor(targetPos.field_1351);
        int top = by + maxHeight;
        top = Math.min(top, 319);

        for (int cy = by + 1; cy <= top; cy++) {
            mutablePos.method_10103(bx, cy, bz);
            if (!isSafePosition(mutablePos)) {
                // 屋顶：取屋顶下方连通的空气（需要 2 格空气）
                if (cy - 1 <= by) return 0;
                mutablePos.method_10103(bx, cy - 1, bz);
                if (!isSafePosition(mutablePos)) return 0;
                return cy - 1 - by;
            }
        }
        return top - by;
    }

    private boolean isSafePosition(class_2338 pos) {
        return positionCache.computeIfAbsent(pos.method_10062(), p -> {
            class_2680 state = mc.field_1687.method_8320(p);
            // 空气或树叶（可穿过树叶升到树冠上方的天空）才视为安全；液体/蛛网/实心方块不安全
            return (state.method_26215() || state.method_26204() instanceof net.minecraft.class_2397)
                    && state.method_26227().method_15769()
                    && !state.method_27852(class_2246.field_10343);
        });
    }

    // ========== 发包 ==========

    private void sendMovePacketWithSpam(class_243 from, class_243 to) {
        double dist = from.method_1022(to);
        int steps = Math.max(1, (int) Math.ceil(dist / 8.0));
        double stepX = (to.field_1352 - from.field_1352) / steps;
        double stepY = (to.field_1351 - from.field_1351) / steps;
        double stepZ = (to.field_1350 - from.field_1350) / steps;

        int spam = spamPackets.get();
        for (int i = 1; i <= steps; i++) {
            double x = from.field_1352 + stepX * i;
            double y = from.field_1351 + stepY * i;
            double z = from.field_1350 + stepZ * i;
            mc.method_1562().method_52787(
                    new class_2828.class_2829(x, y, z, false, false));
            // 发垃圾包
            for (int s = 0; s < spam; s++) {
                mc.method_1562().method_52787(
                        new class_2828.class_2829(x, y, z, false, false));
            }
        }
    }

    private void attackEntity(class_1297 target) {
        if (mc.method_1562() == null) return;
        mc.method_1562().method_52787(
                class_2824.method_34206(target, mc.field_1724.method_5715()));
    }

    // ========== 物品切换 ==========

    private int switchToMace() {
        if (mc.field_1724 == null) return -1;
        class_1661 inv = mc.field_1724.method_31548();
        int cur = getSelectedSlot();
        maceSwapBackSlot = -1;
        if (inv.method_5438(cur).method_7909() == class_1802.field_49814) return cur;
        for (int i = 0; i < 9; i++) {
            if (inv.method_5438(i).method_7909() != class_1802.field_49814) continue;
            if (i != cur) {
                setSelectedSlot(i);
                mc.method_1562().method_52787(new class_2868(i));
            }
            return cur;
        }
        // Mace in the main inventory / offhand -> move it into the selected hotbar slot.
        FindItemResult mace = InvUtils.find(class_1802.field_49814);
        if (mace.found()) {
            int src = mace.slot();
            InvUtils.move().from(src).to(cur);
            maceSwapBackSlot = src;
        }
        return cur;
    }

    private void switchBack(int slot) {
        if (slot < 0 || slot >= 9) return;
        if (maceSwapBackSlot >= 0) {
            InvUtils.move().from(slot).to(maceSwapBackSlot);
            maceSwapBackSlot = -1;
            return;
        }
        setSelectedSlot(slot);
        mc.method_1562().method_52787(new class_2868(slot));
    }

    private int getSelectedSlot() {
        try {
            if (selectedSlotField == null) {
                selectedSlotField = class_1661.class.getDeclaredField("selectedSlot");
                selectedSlotField.setAccessible(true);
            }
            return selectedSlotField.getInt(mc.field_1724.method_31548());
        } catch (Exception e) { return 0; }
    }

    private void setSelectedSlot(int slot) {
        try {
            if (selectedSlotField == null) {
                selectedSlotField = class_1661.class.getDeclaredField("selectedSlot");
                selectedSlotField.setAccessible(true);
            }
            selectedSlotField.setInt(mc.field_1724.method_31548(), slot);
        } catch (Exception ignored) {}
    }

    @Override
    public String getInfoString() {
        if (remainingCooldown > 0) return "CD " + remainingCooldown;
        return bypassTotem.get() ? "Totem Bypass" : "Ready";
    }
}
