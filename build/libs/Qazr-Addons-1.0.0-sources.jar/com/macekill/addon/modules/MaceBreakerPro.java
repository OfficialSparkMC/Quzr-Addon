package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import meteordevelopment.meteorclient.events.entity.player.AttackEntityEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1661;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_2824;
import net.minecraft.class_2868;
import java.lang.reflect.Field;

/**
 * 盾牌破碎 - 攻击时自动斧+重锤连击破盾
 * 来自 InvincibleMachineGun 的 MaceBreakerPro
 */
public class MaceBreakerPro extends Module {
    private static Field selectedSlotField;

    private final SettingGroup sgGeneral = settings.getDefaultGroup();

    private final Setting<Boolean> onlyOnShield = sgGeneral.add(new BoolSetting.Builder()
            .name("Only Blocking").description("Only trigger the combo when the target is blocking")
            .defaultValue(true).build()
    );

    private final Setting<Boolean> swordTrigger = sgGeneral.add(new BoolSetting.Builder()
            .name("Sword Trigger").description("Also trigger the combo when holding a sword").defaultValue(false).build()
    );

    private final Setting<Boolean> axeTrigger = sgGeneral.add(new BoolSetting.Builder()
            .name("Axe Trigger").description("Also trigger the combo when holding an axe").defaultValue(true).build()
    );

    private final Setting<Boolean> maceTrigger = sgGeneral.add(new BoolSetting.Builder()
            .name("Mace Trigger").description("Also trigger the combo when holding a mace").defaultValue(false).build()
    );

    private final Setting<Boolean> autoReturn = sgGeneral.add(new BoolSetting.Builder()
            .name("Auto Return").description("Switch back to the original item after attacking").defaultValue(true).build()
    );

    public MaceBreakerPro() {
        super(MaceKillAddon.CATEGORY, "MaceBreakerPro", "Auto axe+mace combo to break shields on attack");
    }

    @EventHandler
    private void onAttackEntity(AttackEntityEvent event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (!(event.entity instanceof class_1309 target)) return;

        // 仅持盾模式：跳过未举盾的目标
        if (onlyOnShield.get() && !target.method_6039()) return;

        // 检查当前武器是否匹配触发条件
        class_1799 handItem = mc.field_1724.method_6047();
        String weaponName = handItem.method_7909().toString().toLowerCase();
        boolean isSword = weaponName.contains("sword");
        boolean isAxe = weaponName.contains("_axe") || weaponName.contains("axe");
        boolean isMace = weaponName.contains("mace");

        if (!(isSword && swordTrigger.get())
                && !(isAxe && axeTrigger.get())
                && !(isMace && maceTrigger.get())) {
            return;
        }

        // 取消原始攻击事件
        event.setCancelled(true);

        // 找到斧和重锤
        FindItemResult axe = findAxe();
        FindItemResult mace = findMace();
        int originalSlot = getSelectedSlot();

        // 如果有斧：切换斧 → 攻击
        if (axe.found()) {
            switchTo(axe.slot());
            sendAttackPacket(target);
        }

        // 如果有重锤：切换重锤 → 攻击
        if (mace.found()) {
            switchTo(mace.slot());
            sendAttackPacket(target);
        }

        // 恢复原位
        if (autoReturn.get()) {
            switchTo(originalSlot);
        }

        mc.field_1724.method_6104(class_1268.field_5808);
    }

    private FindItemResult findAxe() {
        for (int i = 0; i < 9; i++) {
            class_1799 stack = mc.field_1724.method_31548().method_5438(i);
            String name = stack.method_7909().toString().toLowerCase();
            if (name.contains("_axe")) return new FindItemResult(i, stack.method_7947());
        }
        return new FindItemResult(-1, 0);
    }

    private FindItemResult findMace() {
        return InvUtils.findInHotbar(class_1802.field_49814);
    }

    private void switchTo(int slot) {
        setSelectedSlot(mc.field_1724.method_31548(), slot);
        mc.method_1562().method_52787(new class_2868(slot));
    }

    private void sendAttackPacket(class_1309 target) {
        mc.method_1562().method_52787(
                class_2824.method_34206(target, mc.field_1724.method_5715()));
    }

    private int getSelectedSlot() {
        try {
            if (selectedSlotField == null) {
                selectedSlotField = class_1661.class.getDeclaredField("selectedSlot");
                selectedSlotField.setAccessible(true);
            }
            return selectedSlotField.getInt(mc.field_1724.method_31548());
        } catch (Exception e) {
            return 0;
        }
    }

    private void setSelectedSlot(class_1661 inv, int slot) {
        try {
            if (selectedSlotField == null) {
                selectedSlotField = class_1661.class.getDeclaredField("selectedSlot");
                selectedSlotField.setAccessible(true);
            }
            selectedSlotField.setInt(inv, slot);
        } catch (Exception ignored) {}
    }
}
