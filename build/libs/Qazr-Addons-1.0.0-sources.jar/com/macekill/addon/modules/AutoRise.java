package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2828;

public class AutoRise extends Module {

    private final SettingGroup sgMain = settings.getDefaultGroup();

    private final Setting<Double> detectRange = sgMain.add(new DoubleSetting.Builder()
            .name("Detection Range").description("Target detection range")
            .defaultValue(6.0).min(1.0).max(20.0).sliderRange(1.0, 20.0).build());

    private final Setting<Double> riseHeight = sgMain.add(new DoubleSetting.Builder()
            .name("Rise Height").description("VClip rise height")
            .defaultValue(10.0).min(1.0).max(50.0).sliderRange(1.0, 50.0).build());

    private final Setting<Boolean> sendRotationsWhenHigh = sgMain.add(new BoolSetting.Builder()
            .name("Send Rotations").description("Send junk rotation packets when height > 12")
            .defaultValue(true).build());

    public AutoRise() {
        super(MaceKillAddon.CATEGORY, "AutoRise", "Automatically rises");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null) return;

        double h = riseHeight.get();

        // 如果高度>12且开启了发送旋转，先发4个垃圾旋转包
        if (sendRotationsWhenHigh.get() && h > 12.0) {
            for (int i = 0; i < 4; i++) {
                mc.method_1562().method_52787(new class_2828.class_2831(
                        mc.field_1724.method_36454(), mc.field_1724.method_36455(), mc.field_1724.method_24828(), false));
            }
        }

        // 找到最近的目标（可选：有目标才上升）
        class_1309 target = findTarget();
        if (target == null) return;

        double posX = mc.field_1724.method_23317();
        double posY = mc.field_1724.method_23318();
        double posZ = mc.field_1724.method_23321();

        // 第一个包：上升
        mc.method_1562().method_52787(new class_2828.class_2829(
                posX + h, posY, posZ, false, false));

        // 第二个包：返回原位
        mc.method_1562().method_52787(new class_2828.class_2829(
                posX, posY, posZ, false, false));
    }

    private class_1309 findTarget() {
        if (mc.field_1687 == null || mc.field_1724 == null) return null;
        double rangeSq = detectRange.get() * detectRange.get();
        class_1309 best = null;
        double bestDist = Double.MAX_VALUE;

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1309 le) || !le.method_5805() || le == mc.field_1724) continue;
            double distSq = mc.field_1724.method_5858(le);
            if (distSq > rangeSq) continue;
            if (le instanceof class_1657 p) {
                if (p.method_68878() || p.method_7325() || !Friends.get().shouldAttack(p)) continue;
            }
            if (distSq < bestDist) { bestDist = distSq; best = le; }
        }
        return best;
    }

    @Override
    public String getInfoString() {
        return String.format("%.1f", riseHeight.get());
    }
}
