package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import com.macekill.addon.modules.macekill.Inventory;
import com.macekill.addon.modules.macekill.Movement;
import com.macekill.addon.modules.macekill.Targeting;
import java.util.ArrayList;
import java.util.List;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_243;

/**
 * 新TP重锤 — xintpmace
 *
 * 逻辑：
 * Tick 中找最近目标 → 预测位置 → 分步传送到目标旁 → VClip起跳 → 多高度攻击 → 返回
 * 简洁版，无破甲/图腾绕过等复杂逻辑
 */
public class XinTpMace extends Module {

    private final SettingGroup sgMain = settings.getDefaultGroup();
    private final SettingGroup sgTotem = settings.createGroup("Totem Bypass");

    private final Setting<Double> range = sgMain.add(new DoubleSetting.Builder()
            .name("Range").description("Target detection range")
            .defaultValue(20.0).min(1.0).max(200.0).sliderRange(1.0, 128.0).build());

    private final Setting<Integer> predictTicks = sgMain.add(new IntSetting.Builder()
            .name("Predict Ticks").description("Ticks to predict future position")
            .defaultValue(5).min(1).sliderMax(20).build());

    private final Setting<Double> maxStep = sgMain.add(new DoubleSetting.Builder()
            .name("Max Step").description("Max distance per teleport segment")
            .defaultValue(8.0).min(1.0).max(128.0).sliderRange(1.0, 128.0).build());

    private final Setting<Integer> cooldown = sgMain.add(new IntSetting.Builder()
            .name("Cooldown").description("Attack cooldown in ticks")
            .defaultValue(10).min(0).max(40).sliderMax(40).build());

    private final Setting<List<String>> heights = sgMain.add(new StringListSetting.Builder()
            .name("Height List").description("Heights used for VClip attacks")
            .defaultValue("10", "20", "30").build());

    private final Setting<Boolean> swingHand = sgMain.add(new BoolSetting.Builder()
            .name("Swing Hand").description("Swing hand when attacking").defaultValue(false).build());

    private final Setting<Boolean> onlyPlayers = sgMain.add(new BoolSetting.Builder()
            .name("Players Only").description("Only attack players").defaultValue(true).build());

    private final Setting<Boolean> bypassTotem = sgTotem.add(new BoolSetting.Builder()
            .name("Totem Bypass").description("Drain totems with multi-height hits, then kill at full height")
            .defaultValue(false).build());

    private final Setting<Boolean> detectTotem = sgTotem.add(new BoolSetting.Builder()
            .name("Detect Totem").description("Only drain if the target is actually holding a totem")
            .defaultValue(true).visible(bypassTotem::get).build());

    private final Setting<DrainMode> drainMode = sgTotem.add(new EnumSetting.Builder<DrainMode>()
            .name("Drain Mode").description("List: use custom height list | Incremental: base + step per hit")
            .defaultValue(DrainMode.LIST).visible(bypassTotem::get).build());

    private final Setting<List<String>> drainHeights = sgTotem.add(new StringListSetting.Builder()
            .name("Drain Heights").description("Heights used to drain totems before the kill")
            .defaultValue("4", "8", "12", "16")
            .visible(() -> bypassTotem.get() && drainMode.get() == DrainMode.LIST).build());

    private final Setting<Integer> baseDrainHeight = sgTotem.add(new IntSetting.Builder()
            .name("Base Drain Height").description("Starting height for incremental drain attacks")
            .defaultValue(4).min(1).max(50).sliderMax(50)
            .visible(() -> bypassTotem.get() && drainMode.get() == DrainMode.INCREMENTAL).build());

    private final Setting<Integer> heightIncrement = sgTotem.add(new IntSetting.Builder()
            .name("Height Increment").description("Added height per drain attack")
            .defaultValue(4).min(1).max(20).sliderMax(20)
            .visible(() -> bypassTotem.get() && drainMode.get() == DrainMode.INCREMENTAL).build());

    private final Setting<Integer> totemAttacks = sgTotem.add(new IntSetting.Builder()
            .name("Totem Attacks").description("Number of drain attacks before the kill")
            .defaultValue(4).min(1).max(15).sliderMax(15)
            .visible(bypassTotem::get).build());

    // 状态
    private int cooldownTicks;
    private class_243 originalPos;

    public XinTpMace() {
        super(MaceKillAddon.CATEGORY, "xintpmace", "New TP mace - predicted teleport+multi-height VClip attack");
    }

    @Override
    public void onDeactivate() {
        cooldownTicks = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null) return;

        if (cooldownTicks > 0) { cooldownTicks--; return; }

        class_1309 target = findTarget();
        if (target == null) return;

        originalPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
        class_243 predicted = Targeting.predictPosition(mc, target, true, predictTicks.get());

        boolean draining = false;
        List<String> rawHeights = heights.get();
        if (bypassTotem.get() && target instanceof class_1657 p
                && (!detectTotem.get() || targetHasTotem(p))) {
            draining = true;
            rawHeights = new ArrayList<>();
            rawHeights.addAll(getDrainHeights());
            rawHeights.addAll(heights.get());
        }

        int oldSlot = Inventory.switchToMace(mc);
        if (oldSlot == -1) return;

        try {
            // 传送到目标旁
            Movement.doTpTo(mc, predicted, maxStep.get(), false);

            // 多高度VClip攻击
            for (String hStr : rawHeights) {
                double h;
                try { h = Double.parseDouble(hStr.trim()); }
                catch (NumberFormatException e) { continue; }
                if (h <= 0) continue;

                // VClip 起跳
                class_243 current = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
                class_243 jumpPos = new class_243(predicted.field_1352, predicted.field_1351 + h, predicted.field_1350);
                Movement.doTpTo(mc, jumpPos, maxStep.get(), false);

                // 下落并攻击
                class_243 attackPos = new class_243(predicted.field_1352, predicted.field_1351 + 0.5, predicted.field_1350);
                Movement.sendMovePacket(mc, attackPos.field_1352, attackPos.field_1351, attackPos.field_1350);

                if (swingHand.get()) mc.field_1724.method_6104(class_1268.field_5808);
                Movement.attackEntity(mc, target);
            }
        } finally {
            Inventory.switchBack(mc, oldSlot);
        }

        // 返回原位
        if (originalPos != null) {
            Movement.doTpTo(mc, originalPos, maxStep.get(), false);
        }

        cooldownTicks = cooldown.get();
    }

    private class_1309 findTarget() {
        if (mc.field_1687 == null || mc.field_1724 == null) return null;
        double rangeSq = range.get() * range.get();
        class_1309 best = null;
        double bestDist = Double.MAX_VALUE;

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1309 le) || !le.method_5805() || le == mc.field_1724) continue;
            double distSq = mc.field_1724.method_5858(le);
            if (distSq > rangeSq) continue;
            if (onlyPlayers.get() && !(le instanceof class_1657)) continue;
            if (le instanceof class_1657 p) {
                if (p.method_68878() || p.method_7325() || !Friends.get().shouldAttack(p)) continue;
            }
            if (distSq < bestDist) { bestDist = distSq; best = le; }
        }
        return best;
    }

    @Override
    public String getInfoString() {
        if (cooldownTicks > 0 && bypassTotem.get()) {
            return "Totem Bypass";
        }
        if (cooldownTicks > 0) return "CD " + cooldownTicks;
        return "Ready";
    }

    private boolean targetHasTotem(class_1657 player) {
        return player.method_6079().method_31574(class_1802.field_8288)
            || player.method_6047().method_31574(class_1802.field_8288);
    }

    private List<String> getDrainHeights() {
        if (drainMode.get() == DrainMode.INCREMENTAL) {
            List<String> list = new ArrayList<>();
            for (int i = 0; i < totemAttacks.get(); i++) {
                list.add(String.valueOf(baseDrainHeight.get() + i * heightIncrement.get()));
            }
            return list;
        }
        return drainHeights.get();
    }

    private enum DrainMode {
        LIST,
        INCREMENTAL
    }
}
