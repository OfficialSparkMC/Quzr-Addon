package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import com.macekill.addon.modules.macekill.Combat;
import meteordevelopment.meteorclient.events.entity.player.AttackEntityEvent;
import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.systems.modules.Modules;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1713;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2824;
import net.minecraft.class_2828;
import net.minecraft.class_2868;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;

/**
 * MaceAttect - all of TpMace's smash features, but instead of auto-TP to a target it
 * triggers the mace totem-bypass smash on the specific entity YOU hit (or that another
 * module sends an attack packet to). The smash is performed locally (vertical VClip from
 * your current position onto the hit entity) - no long-range teleport.
 */
public class MaceAttect extends Module {
    private static Field selectedSlotField;
    private static Field cachedTypeField;
    private static Object cachedAttackType;
    private static Field cachedEntityIdField;
    private static Field attackEventEntityField;

    // The addon is remapped to intermediary at runtime, so string-based reflection must
    // try BOTH the yarn name and the intermediary name. The packet's type field is
    // "type"/"field_12871", the ATTACK constant is "ATTACK"/"field_29170", and entityId is
    // "entityId"/"field_12870".
    private static final String[] TYPE_FIELD_CANDIDATES = { "field_12871", "type" };
    private static final String[] ATTACK_FIELD_CANDIDATES = { "field_29170", "ATTACK" };
    private static final String[] ENTITY_ID_FIELD_CANDIDATES = { "field_12870", "entityId" };

    // ==================== 设置组 ====================
    private final SettingGroup sgGeneral = settings.getDefaultGroup();
    private final SettingGroup sgExploit = settings.createGroup("Attack");
    private final SettingGroup sgTotem = settings.createGroup("Totem Bypass");
    private final SettingGroup sgTarget = settings.createGroup("Target");

    // ---- 通用 ----
    private final Setting<Double> moveDistance = sgGeneral.add(new DoubleSetting.Builder()
            .name("Move Step").description("Max distance per movement packet")
            .defaultValue(8).min(1).max(128).sliderRange(1, 128).build()
    );

    private final Setting<Boolean> autoSwitch = sgGeneral.add(new BoolSetting.Builder()
            .name("Auto Switch").description("Auto-switch to mace").defaultValue(true).build()
    );

    private final Setting<Boolean> rotate = sgGeneral.add(new BoolSetting.Builder()
            .name("Rotate").description("Face target when attacking").defaultValue(true).build()
    );

    private final Setting<Boolean> swingHand = sgGeneral.add(new BoolSetting.Builder()
            .name("Swing Hand").description("Swing hand client-side on attack").defaultValue(false).build()
    );

    private final Setting<Boolean> returnPos = sgGeneral.add(new BoolSetting.Builder()
            .name("Return to Start").description("Return to where you were standing when you hit")
            .defaultValue(true).build()
    );

    // ---- 攻击 ----
    private final Setting<Boolean> maxPower = sgExploit.add(new BoolSetting.Builder()
            .name("Max Damage").description("Use max safe height (170) when on, set height when off")
            .defaultValue(true).build()
    );

    private final Setting<Integer> fallHeight = sgExploit.add(new IntSetting.Builder()
            .name("Attack Height").description("Fall height (mace damage) used for the attack")
            .defaultValue(170).min(1).max(170).sliderRange(1, 170)
            .visible(() -> !maxPower.get()).build()
    );

    private final Setting<Boolean> silentSwap = sgExploit.add(new BoolSetting.Builder()
            .name("Silent Swap").description("Swap to mace without sending a slot packet").defaultValue(false).build()
    );

    // ---- 图腾绕过 ----
    private final Setting<Boolean> totemBypass = sgTotem.add(new BoolSetting.Builder()
            .name("Totem Bypass").description("Drain totems with multi-height hits, then kill at full height")
            .defaultValue(false).build()
    );

    private final Setting<Boolean> detectTotem = sgTotem.add(new BoolSetting.Builder()
            .name("Detect Totem").description("Only drain if the target is actually holding a totem")
            .defaultValue(true).visible(totemBypass::get).build()
    );

    private final Setting<DrainMode> drainMode = sgTotem.add(new EnumSetting.Builder<DrainMode>()
            .name("Drain Mode").description("List: use custom height list | Incremental: base + step per hit")
            .defaultValue(DrainMode.LIST).visible(totemBypass::get).build()
    );

    private final Setting<List<String>> drainHeights = sgTotem.add(new StringListSetting.Builder()
            .name("Drain Heights").description("Heights used to drain totems before the kill")
            .defaultValue("4", "8", "12", "16")
            .visible(() -> totemBypass.get() && drainMode.get() == DrainMode.LIST).build()
    );

    private final Setting<Integer> baseDrainHeight = sgTotem.add(new IntSetting.Builder()
            .name("Base Drain Height").description("Starting height for incremental drain attacks")
            .defaultValue(4).min(1).max(50).sliderMax(50)
            .visible(() -> totemBypass.get() && drainMode.get() == DrainMode.INCREMENTAL).build()
    );

    private final Setting<Integer> heightIncrement = sgTotem.add(new IntSetting.Builder()
            .name("Height Increment").description("Added height per drain attack")
            .defaultValue(4).min(1).max(20).sliderMax(20)
            .visible(() -> totemBypass.get() && drainMode.get() == DrainMode.INCREMENTAL).build()
    );

    private final Setting<Integer> totemAttacks = sgTotem.add(new IntSetting.Builder()
            .name("Totem Attacks").description("Number of drain attacks before the kill")
            .defaultValue(4).min(1).max(15).sliderMax(15)
            .visible(totemBypass::get).build()
    );

    private final Setting<Integer> totemsToPop = sgTotem.add(new IntSetting.Builder()
            .name("Totems To Pop").description("How many totems to pop (1-198)")
            .defaultValue(24).min(1).max(198).sliderMax(198)
            .visible(totemBypass::get).build()
    );

    private final Setting<Boolean> singleTick = sgTotem.add(new BoolSetting.Builder()
            .name("Single Tick").description("Totem bypass always fires the whole hit list in one mace smash (required to beat AutoTotem)")
            .defaultValue(true).visible(() -> false).build()
    );

    private final Setting<Integer> bypassHitsPerTick = sgTotem.add(new IntSetting.Builder()
            .name("Hits Per Tick").description("Unused - totem bypass is always a single smash")
            .defaultValue(1).min(1).max(20).sliderMax(20)
            .visible(() -> false).build()
    );

    // ---- 目标过滤 ----
    private final Setting<Boolean> players = sgTarget.add(new BoolSetting.Builder()
            .name("Players").description("Smash players").defaultValue(true).build()
    );
    private final Setting<Boolean> entities = sgTarget.add(new BoolSetting.Builder()
            .name("Entities").description("Smash living entities").defaultValue(false).build()
    );
    private final Setting<Boolean> throughWalls = sgTarget.add(new BoolSetting.Builder()
            .name("Through Walls").description("Require line of sight to smash").defaultValue(false).build()
    );
    private final Setting<Boolean> ignoreNamed = sgTarget.add(new BoolSetting.Builder()
            .name("Ignore Named").description("Ignore entities with custom names").defaultValue(false).build()
    );
    private final Setting<ListMode> listMode = sgTarget.add(new EnumSetting.Builder<ListMode>()
            .name("List Mode").description("Whitelist or blacklist").defaultValue(ListMode.Off).build()
    );
    private final Setting<String> playerList = sgTarget.add(new StringSetting.Builder()
            .name("Player List").description("Comma separated").defaultValue("")
            .visible(() -> listMode.get() != ListMode.Off).build()
    );

    // ==================== 状态 ====================
    private enum Phase { IDLE, SMASH, RETURN_DELAY }
    private enum ListMode { Off, Whitelist, Blacklist }
    private enum DrainMode { LIST, INCREMENTAL }

    private Phase phase = Phase.IDLE;
    private int delayTicks;
    private int attackCount;
    private class_243 originalPos;
    private class_1309 target;
    private class_1309 pendingTarget;
    private int originalSlot = -1;
    private int maceSlot = -1;
    private int maceSwapBackSlot = -1;
    private boolean noMaceWarned = false;
    private List<String> bypassHeights;
    private int bypassIdx;

    public MaceAttect() {
        super(MaceKillAddon.CATEGORY, "MaceAttect", "Mace totem-bypass smash triggered by your hit / an attack packet on a specific entity (no auto-TP)");
    }

    @Override
    public void onDeactivate() {
        phase = Phase.IDLE;
        target = null;
        pendingTarget = null;
        originalPos = null;
        originalSlot = -1;
        maceSlot = -1;
        maceSwapBackSlot = -1;
        attackCount = 0;
        bypassHeights = null;
        bypassIdx = 0;
    }

    // ==================== 触发 ====================

    /** Other modules can call this to make MaceAttect smash an entity. */
    public static void request(class_1309 target) {
        MaceAttect m = Modules.get().get(MaceAttect.class);
        if (m != null && m.isActive() && m.phase == Phase.IDLE) {
            m.pendingTarget = target;
        }
    }

    // Manual hit: Meteor posts AttackEntityEvent whenever the player attacks an entity.
    @EventHandler
    private void onAttackEntity(AttackEntityEvent event) {
        if (phase != Phase.IDLE) return;
        class_1309 le = getAttackEventEntity(event);
        if (le == null) return;
        if (!hitCheck(le)) return;
        pendingTarget = le;
    }

    // Injection: any module that sends an attack packet on an entity triggers the smash too.
    @EventHandler
    private void onPacketSend(PacketEvent.Send event) {
        if (phase != Phase.IDLE) return;
        if (!(event.packet instanceof class_2824 pkt)) return;
        if (!isAttackPacket(pkt)) return;
        class_1297 e = getPacketEntity(pkt);
        if (!(e instanceof class_1309 le)) return;
        if (!hitCheck(le)) return;
        pendingTarget = le;
    }

    // PlayerInteractEntityC2SPacket has no public type/getter on the client, so detect the
    // ATTACK variant via reflection on the private fields. Covers both your manual hit and
    // any attack packet another module sends (injection). Field names are remapped at runtime,
    // so we try both yarn and intermediary names.
    private boolean resolveAttackType() {
        if (cachedAttackType != null && cachedTypeField != null) return true;
        try {
            Class<?> cls = class_2824.class;
            for (String n : ATTACK_FIELD_CANDIDATES) {
                try {
                    Field f = cls.getDeclaredField(n);
                    f.setAccessible(true);
                    Object v = f.get(null);
                    if (v != null) { cachedAttackType = v; break; }
                } catch (Exception ignored) {}
            }
            for (String n : TYPE_FIELD_CANDIDATES) {
                try {
                    Field f = cls.getDeclaredField(n);
                    f.setAccessible(true);
                    cachedTypeField = f;
                    break;
                } catch (Exception ignored) {}
            }
        } catch (Exception ignored) {}
        return cachedAttackType != null && cachedTypeField != null;
    }

    private boolean isAttackPacket(class_2824 pkt) {
        if (!resolveAttackType()) return false;
        try {
            return cachedAttackType.equals(cachedTypeField.get(pkt));
        } catch (Exception e) {
            return false;
        }
    }

    private class_1297 getPacketEntity(class_2824 pkt) {
        try {
            if (cachedEntityIdField == null) {
                for (String n : ENTITY_ID_FIELD_CANDIDATES) {
                    try {
                        Field f = class_2824.class.getDeclaredField(n);
                        f.setAccessible(true);
                        cachedEntityIdField = f;
                        break;
                    } catch (Exception ignored) {}
                }
            }
            if (cachedEntityIdField == null) return null;
            int id = (int) cachedEntityIdField.get(pkt);
            return mc.field_1687.method_8469(id);
        } catch (Exception e) {
            return null;
        }
    }

    // AttackEntityEvent.entity is typed via a different mapping than this addon uses, so read
    // it reflectively to avoid a compile-time type mismatch.
    private class_1309 getAttackEventEntity(AttackEntityEvent event) {
        try {
            if (attackEventEntityField == null) {
                attackEventEntityField = AttackEntityEvent.class.getField("entity");
            }
            Object e = attackEventEntityField.get(event);
            if (e instanceof class_1309 le) return le;
        } catch (Exception ignored) {
        }
        return null;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        switch (phase) {
            case IDLE -> {
                if (pendingTarget != null) {
                    class_1309 t = pendingTarget;
                    pendingTarget = null;
                    if (checkAndSwapWeapon()) {
                        originalPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());
                        attackCount = 0;
                        target = t;
                        phase = Phase.SMASH;
                    }
                }
            }
            case SMASH -> runSmash();
            case RETURN_DELAY -> tickReturnDelay();
        }
    }

    // ==================== 攻击核心 ====================

    private void runSmash() {
        if (target == null) { resetState(); return; }

        if (totemBypass.get() && target instanceof class_1657 p
                && (!detectTotem.get() || targetHasTotem(p))) {
            int totems = totemsToPop.get();
            if (detectTotem.get()) totems = Math.min(totems, countTotems(p));
            totems = Math.min(totems + 3, Combat.MAX_TOTEM_HITS);
            int base = maxPower.get() ? 170 : fallHeight.get();
            // AutoTotem re-equips between ticks, so the whole strictly-escalating hit list
            // MUST land in a single tick (one mace smash) or the target always survives.
            List<String> all = Combat.totemBypassHeights(getDrainHeights(), totems, base, 3);
            for (String hStr : all) {
                int h = parseHeight(hStr);
                if (h > 0) attackOnce(target, h);
            }
            finishAttack();
            return;
        }

        doAttack(target, getAttackHeight(), true);
    }

    private void doAttack(class_1309 target, int height, boolean isFinal) {
        attackOnce(target, height);
        if (isFinal) {
            finishAttack();
        } else {
            delayTicks = 0;
            phase = Phase.RETURN_DELAY;
        }
    }

    private void attackOnce(class_1309 target, int height) {
        if (mc.field_1724 == null) return;

        // Cap the teleport at the highest air that is still connected to the target. Never
        // teleport through a solid roof into the disconnected sky (that strands the player up there).
        class_2338 hole = Combat.findVclipHole(mc, target.method_23317(), target.method_23318(), target.method_23321(), height);
        if (hole.method_10264() <= (int) target.method_23318() + 1) {
            return; // no clearance under the roof -> don't attack, avoid getting stuck
        }
        class_243 tpPos = new class_243(target.method_23317(), hole.method_10264(), target.method_23321());

        if (rotate.get()) {
            float yaw = getYawTo(target);
            float pitch = getPitchTo(target);
            mc.method_1562().method_52787(
                    new class_2828.class_2831(yaw, pitch, mc.field_1724.method_24828(), false));
        }

        // VClip：模拟升空（从玩家当前位置到目标正上方）
        sendVClipPackets(new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321()), tpPos);

        // 模拟掉落
        sendExploitPackets(tpPos);

        // 攻击
        sendAttack(target);
    }

    private void sendVClipPackets(class_243 from, class_243 to) {
        double step = moveDistance.get();
        double totalDist = to.field_1351 - from.field_1351;
        int steps = (int) Math.ceil(Math.abs(totalDist) / step);
        double stepY = totalDist / steps;

        for (int i = 1; i <= steps; i++) {
            double y = from.field_1351 + stepY * i;
            mc.method_1562().method_52787(
                    new class_2828.class_2829(from.field_1352, y, from.field_1350, false, false));
        }
    }

    private void sendExploitPackets(class_243 from) {
        double step = moveDistance.get();
        double startY = from.field_1351;
        double targetY = target.method_23318() + 1.1;

        for (double y = startY; y > targetY + step; y -= step) {
            mc.method_1562().method_52787(
                    new class_2828.class_2829(from.field_1352, y, from.field_1350, false, false));
        }

        mc.method_1562().method_52787(
                new class_2828.class_2829(from.field_1352, targetY, from.field_1350, false, false));
    }

    private void sendAttack(class_1309 target) {
        if (silentSwap.get() && maceSlot != -1) {
            setSlotClient(maceSlot);
        }

        mc.method_1562().method_52787(class_2824.method_34206(target, mc.field_1724.method_5715()));

        if (swingHand.get()) {
            mc.field_1724.method_6104(class_1268.field_5808);
        }

        if (silentSwap.get()) {
            setSlotClient(originalSlot);
        }
    }

    private void finishAttack() {
        if (returnPos.get() && originalPos != null) {
            mc.method_1562().method_52787(
                    new class_2828.class_2829(originalPos.field_1352, originalPos.field_1351, originalPos.field_1350,
                            mc.field_1724.method_24828(), false));
            delayTicks = 0;
            phase = Phase.RETURN_DELAY;
            return;
        }
        resetState();
    }

    private void tickReturnDelay() {
        delayTicks++;
        if (delayTicks >= 2) {
            if (originalPos != null) {
                mc.method_1562().method_52787(
                        new class_2828.class_2829(originalPos.field_1352, originalPos.field_1351 + 0.5, originalPos.field_1350,
                                true, false));
            }
            resetState();
        }
    }

    private void resetState() {
        if (maceSwapBackSlot >= 0) {
            swapMace(maceSwapBackSlot, originalSlot);
            maceSwapBackSlot = -1;
        }
        phase = Phase.IDLE;
        delayTicks = 0;
        attackCount = 0;
        target = null;
        originalPos = null;
        bypassHeights = null;
        bypassIdx = 0;
    }

    // ==================== 武器切换 ====================

    private boolean checkAndSwapWeapon() {
        originalSlot = getSelectedSlot();
        maceSwapBackSlot = -1;

        if (!autoSwitch.get()) return true;

        class_1661 inv = mc.field_1724.method_31548();

        if (inv.method_5438(originalSlot).method_31574(class_1802.field_49814)) {
            maceSlot = originalSlot;
            noMaceWarned = false;
            return true;
        }

        for (int i = 0; i < 9; i++) {
            if (inv.method_5438(i).method_31574(class_1802.field_49814)) {
                maceSlot = i;
                noMaceWarned = false;
                if (i != originalSlot) {
                    setSelectedSlot(inv, i);
                    mc.method_1562().method_52787(new class_2868(i));
                }
                return true;
            }
        }

        int src = -1;
        for (int i = 9; i < inv.method_5439(); i++) {
            if (inv.method_5438(i).method_31574(class_1802.field_49814)) {
                src = i;
                break;
            }
        }
        if (src == -1) {
            if (!noMaceWarned) {
                error("No mace found in inventory, attack cancelled.");
                noMaceWarned = true;
            }
            return false;
        }

        swapMace(src, originalSlot);
        maceSlot = originalSlot;
        maceSwapBackSlot = src;
        mc.method_1562().method_52787(new class_2868(originalSlot));
        noMaceWarned = false;
        return true;
    }

    private void swapMace(int invSlot, int hotbarSlot) {
        if (mc.field_1724 == null) return;
        int screenSlot = invSlot;
        if (invSlot >= 36 && invSlot <= 39) screenSlot = invSlot - 31; // armor -> 5..8
        else if (invSlot == 40) screenSlot = 45; // offhand
        mc.field_1761.method_2906(
                mc.field_1724.field_7498.field_7763, screenSlot, hotbarSlot, class_1713.field_7791, mc.field_1724);
    }

    // ==================== 目标过滤 ====================

    private boolean hitCheck(class_1297 entity) {
        if (!(entity instanceof class_1309 le) || le.method_29504()) return false;
        if (entity == mc.field_1724) return false;

        if (entity instanceof class_1657 player) {
            if (!players.get()) return false;
            if (player.method_7325()) return false;
            if (Friends.get().isFriend(player)) return false;
            if (!Friends.get().shouldAttack(player)) return false;

            if (listMode.get() != ListMode.Off) {
                List<String> list = parsePlayerList();
                String name = player.method_5477().getString();
                if (listMode.get() == ListMode.Whitelist && !list.contains(name)) return false;
                if (listMode.get() == ListMode.Blacklist && list.contains(name)) return false;
            }
        } else {
            if (!entities.get()) return false;
        }

        if (ignoreNamed.get() && entity.method_16914()) return false;
        if (!throughWalls.get() && !mc.field_1724.method_6057(entity)) return false;

        return true;
    }

    // ==================== 高度计算 ====================

    private int getAttackHeight() {
        if (maxPower.get()) return 170;
        return Math.min(fallHeight.get(), 170);
    }

    // ==================== 旋转 ====================

    private float getYawTo(class_1297 target) {
        double dx = target.method_23317() - mc.field_1724.method_23317();
        double dz = target.method_23321() - mc.field_1724.method_23321();
        return (float) (Math.toDegrees(Math.atan2(-dx, dz)));
    }

    private float getPitchTo(class_1297 target) {
        double dx = target.method_23317() - mc.field_1724.method_23317();
        double dy = target.method_23320() - mc.field_1724.method_23320();
        double dz = target.method_23321() - mc.field_1724.method_23321();
        double dist = Math.sqrt(dx * dx + dz * dz);
        return (float) -Math.toDegrees(Math.atan2(dy, dist));
    }

    // ==================== 反射 ====================

    private int getSelectedSlot() {
        try {
            if (selectedSlotField == null) {
                selectedSlotField = class_1661.class.getDeclaredField("selectedSlot");
                selectedSlotField.setAccessible(true);
            }
            return selectedSlotField.getInt(mc.field_1724.method_31548());
        } catch (Exception e) {
            return 0;
        }
    }

    private void setSelectedSlot(class_1661 inv, int slot) {
        try {
            if (selectedSlotField == null) {
                selectedSlotField = class_1661.class.getDeclaredField("selectedSlot");
                selectedSlotField.setAccessible(true);
            }
            selectedSlotField.setInt(inv, slot);
        } catch (Exception ignored) {}
    }

    private void setSlotClient(int slot) {
        setSelectedSlot(mc.field_1724.method_31548(), slot);
    }

    private boolean targetHasTotem(class_1657 player) {
        return countTotems(player) > 0;
    }

    private int countTotems(class_1657 player) {
        int n = 0;
        class_1661 inv = player.method_31548();
        for (int i = 0; i < inv.method_5439(); i++) {
            if (inv.method_5438(i).method_31574(class_1802.field_8288)) n++;
        }
        return n;
    }

    private List<String> getDrainHeights() {
        if (drainMode.get() == DrainMode.INCREMENTAL) {
            List<String> list = new ArrayList<>();
            for (int i = 0; i < totemAttacks.get(); i++) {
                list.add(String.valueOf(baseDrainHeight.get() + i * heightIncrement.get()));
            }
            return list;
        }
        return drainHeights.get();
    }

    private int parseHeight(String s) {
        try {
            return (int) Double.parseDouble(s.trim());
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private List<String> parsePlayerList() {
        List<String> list = new ArrayList<>();
        for (String s : playerList.get().split(",")) {
            String trim = s.trim();
            if (!trim.isEmpty()) list.add(trim);
        }
        return list;
    }

    @Override
    public String getInfoString() {
        if (totemBypass.get() && target instanceof class_1657) return "Totem Bypass";
        return target != null ? target.method_5477().getString() : "Idle";
    }
}
