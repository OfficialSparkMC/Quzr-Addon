package com.macekill.addon.modules;

import meteordevelopment.meteorclient.events.packets.PacketEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.Rotations;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2824;
import net.minecraft.class_8143;

import static com.macekill.addon.MaceKillAddon.CATEGORY;

public class Hitback extends Module {
    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<Boolean> rotate = sg.add(new BoolSetting.Builder()
        .name("Rotate")
        .description("Rotate to face the attacker before hitting back.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> ignoreFriends = sg.add(new BoolSetting.Builder()
        .name("Ignore Friends")
        .description("Do not hit back friends.")
        .defaultValue(true)
        .build());

    private final Setting<Boolean> onlyPlayers = sg.add(new BoolSetting.Builder()
        .name("Only Players")
        .description("Only hit back players, not mobs/entities.")
        .defaultValue(true)
        .build());

    private final Setting<Integer> cooldown = sg.add(new IntSetting.Builder()
        .name("Cooldown")
        .description("Minimum ticks between hitbacks.")
        .defaultValue(10)
        .min(0)
        .max(200)
        .sliderMax(200)
        .build());

    private int cd;

    public Hitback() {
        super(CATEGORY, "Hitback", "Automatically hits back whoever damages you.");
    }

    @Override
    public void onActivate() {
        cd = 0;
    }

    @EventHandler
    private void onDamagePacket(PacketEvent.Receive event) {
        if (!(event.packet instanceof class_8143 packet)) return;
        if (mc.field_1724 == null || mc.field_1687 == null) return;
        if (packet.comp_1267() != mc.field_1724.method_5628()) return;

        int attackerId = packet.comp_1269();
        if (attackerId <= 0) return;

        class_1297 attacker = mc.field_1687.method_8469(attackerId);
        if (attacker == null || attacker == mc.field_1724) return;
        if (onlyPlayers.get() && !(attacker instanceof class_1657)) return;
        if (ignoreFriends.get() && attacker instanceof class_1657 p && Friends.get().isFriend(p)) return;

        if (cd > 0) return;
        cd = cooldown.get();
        hitBack(attacker);
    }

    private void hitBack(class_1297 attacker) {
        Runnable attack = () -> mc.method_1562().method_52787(
            class_2824.method_34206(attacker, mc.field_1724.method_5715())
        );

        if (rotate.get()) {
            double dx = attacker.method_23317() - mc.field_1724.method_23317();
            double dy = attacker.method_23320() - mc.field_1724.method_23320();
            double dz = attacker.method_23321() - mc.field_1724.method_23321();
            double dist = Math.sqrt(dx * dx + dz * dz);
            float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
            float pitch = (float) -Math.toDegrees(Math.atan2(dy, dist));
            Rotations.rotate(yaw, pitch, attack);
        } else {
            attack.run();
        }
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (cd > 0) cd--;
    }
}
