package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_2828;

/**
 * Anti-air miss module.
 * Uses rapid vertical position packets to attempt to prevent hammer attacks
 * from being registered as misses.
 */
public class AntiAirMiss extends Module {

    // ==================== Settings ====================

    private final SettingGroup sgMain = settings.getDefaultGroup();

    private final Setting<Double> detectionRange = sgMain.add(
        new DoubleSetting.Builder()
            .name("detection-range")
            .description("Maximum distance for detecting nearby players.")
            .defaultValue(6)
            .min(1)
            .max(20)
            .sliderRange(1, 20)
            .build()
    );

    private final Setting<Double> verticalOffset = sgMain.add(
        new DoubleSetting.Builder()
            .name("vertical-offset")
            .description("Maximum vertical distance used for the position packet sequence.")
            .defaultValue(10)
            .min(1)
            .max(50)
            .sliderRange(1, 50)
            .build()
    );

    // ==================== State ====================

    private class_1657 targetPlayer;

    public AntiAirMiss() {
        super(
            MaceKillAddon.CATEGORY,
            "anti-air-miss",
            "Attempts to prevent hammer attacks from missing by sending rapid vertical position updates."
        );
    }

    @Override
    public void onDeactivate() {
        targetPlayer = null;
    }

    // ==================== Tick ====================

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null ||
            mc.field_1687 == null ||
            mc.method_1562() == null) {
            return;
        }

        targetPlayer = findNearestPlayer();

        if (targetPlayer == null) {
            return;
        }

        double offset = verticalOffset.get();
        double originalY = mc.field_1724.method_23318();

        // Send rapid upward position updates.
        for (int step = 1; step <= 10; step++) {
            double y = originalY + (offset / 10.0) * step;

            mc.method_1562().method_52787(
                new class_2828.class_2829(
                    mc.field_1724.method_23317(),
                    y,
                    mc.field_1724.method_23321(),
                    false,
                    false
                )
            );
        }

        // Send rapid downward position updates.
        for (int step = 1; step <= 10; step++) {
            double y = originalY + offset - (offset / 10.0) * step;

            mc.method_1562().method_52787(
                new class_2828.class_2829(
                    mc.field_1724.method_23317(),
                    y,
                    mc.field_1724.method_23321(),
                    false,
                    false
                )
            );
        }

        // Restore the original position.
        mc.method_1562().method_52787(
            new class_2828.class_2829(
                mc.field_1724.method_23317(),
                originalY,
                mc.field_1724.method_23321(),
                mc.field_1724.method_24828(),
                false
            )
        );
    }

    // ==================== Target Selection ====================

    private class_1657 findNearestPlayer() {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return null;
        }

        double rangeSquared =
            detectionRange.get() * detectionRange.get();

        class_1657 closestPlayer = null;
        double closestDistanceSquared = Double.MAX_VALUE;

        for (class_1297 entity : mc.field_1687.method_18112()) {
            if (!(entity instanceof class_1657 player)) {
                continue;
            }

            if (player == mc.field_1724 || !player.method_5805()) {
                continue;
            }

            if (!Friends.get().shouldAttack(player)) {
                continue;
            }

            double distanceSquared =
                mc.field_1724.method_5858(player);

            if (distanceSquared > rangeSquared) {
                continue;
            }

            if (distanceSquared < closestDistanceSquared) {
                closestDistanceSquared = distanceSquared;
                closestPlayer = player;
            }
        }

        return closestPlayer;
    }

    // ==================== HUD Information ====================

    @Override
    public String getInfoString() {
        if (targetPlayer != null && mc.field_1724 != null) {
            double distance = mc.field_1724.method_5739(targetPlayer);

            return String.format(
                "%s %.1fm",
                targetPlayer.method_5477().getString(),
                distance
            );
        }

        return "No target";
    }
}
