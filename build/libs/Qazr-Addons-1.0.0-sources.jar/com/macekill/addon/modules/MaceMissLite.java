package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import com.macekill.addon.modules.macekill.Combat;
import com.macekill.addon.modules.macekill.Inventory;
import com.macekill.addon.modules.macekill.Movement;
import com.macekill.addon.modules.macekill.SortPriority;
import com.macekill.addon.modules.macekill.Targeting;
import java.util.*;
import java.util.function.Predicate;
import meteordevelopment.meteorclient.events.render.Render3DEvent;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.renderer.ShapeMode;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.friends.Friends;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1268;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1588;
import net.minecraft.class_1657;
import net.minecraft.class_1802;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;

/**
 * 重锤导弹精简版 — MaceMissLite
 *
 * 核心特性：
 * - 强制忽略按键：按住跳过当前目标
 * - dv1/dv2 双偏移值控制攻击角度
 * - 破甲模式 + 击杀模式双路攻击流程
 * - 预测位置/碰撞箱
 * - 毫秒计时器
 * - 渲染方块框
 */
public class MaceMissLite extends Module {

    /* ========== MSTimer — 毫秒级计时器 ========== */
    private static class MSTimer {
        private long lastMS;
        boolean hasPassed(long ms) {
            return System.currentTimeMillis() - lastMS >= ms;
        }
        void reset() { lastMS = System.currentTimeMillis(); }
    }

    /* ========== 设置 ========== */
    private final SettingGroup sgMain = settings.getDefaultGroup();
    private final SettingGroup sgTarget = settings.createGroup("Target");
    private final SettingGroup sgArmor = settings.createGroup("Armor Break");
    private final SettingGroup sgTotem = settings.createGroup("Totem Bypass");

    // 通用
    private final Setting<Double> range = sgMain.add(new DoubleSetting.Builder()
            .name("Range").description("Detection range")
            .defaultValue(20.0).min(1.0).max(200.0).sliderRange(1.0, 128.0).build());

    private final Setting<Double> moveDistance = sgMain.add(new DoubleSetting.Builder()
            .name("Move Step").description("Max distance per move packet")
            .defaultValue(8.0).min(1.0).max(128.0).sliderRange(1.0, 128.0).build());

    private final Setting<List<String>> killHeights = sgMain.add(new StringListSetting.Builder()
            .name("Kill Heights").description("Heights used for kill attacks")
            .defaultValue("10", "20", "30").build());

    private final Setting<Integer> attackDelay = sgMain.add(new IntSetting.Builder()
            .name("Attack Delay").description("Attack interval in ticks")
            .defaultValue(10).min(0).max(40).sliderMax(40).build());

    private final Setting<Boolean> predict = sgMain.add(new BoolSetting.Builder()
            .name("Predict Position").description("Predict target's future position").defaultValue(true).build());

    private final Setting<Integer> predictTicks = sgMain.add(new IntSetting.Builder()
            .name("Predict Ticks").description("Ticks to predict ahead")
            .defaultValue(5).min(1).sliderMax(20).visible(predict::get).build());

    // dv偏移
    private final Setting<Double> dv1 = sgMain.add(new DoubleSetting.Builder()
            .name("Attack 1 Offset").description("Horizontal offset for the first attack")
            .defaultValue(0.0).min(0).max(10).sliderMax(5).build());

    private final Setting<Double> dv2 = sgMain.add(new DoubleSetting.Builder()
            .name("Attack 2 Offset").description("Horizontal offset for the second attack")
            .defaultValue(0.0).min(0).max(10).sliderMax(5).build());

    private final Setting<Boolean> swingHand = sgMain.add(new BoolSetting.Builder()
            .name("Swing Hand").description("Swing hand when attacking").defaultValue(false).build());

    // 强制忽略
    private final Setting<Boolean> forceIgnore = sgMain.add(new BoolSetting.Builder()
            .name("Force Skip").description("Enable to skip the current target").defaultValue(false).build());

    // 目标
    private final Setting<Boolean> targetPlayers = sgTarget.add(new BoolSetting.Builder()
            .name("Players").description("Attack players").defaultValue(true).build());

    private final Setting<Boolean> targetHostiles = sgTarget.add(new BoolSetting.Builder()
            .name("Hostile Mobs").description("Attack hostile mobs").defaultValue(true).build());

    private final Setting<Boolean> targetAnimals = sgTarget.add(new BoolSetting.Builder()
            .name("Animals").description("Attack animals").defaultValue(true).build());

    private final Setting<SortPriority> sortPriority = sgTarget.add(new EnumSetting.Builder<SortPriority>()
            .name("Sort Priority").description("How targets are sorted")
            .defaultValue(SortPriority.DISTANCE).build());

    private final Setting<Boolean> autoAttackEntity = sgTarget.add(new BoolSetting.Builder()
            .name("Auto Attack Entities").description("Attack any living entity, ignoring the target filters above")
            .defaultValue(false).build());

    // 破甲
    private final Setting<Boolean> destroyArmor = sgArmor.add(new BoolSetting.Builder()
            .name("Armor Break").description("Break armor before killing").defaultValue(false).build());

    private final Setting<Integer> ignoreValue = sgArmor.add(new IntSetting.Builder()
            .name("Armor Threshold").description("Switch to kill when target armor is at or below this")
            .defaultValue(0).min(0).max(4).sliderMax(4)
            .visible(destroyArmor::get).build());

    private final Setting<List<String>> destroyHeights = sgArmor.add(new StringListSetting.Builder()
            .name("Armor Break Heights").description("Heights used for armor-break attacks")
            .defaultValue("30", "60").visible(destroyArmor::get).build());

    private final Setting<Boolean> bypassTotem = sgTotem.add(new BoolSetting.Builder()
            .name("Totem Bypass").description("Drain totems with multi-height hits, then kill at full height")
            .defaultValue(false).build());

    private final Setting<Boolean> detectTotem = sgTotem.add(new BoolSetting.Builder()
            .name("Detect Totem").description("Only drain if the target is actually holding a totem")
            .defaultValue(true).visible(bypassTotem::get).build());

    private final Setting<DrainMode> drainMode = sgTotem.add(new EnumSetting.Builder<DrainMode>()
            .name("Drain Mode").description("List: use custom height list | Incremental: base + step per hit")
            .defaultValue(DrainMode.LIST).visible(bypassTotem::get).build());

    private final Setting<List<String>> drainHeights = sgTotem.add(new StringListSetting.Builder()
            .name("Drain Heights").description("Heights used to drain totems before the kill")
            .defaultValue("4", "8", "12", "16")
            .visible(() -> bypassTotem.get() && drainMode.get() == DrainMode.LIST).build());

    private final Setting<Integer> baseDrainHeight = sgTotem.add(new IntSetting.Builder()
            .name("Base Drain Height").description("Starting height for incremental drain attacks")
            .defaultValue(4).min(1).max(50).sliderMax(50)
            .visible(() -> bypassTotem.get() && drainMode.get() == DrainMode.INCREMENTAL).build());

    private final Setting<Integer> heightIncrement = sgTotem.add(new IntSetting.Builder()
            .name("Height Increment").description("Added height per drain attack")
            .defaultValue(4).min(1).max(20).sliderMax(20)
            .visible(() -> bypassTotem.get() && drainMode.get() == DrainMode.INCREMENTAL).build());

    private final Setting<Integer> totemAttacks = sgTotem.add(new IntSetting.Builder()
            .name("Totem Attacks").description("Number of drain attacks before the kill")
            .defaultValue(4).min(1).max(15).sliderMax(15)
            .visible(bypassTotem::get).build());

    // 渲染
    private final Setting<Boolean> renderBox = sgMain.add(new BoolSetting.Builder()
            .name("Render Box").description("Render box around the target").defaultValue(true).build());

    private final Setting<SettingColor> boxColor = sgMain.add(new ColorSetting.Builder()
            .name("Box Color").description("Render color")
            .defaultValue(new SettingColor(255, 0, 0, 100)).build());

    /* ========== 状态 ========== */
    private final MSTimer attackTimer = new MSTimer();
    private class_1309 currentTarget;
    private int attackIndex;
    private int delayTicks;
    private Phase phase = Phase.IDLE;
    private class_243 originalPos;

    private enum Phase { IDLE, DELAY }

    public MaceMissLite() {
        super(MaceKillAddon.CATEGORY, "MaceMissLite", "Lite mace missile - dual offsets+force skip+armor break");
    }

    @Override
    public void onDeactivate() {
        currentTarget = null;
        attackIndex = 0;
        delayTicks = 0;
        phase = Phase.IDLE;
    }

    /* ========== Tick ========== */

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null) return;

        switch (phase) {
            case IDLE -> {
                if (delayTicks > 0) { delayTicks--; return; }
                tickIdle();
            }
            case DELAY -> {
                delayTicks--;
                if (delayTicks <= 0) {
                    phase = Phase.IDLE;
                    attackIndex = 0;
                }
            }
        }
    }

    private void tickIdle() {
        updateTarget();
        if (currentTarget == null) return;
        if (isAboutToBeIgnored()) {
            currentTarget = null;
            return;
        }
        doAura();
        delayTicks = attackDelay.get();
        phase = Phase.DELAY;
    }

    // ========== 目标更新 ==========

    private void updateTarget() {
        List<class_1309> validTargets = new ArrayList<>();
        double rangeSq = range.get() * range.get();

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1309 le) || !le.method_5805() || le == mc.field_1724) continue;
            if (mc.field_1724.method_5858(le) > rangeSq) continue;
            if (!targetCheck(le)) continue;
            validTargets.add(le);
        }

        if (validTargets.isEmpty()) { currentTarget = null; return; }

        validTargets.sort((a, b) -> switch (sortPriority.get()) {
            case DISTANCE ->
                Double.compare(mc.field_1724.method_5858(a), mc.field_1724.method_5858(b));
            case HEALTH ->
                Float.compare(a.method_6032(), b.method_6032());
            case ANGLE -> {
                class_243 look = mc.field_1724.method_5828(1.0f);
                class_243 eye = mc.field_1724.method_33571();
                double aDot = look.method_1026(a.method_33571().method_1020(eye).method_1029());
                double bDot = look.method_1026(b.method_33571().method_1020(eye).method_1029());
                yield Double.compare(bDot, aDot);
            }
        });
        currentTarget = validTargets.get(0);
    }

    private boolean targetCheck(class_1309 entity) {
        if (entity instanceof class_1657 p) {
            if (p.method_68878() || p.method_7325() || !Friends.get().shouldAttack(p)) return false;
            return targetPlayers.get();
        }
        if (autoAttackEntity.get()) return true;
        if (entity instanceof class_1588) return targetHostiles.get();
        if (entity instanceof class_1429) return targetAnimals.get();
        return false;
    }

    // ========== 攻击流程 ==========

    private void doAura() {
        if (currentTarget == null || mc.method_1562() == null) return;

        originalPos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());

        if (bypassTotem.get() && currentTarget instanceof class_1657 p
                && (!detectTotem.get() || targetHasTotem(p))) {
            List<String> all = new ArrayList<>(getDrainHeights());
            all.addAll(killHeights.get());
            doTpAura(all);
            return;
        }

        if (destroyArmor.get() && currentTarget instanceof class_1657 p && !isNaked(p)) {
            doDestroyArmor();
        } else {
            doTpAura(killHeights.get());
        }
    }

    private void doDestroyArmor() {
        doTpAura(destroyHeights.get());
    }

    private void doTpAura(List<String> rawHeights) {
        List<Double> heights = Combat.parseHeights(rawHeights);
        if (heights.isEmpty()) heights.add(20.0);

        int oldSlot = Inventory.switchToMace(mc);
        if (oldSlot == -1) return;

        try {
            class_243 targetPos = Targeting.predictPosition(mc, currentTarget, predict.get(), predictTicks.get());
            class_243 basePos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());

            for (int i = 0; i < heights.size(); i++) {
                double h = heights.get(i);
                // 应用 dv 偏移
                if (i == 0 && dv1.get() > 0) targetPos = applyDv(targetPos, dv1.get());
                if (i == 1 && dv2.get() > 0) targetPos = applyDv(targetPos, dv2.get());

                class_2338 vclipHole = Combat.findVclipHole(mc,
                        mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), h);
                class_243 vclipPos = class_243.method_24955(vclipHole);

                Movement.doTpTo(mc, vclipPos, moveDistance.get(), false);
                Movement.sendMovePacket(mc, targetPos.field_1352, targetPos.field_1351 + 0.5, targetPos.field_1350);
                Movement.sendMovePacket(mc, basePos.field_1352, basePos.field_1351, basePos.field_1350);

                if (swingHand.get()) mc.field_1724.method_6104(class_1268.field_5808);
                Movement.attackEntity(mc, currentTarget);
            }
        } finally {
            Inventory.switchBack(mc, oldSlot);
        }
    }

    private class_243 applyDv(class_243 pos, double offset) {
        double angle = Math.random() * Math.PI * 2;
        return new class_243(
                pos.field_1352 + Math.cos(angle) * offset,
                pos.field_1351,
                pos.field_1350 + Math.sin(angle) * offset);
    }

    // ========== 判定 ==========

    private boolean isAboutToBeIgnored() {
        return forceIgnore.get();
    }

    private boolean isNaked(class_1657 player) {
        return Combat.needsArmorDestroy(player, ignoreValue.get()) == false;
        // needsArmorDestroy returns count > ignoreValue → 需要破甲
        // 所以 !needsArmorDestroy = 护甲 <= ignoreValue = 已经破甲 → isNaked
    }

    private boolean targetHasTotem(class_1657 player) {
        return player.method_6079().method_31574(class_1802.field_8288)
            || player.method_6047().method_31574(class_1802.field_8288);
    }

    private List<String> getDrainHeights() {
        if (drainMode.get() == DrainMode.INCREMENTAL) {
            List<String> list = new ArrayList<>();
            for (int i = 0; i < totemAttacks.get(); i++) {
                list.add(String.valueOf(baseDrainHeight.get() + i * heightIncrement.get()));
            }
            return list;
        }
        return drainHeights.get();
    }

    // ========== 渲染 ==========

    @EventHandler
    private void onRender3D(Render3DEvent event) {
        if (!renderBox.get() || currentTarget == null) return;
        class_238 box = currentTarget.method_5829();
        event.renderer.box(box, boxColor.get(), boxColor.get(), ShapeMode.Both, 0);
    }

    @Override
    public String getInfoString() {
        if (currentTarget == null) return "No target";
        if (phase == Phase.DELAY && bypassTotem.get()) {
            return "Totem Bypass";
        }
        if (phase == Phase.DELAY) return "CD " + delayTicks;
        String name = currentTarget instanceof class_1657 p ? p.method_5477().getString()
                : currentTarget.method_5864().method_5897().getString();
        return name;
    }

    private enum DrainMode {
        LIST,
        INCREMENTAL
    }
}
