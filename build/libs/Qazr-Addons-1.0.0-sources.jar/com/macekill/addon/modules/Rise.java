package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2828;

public class Rise extends Module {

    private final SettingGroup sgMain = settings.getDefaultGroup();

    private final Setting<Integer> height = sgMain.add(new IntSetting.Builder()
            .name("Height").description("VClip rise height")
            .defaultValue(10).min(1).max(50).build());

    private final Setting<Integer> delay = sgMain.add(new IntSetting.Builder()
            .name("Delay").description("Interval between rises in ticks")
            .defaultValue(20).min(1).max(100).build());

    private final Setting<Boolean> bypass = sgMain.add(new BoolSetting.Builder()
            .name("Bypass").description("Enable bypass mode")
            .defaultValue(true).build());

    private int delayTicks;

    public Rise() {
        super(MaceKillAddon.CATEGORY, "Rise", "Vertical rise");
    }

    @Override
    public void onDeactivate() {
        delayTicks = 0;
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null) return;

        if (delayTicks > 0) { delayTicks--; return; }

        if (!bypass.get() && delayTicks > 0) return;

        double posX = mc.field_1724.method_23317();
        double posY = mc.field_1724.method_23318();
        double posZ = mc.field_1724.method_23321();

        // 每tick发送10组上下抖动包
        for (int i = 0; i < 10; i++) {
            // 上升包
            mc.method_1562().method_52787(new class_2828.class_2829(
                    posX, posY + height.get(), posZ, false, false));

            // 回落包
            mc.method_1562().method_52787(new class_2828.class_2829(
                    posX, posY, posZ, false, false));
        }

        delayTicks = delay.get();
    }

    @Override
    public String getInfoString() {
        if (delayTicks > 0) return "CD " + delayTicks;
        return "+" + height.get();
    }
}
