package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_2828;

public class SpeedModule extends Module {

    private final SettingGroup sgMain = settings.getDefaultGroup();

    private final Setting<Integer> riseHeight = sgMain.add(new IntSetting.Builder()
            .name("Rise Height").description("Height gained per cycle")
            .defaultValue(5).min(1).max(20).build());

    private final Setting<Integer> cycles = sgMain.add(new IntSetting.Builder()
            .name("Cycles").description("Number of rise cycles")
            .defaultValue(10).min(1).max(50).build());

    public SpeedModule() {
        super(MaceKillAddon.CATEGORY, "Speed", "Cyclic rise");
    }

    @EventHandler
    private void onTick(TickEvent.Pre event) {
        if (mc.field_1724 == null || mc.field_1687 == null || mc.method_1562() == null) return;

        double posX = mc.field_1724.method_23317();
        double posY = mc.field_1724.method_23318();
        double posZ = mc.field_1724.method_23321();
        int h = riseHeight.get();
        int n = cycles.get();

        // 从0到cycles（含）循环，每级上升riseHeight * i
        for (int i = 0; i <= n; i++) {
            double targetY = posY + h * i;
            for (int j = 0; j < 3; j++) {
                mc.method_1562().method_52787(new class_2828.class_2829(
                        posX, targetY, posZ, false, false));
            }
        }
    }

    @Override
    public String getInfoString() {
        return riseHeight.get() + "x" + cycles.get();
    }
}
