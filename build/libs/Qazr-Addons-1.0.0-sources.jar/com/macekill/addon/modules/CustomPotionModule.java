package com.macekill.addon.modules;

import com.macekill.addon.MaceKillAddon;
import com.macekill.addon.utils.CreativeGiveUtil;
import meteordevelopment.meteorclient.events.world.TickEvent;
import meteordevelopment.meteorclient.settings.*;
import meteordevelopment.meteorclient.systems.modules.Module;
import meteordevelopment.meteorclient.utils.render.color.SettingColor;
import meteordevelopment.orbit.EventHandler;
import net.minecraft.class_1291;
import net.minecraft.class_1293;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1844;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.class_9334;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * 自定义药水生成器 (照搬 Wurst PotionCmd 逻辑)
 * 独立模块, 不与其他物品生成器耦合
 *
 * 效果列表格式: 效果ID|等级(0-255)|持续秒数
 * 多个效果: 喷溅/滞留只能有1个, 普通可以有多个
 *
 * 常用效果ID:
 *   instant_health, instant_damage, strength, regeneration,
 *   speed, slowness, jump_boost, resistance, fire_resistance,
 *   invisibility, night_vision, water_breathing, absorption,
 *   health_boost, saturation, glowing, levitation, slow_falling,
 *   luck, unluck, bad_omen, hero_of_the_village, darkness
 */
public class CustomPotionModule extends Module {
    private final class_310 mc = class_310.method_1551();

    public enum PotionType {
        REGULAR, SPLASH, LINGERING
    }

    public CustomPotionModule() {
        super(MaceKillAddon.CATEGORY, "PotionGiver",
            "Creative-mode custom potion spawner\n" +
            "Effect list: one per line, format effectID|level|durationSeconds\n" +
            "Example: instant_health|125|1   (Instant Health lvl 125)\n" +
            "minecraft: prefix optional, duration capped at 60 minutes");
    }

    private final SettingGroup sg = settings.getDefaultGroup();

    private final Setting<PotionType> potionType = sg.add(new EnumSetting.Builder<PotionType>()
        .name("Potion Type")
        .defaultValue(PotionType.SPLASH).build()
    );

    private final Setting<Integer> count = sg.add(new IntSetting.Builder()
        .name("Count").defaultValue(1).min(1).max(64).sliderMax(64).build()
    );

    private final Setting<List<String>> potionEffects = sg.add(new StringListSetting.Builder()
        .name("Effect List")
        .description("One per line, format: effectID|level (0-255)|duration (seconds)\n" +
                     "minecraft: prefix optional\n" +
                     "Examples:\n" +
                     "  instant_health|125|1    (Instant Health lvl 125)\n" +
                     "  strength|10|300        (Strength 10 for 5 min)\n" +
                     "  regeneration|5|30      (Regeneration 5 for 30s)\n" +
                     "  speed|2|600            (Speed 2 for 10 min)\n" +
                     "Common: instant_health, instant_damage, strength, regeneration, " +
                     "speed, slowness, jump_boost, resistance, fire_resistance, " +
                     "invisibility, night_vision, water_breathing, absorption, " +
                     "health_boost, saturation, glowing, levitation, slow_falling, " +
                     "luck, unluck, bad_omen, hero_of_the_village, darkness, " +
                     "weaving, oozing, infested, wind_charged, raid_omen, trial_omen")
        .defaultValue(List.of("instant_health|125|1"))
        .build()
    );

    private final Setting<Boolean> customColor = sg.add(new BoolSetting.Builder()
        .name("Custom Color").defaultValue(false).build()
    );

    private final Setting<SettingColor> potionColor = sg.add(new ColorSetting.Builder()
        .name("Potion Color")
        .description("Click to open the HSV color picker; applied as the potion particle color")
        .defaultValue(new SettingColor(255, 0, 0)) // 默认红色
        .build()
    );

    private final Setting<Boolean> customName = sg.add(new BoolSetting.Builder()
        .name("Custom Name").defaultValue(false).build()
    );

    private final Setting<String> nameText = sg.add(new StringSetting.Builder()
        .name("Name Text")
        .description("Supports color codes: &6gold &cred &agreen &blight blue &9blue &dpink &eyellow &fwhite &0black etc.\n" +
                     "&l=bold &o=italic &n=underline &m=strikethrough &k=obfuscated")
        .defaultValue("&c&lQazr1234 &6&lKill Potion").build()
    );

    private final Setting<Boolean> continuous = sg.add(new BoolSetting.Builder()
        .name("Continuous").defaultValue(false).build()
    );

    @Override
    public void onActivate() {
        if (mc.field_1724 == null || mc.field_1687 == null) { toggle(); return; }
        if (!mc.field_1724.method_31549().field_7477) {
            CreativeGiveUtil.warn("Creative mode required!"); toggle(); return;
        }
        CreativeGiveUtil.resetError();
        generateAndGive();
        if (!continuous.get()) toggle();
    }

    @EventHandler
    private void onTick(TickEvent.Post event) {
        if (!continuous.get() || mc.field_1724 == null) return;
        if (!mc.field_1724.method_31549().field_7477) { toggle(); return; }
        generateAndGive();
    }

    private void generateAndGive() {
        PotionType type = potionType.get();
        class_1792 baseItem = switch (type) {
            case REGULAR -> class_1802.field_8574;
            case SPLASH -> class_1802.field_8436;
            case LINGERING -> class_1802.field_8150;
        };

        class_1799 stack = new class_1799(baseItem, count.get());

        // 解析效果列表
        List<class_1293> effects = new ArrayList<>();
        for (String entry : potionEffects.get()) {
            if (entry == null) continue;
            String s = entry.trim();
            if (s.isEmpty()) continue;
            String[] parts = s.split("\\|");
            if (parts.length < 1) { CreativeGiveUtil.warn("Invalid effect format: " + s + " (expected id|level|seconds)"); continue; }

            String idStr = parts[0].trim();
            int amplifier = 0;
            int durationTicks = 600; // 默认30秒
            if (parts.length >= 2) {
                try { amplifier = Integer.parseInt(parts[1].trim()); }
                catch (Exception e) { CreativeGiveUtil.warn("Effect level parse error: " + parts[1]); }
            }
            if (parts.length >= 3) {
                try {
                    int seconds = Integer.parseInt(parts[2].trim());
                    durationTicks = Math.min(seconds * 20, 72000); // 最大60分钟
                } catch (Exception e) { CreativeGiveUtil.warn("Effect duration parse error: " + parts[2]); }
            }

            try {
                class_2960 effId = class_2960.method_12829(idStr.contains(":") ? idStr : "minecraft:" + idStr);
                if (effId == null) { CreativeGiveUtil.warn("Unknown effect ID: " + idStr); continue; }
                Optional<class_6880.class_6883<class_1291>> ref = statusEffectRegistry().method_10223(effId);
                if (ref.isEmpty()) { CreativeGiveUtil.warn("Effect not found: " + idStr); continue; }
                effects.add(new class_1293(ref.get(), durationTicks, amplifier, false, true));
            } catch (Exception e) {
                CreativeGiveUtil.warn("Effect failed [" + idStr + "]: " + e.getMessage());
            }
        }

        if (effects.isEmpty()) {
            CreativeGiveUtil.warn("No effects added!"); return;
        }

        // 组装 PotionContentsComponent (照搬 Wurst: Optional<potion>, Optional<customColor>, List<customEffects>, Optional<customName>)
        SettingColor sc = potionColor.get();
        // 转换: SettingColor (r,g,b) -> MC ARGB int (0xAARRGGBB), PotionContentsComponent 使用纯 RGB int
        int rgb = (sc.r << 16) | (sc.g << 8) | sc.b;
        Optional<Integer> color = customColor.get() ? Optional.of(rgb) : Optional.empty();
        class_1844 contents = new class_1844(
            Optional.empty(),         // 不使用原版药水类型
            color,                    // 自定义颜色
            effects,                  // 自定义效果
            Optional.empty()          // 不使用自定义药水名
        );
        stack.method_57379(class_9334.field_49651, contents);

        if (customName.get()) {
            stack.method_57379(class_9334.field_49631, parseName(nameText.get()));
        }

        if (CreativeGiveUtil.give(stack)) {
            CreativeGiveUtil.info("Given " + type + " potion x" + stack.method_7947() + " (effects: " + effects.size() + ")");
        }
    }

    /** 解析 & 或 § 颜色代码为带样式的 Text (italic=false 确保显示) */
    private net.minecraft.class_2561 parseName(String raw) {
        if (raw == null || raw.isEmpty()) return net.minecraft.class_2561.method_43470("");
        net.minecraft.class_5250 out = net.minecraft.class_2561.method_43473();
        StringBuilder buf = new StringBuilder();
        net.minecraft.class_2583 curStyle = net.minecraft.class_2583.field_24360.method_10978(false);
        for (int i = 0; i < raw.length(); i++) {
            char c = raw.charAt(i);
            if ((c == '&' || c == '§') && i + 1 < raw.length()) {
                if (buf.length() > 0) {
                    out.method_10852(net.minecraft.class_2561.method_43470(buf.toString()).method_10862(curStyle));
                    buf.setLength(0);
                }
                char code = Character.toLowerCase(raw.charAt(++i));
                net.minecraft.class_124 f = net.minecraft.class_124.method_544(code);
                if (f != null) {
                    if (f == net.minecraft.class_124.field_1067) curStyle = curStyle.method_10982(!curStyle.method_10984());
                    else if (f == net.minecraft.class_124.field_1056) curStyle = curStyle.method_10978(!curStyle.method_10966());
                    else if (f == net.minecraft.class_124.field_1073) curStyle = curStyle.method_30938(!curStyle.method_10965());
                    else if (f == net.minecraft.class_124.field_1055) curStyle = curStyle.method_36140(!curStyle.method_10986());
                    else if (f == net.minecraft.class_124.field_1051) curStyle = curStyle.method_36141(!curStyle.method_10987());
                    else if (f.method_543()) curStyle = curStyle.method_27703(net.minecraft.class_5251.method_27718(f));
                }
            } else {
                buf.append(c);
            }
        }
        if (buf.length() > 0) {
            out.method_10852(net.minecraft.class_2561.method_43470(buf.toString()).method_10862(curStyle));
        }
        return out;
    }

    @SuppressWarnings("unchecked")
    private class_2378<class_1291> statusEffectRegistry() {
        return (class_2378<class_1291>) (class_2378<?>) mc.field_1687.method_30349()
            .method_46759(class_7924.field_41208).orElseThrow();
    }
}
