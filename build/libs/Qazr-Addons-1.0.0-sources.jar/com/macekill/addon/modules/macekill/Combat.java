package com.macekill.addon.modules.macekill;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_1268;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_2397;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public final class Combat {
    private Combat() {}

    public static boolean executeAttack(class_310 mc, Config config,
                                        class_1309 target, class_243 targetPos) {
        if (target == null || mc.method_1562() == null) {
            return true;
        }

        List<String> rawHeights;
        boolean armorDestroyed;
        if (config.enableArmorDestroy() && needsArmorDestroy(target, config.ignoreArmorValue())) {
            rawHeights = config.destroyHeights();
            armorDestroyed = false;
        } else {
            rawHeights = config.killHeights();
            armorDestroyed = true;
        }

        List<Double> heights = parseHeights(rawHeights);
        if (heights.isEmpty()) {
            heights.add(20.0);
        }

        int oldSlot = Inventory.switchToMace(mc);
        if (oldSlot == -1) {
            return armorDestroyed;
        }

        try {
            class_243 basePos = new class_243(mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321());

            for (double h : heights) {
                class_2338 vclipHole = findVclipHole(mc,
                    mc.field_1724.method_23317(), mc.field_1724.method_23318(), mc.field_1724.method_23321(), h);
                class_243 vclipPos = class_243.method_24955(vclipHole);

                Movement.doTpTo(mc, vclipPos, config.moveDistance(), config.syncClientPos());
                Movement.sendMovePacket(mc, targetPos.field_1352, targetPos.field_1351 + 0.5, targetPos.field_1350);
                Movement.sendMovePacket(mc, basePos.field_1352, basePos.field_1351, basePos.field_1350);

                if (config.swingHand()) {
                    mc.field_1724.method_6104(class_1268.field_5808);
                }
                Movement.attackEntity(mc, target);
            }
        } finally {
            if (config.autoTotem()) {
                int totemSlot = Inventory.findTotemSlot(mc);
                if (totemSlot != -1) {
                    Inventory.setSelectedSlot(mc.field_1724.method_31548(), totemSlot);
                    Movement.sendSlotPacket(mc, totemSlot);
                } else {
                    Inventory.switchBack(mc, oldSlot);
                }
            } else {
                Inventory.switchBack(mc, oldSlot);
            }
        }
        return armorDestroyed;
    }

    public static class_2338 findVclipHole(class_310 mc,
                                         double x, double y, double z, double vclip) {
        class_2338 base = class_2338.method_49637(x, y, z);
        if (vclip <= 0.0) {
            return base;
        }

        int bx = base.method_10263();
        int by = base.method_10264();
        int bz = base.method_10260();
        int top = by + (int) vclip;
        top = Math.min(top, 319);

        // Scan UP from the player. The first non-safe block (a solid roof) is the ceiling.
        // We must never teleport through it into the disconnected sky above, or the fall back
        // down through the roof gets rejected by the server and the player is stranded in the sky.
        class_2338.class_2339 mutable = new class_2338.class_2339();
        for (int cy = by + 1; cy <= top; cy++) {
            mutable.method_10103(bx, cy, bz);
            if (!vclipSafe(mc, mutable)) {
                // Ceiling hit: highest connected safe air is just below it (need a 2-air column).
                if (cy - 1 <= by) return base;
                mutable.method_10103(bx, cy - 1, bz);
                if (!vclipSafe(mc, mutable)) return base;
                return new class_2338(bx, cy - 1, bz);
            }
        }
        return new class_2338(bx, top, bz);
    }

    // A vclip destination must be an air block (or leaves: we can teleport straight
    // through foliage to reach clear sky above a tree canopy), with no fluid/cobweb.
    private static boolean vclipSafe(class_310 mc, class_2338 pos) {
        if (mc.field_1687 == null) return false;
        class_2680 state = mc.field_1687.method_8320(pos);
        if (state.method_26215() && state.method_26227().method_15769() && !state.method_27852(class_2246.field_10343)) {
            return true;
        }
        return state.method_26204() instanceof class_2397;
    }

    public static boolean needsArmorDestroy(class_1309 entity, int ignoreArmorValue) {
        if (!(entity instanceof class_1657 player)) {
            return false;
        }
        int count = 0;
        for (int i = 36; i <= 39; i++) {
            if (player.method_31548().method_5438(i).method_7960()) continue;
            count++;
        }
        return count > ignoreArmorValue;
    }

    public static List<Double> parseHeights(List<String> raw) {
        List<Double> list = new ArrayList<>();
        for (String s : raw) {
            try {
                double v = Double.parseDouble(s.trim());
                if (v > 0.0) {
                    list.add(v);
                }
            } catch (NumberFormatException ignored) {
            }
        }
        return list;
    }

    // Available vertical headroom (in blocks) directly above the target before a solid
    // roof is hit. In a cave this is small; in open sky it is large.
    public static int getVclipClearance(class_310 mc, class_1309 target) {
        class_2338 hole = findVclipHole(mc, target.method_23317(), target.method_23318(), target.method_23321(), 319);
        return hole.method_10264() - (int) target.method_23318();
    }

    // Builds the totem-bypass height list: (totemCount + 1) hits at STRICTLY INCREASING
    // heights, all within the available headroom above the target. Each successive mace
    // hit deals strictly more damage, which bypasses the server's hurtResistantTime
    // invulnerability check (amount <= lastDamage is ignored), popping every held totem.
    //
    // Crucially the heights are spread across the REAL clearance (not a fixed 170), so
    // under a roof / in a cave the hits stay distinct instead of all collapsing onto the
    // ceiling height (which would make them deal identical damage and only pop one totem).
    public static final int MAX_TOTEM_HITS = 198;
    public static List<String> totemBypassHeights(int totemCount, int maxHeight) {
        List<String> all = new ArrayList<>();
        int avail = Math.max(0, maxHeight);
        int minLethal = 5; // ~22 mace damage - lethal for a 20 HP target
        if (avail < minLethal) return all; // no headroom for even one lethal hit

        int kills = totemCount + 1;
        int span = avail - minLethal;
        int maxKills = span + 1;        // distinct integer heights available in [minLethal, avail]
        kills = Math.min(kills, maxKills);

        if (kills < 1) return all;
        int denom = Math.max(1, kills - 1);
        for (int i = 0; i < kills; i++) {
            int off = minLethal + (int) Math.round((double) i * span / denom);
            if (off > avail) off = avail;
            if (off < minLethal) off = minLethal;
            all.add(String.valueOf(off));
        }
        return all;
    }

    // Drives the totem bypass across multiple ticks. Each tick we hand out a small
    // slice of the (strictly increasing) height list; the server recomputes the mace
    // fall distance once per tick, so spacing the hits out lets every totem pop.
    public static final class BypassRunner {
        private final List<Double> heights;
        private int idx;

        public BypassRunner(List<Double> heights) {
            this.heights = heights;
            this.idx = 0;
        }

        public boolean hasMore() {
            return idx < heights.size();
        }

        public int remaining() {
            return heights.size() - idx;
        }

        public List<Double> next(int count) {
            List<Double> out = new ArrayList<>();
            while (idx < heights.size() && out.size() < count) {
                out.add(heights.get(idx++));
            }
            return out;
        }
    }
}
