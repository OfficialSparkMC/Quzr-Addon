package com.macekill.addon.modules.macekill;

import net.minecraft.class_1309;
import net.minecraft.class_1429;
import net.minecraft.class_1588;
import net.minecraft.class_1657;

public record TargetFilter(
    boolean players,
    boolean hostiles,
    boolean animals,
    boolean others
) {
    public boolean accepts(class_1309 entity) {
        if (entity instanceof class_1657) return players;
        if (entity instanceof class_1588) return hostiles;
        if (entity instanceof class_1429) return animals;
        return others;
    }
}
