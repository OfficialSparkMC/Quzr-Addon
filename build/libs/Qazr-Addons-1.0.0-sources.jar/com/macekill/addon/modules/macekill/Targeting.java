package com.macekill.addon.modules.macekill;

import meteordevelopment.meteorclient.systems.friends.Friends;
import net.minecraft.class_1297;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_2246;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_310;

public final class Targeting {
    private Targeting() {}

    public static class_1309 findBestTarget(class_310 mc, double range,
                                              TargetFilter filter,
                                              SortPriority priority) {
        if (mc.field_1687 == null || mc.field_1724 == null) {
            return null;
        }
        class_1309 best = null;
        double bestScore = Double.MAX_VALUE;
        double rangeSq = range * range;

        class_243 lookDir = (priority == SortPriority.ANGLE)
            ? mc.field_1724.method_5828(1.0f) : null;
        class_243 eyePos  = (priority == SortPriority.ANGLE)
            ? mc.field_1724.method_33571() : null;

        for (class_1297 e : mc.field_1687.method_18112()) {
            if (!(e instanceof class_1309 living)) continue;
            if (living == mc.field_1724 || !living.method_5805()) continue;

            double distSq = mc.field_1724.method_5858(living);
            if (distSq >= rangeSq) continue;

            if (!filter.accepts(living)) continue;
            if (living instanceof class_1657 player) {
                if (player.method_68878() || player.method_7325()
                        || !Friends.get().shouldAttack(player)) continue;
            }

            double score = scoreTarget(living, priority, distSq, lookDir, eyePos);
            if (score < bestScore) {
                bestScore = score;
                best = living;
            }
        }
        return best;
    }

    private static double scoreTarget(class_1309 entity, SortPriority priority,
                                      double distSq, class_243 lookDir, class_243 eyePos) {
        return switch (priority) {
            case DISTANCE -> distSq;

            case ANGLE -> {
                class_243 targetEye = entity.method_33571();
                double dx = targetEye.field_1352 - eyePos.field_1352;
                double dy = targetEye.field_1351 - eyePos.field_1351;
                double dz = targetEye.field_1350 - eyePos.field_1350;
                double lenSq = dx * dx + dy * dy + dz * dz;
                if (lenSq < 1.0E-8) yield -1.0;
                double invLen = 1.0 / Math.sqrt(lenSq);
                double cos = (lookDir.field_1352 * dx + lookDir.field_1351 * dy + lookDir.field_1350 * dz) * invLen;
                yield -cos;
            }

            case HEALTH -> entity.method_6032();
        };
    }

    public static class_243 predictPosition(class_310 mc, class_1309 entity,
                                        boolean predict, int predictTicks) {
        if (!predict) {
            return new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
        }
        class_243 pos = new class_243(entity.method_23317(), entity.method_23318(), entity.method_23321());
        class_243 vel = entity.method_18798();
        if (vel.field_1352 * vel.field_1352 + vel.field_1351 * vel.field_1351 + vel.field_1350 * vel.field_1350 < 1.0E-4) {
            return pos;
        }
        for (int i = 0; i < predictTicks; i++) {
            class_2338 next = class_2338.method_49637(pos.field_1352 + vel.field_1352, pos.field_1351, pos.field_1350 + vel.field_1350);
            if (!isSafeBlock(mc, next)) {
                vel = new class_243(0.0, vel.field_1351, 0.0);
            }
            pos = pos.method_1031(vel.field_1352, 0.0, vel.field_1350);
        }
        return pos;
    }

    public static boolean isSafeBlock(class_310 mc, class_2338 pos) {
        class_2680 state = mc.field_1687.method_8320(pos);
        return state.method_26215()
            && state.method_26227().method_15769()
            && !state.method_27852(class_2246.field_10343);
    }
}
