package com.macekill.addon.modules.macekill;

import java.lang.reflect.Field;
import net.minecraft.class_1661;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class Inventory {
    private static Field selectedSlotField;

    private Inventory() {}

    public static int switchToMace(class_310 mc) {
        if (mc.field_1724 == null) return -1;
        class_1661 inv = mc.field_1724.method_31548();
        for (int i = 0; i < 9; i++) {
            if (inv.method_5438(i).method_7909() != class_1802.field_49814) continue;
            int cur = getSelectedSlot(inv);
            if (i != cur) {
                setSelectedSlot(inv, i);
                Movement.sendSlotPacket(mc, i);
            }
            return cur;
        }
        return -1;
    }

    public static void switchBack(class_310 mc, int slot) {
        if (mc.field_1724 == null) return;
        class_1661 inv = mc.field_1724.method_31548();
        setSelectedSlot(inv, slot);
        Movement.sendSlotPacket(mc, slot);
    }

    public static int findTotemSlot(class_310 mc) {
        if (mc.field_1724 == null) return -1;
        class_1661 inv = mc.field_1724.method_31548();
        for (int i = 0; i < 9; i++) {
            if (inv.method_5438(i).method_7909() != class_1802.field_8288) continue;
            return i;
        }
        return -1;
    }

    public static void ensureTotem(class_310 mc) {
        if (mc.field_1724 == null || mc.method_1562() == null) return;
        class_1661 inv = mc.field_1724.method_31548();
        int cur = getSelectedSlot(inv);
        if (inv.method_5438(cur).method_7909() == class_1802.field_8288) return;
        int t = findTotemSlot(mc);
        if (t != -1) {
            setSelectedSlot(inv, t);
            Movement.sendSlotPacket(mc, t);
        }
    }

    public static int getSelectedSlot(class_310 mc) {
        if (mc.field_1724 == null) return 0;
        return getSelectedSlot(mc.field_1724.method_31548());
    }

    public static int getSelectedSlot(class_1661 inv) {
        try {
            ensureField();
            return selectedSlotField.getInt(inv);
        } catch (Exception e) {
            return 0;
        }
    }

    public static void setSelectedSlot(class_1661 inv, int slot) {
        try {
            ensureField();
            selectedSlotField.setInt(inv, slot);
        } catch (Exception ignored) {
        }
    }

    private static void ensureField() throws NoSuchFieldException {
        if (selectedSlotField == null) {
            selectedSlotField = class_1661.class.getDeclaredField("selectedSlot");
            selectedSlotField.setAccessible(true);
        }
    }
}
