package com.macekill.addon.modules.macekill;

import java.lang.reflect.Field;
import meteordevelopment.meteorclient.utils.player.FindItemResult;
import meteordevelopment.meteorclient.utils.player.InvUtils;
import net.minecraft.class_1661;
import net.minecraft.class_1802;
import net.minecraft.class_310;

public final class Inventory {
    private static Field selectedSlotField;
    // When the mace was moved out of the main inventory into the hotbar, this is its
    // original slot so we can move it back after the attack. -1 means no swap happened.
    private static int lastMaceSwapSlot = -1;

    private Inventory() {}

    public static int switchToMace(class_310 mc) {
        if (mc.field_1724 == null) return -1;
        class_1661 inv = mc.field_1724.method_31548();
        int cur = getSelectedSlot(inv);
        lastMaceSwapSlot = -1;

        if (inv.method_5438(cur).method_7909() == class_1802.field_49814) return cur;

        // Mace already in the hotbar -> just select it.
        for (int i = 0; i < 9; i++) {
            if (inv.method_5438(i).method_7909() != class_1802.field_49814) continue;
            if (i != cur) {
                setSelectedSlot(inv, i);
                Movement.sendSlotPacket(mc, i);
            }
            return cur;
        }

        // Mace somewhere else in the inventory -> move it into the selected hotbar slot.
        FindItemResult mace = InvUtils.find(class_1802.field_49814);
        if (mace.found()) {
            int src = mace.slot();
            InvUtils.move().from(src).to(cur);
            lastMaceSwapSlot = src;
        }
        return cur;
    }

    public static void switchBack(class_310 mc, int slot) {
        if (mc.field_1724 == null) return;
        class_1661 inv = mc.field_1724.method_31548();
        if (lastMaceSwapSlot >= 0) {
            // Move the mace back to where it came from (swaps the original item back).
            InvUtils.move().from(slot).to(lastMaceSwapSlot);
            lastMaceSwapSlot = -1;
            return;
        }
        setSelectedSlot(inv, slot);
        Movement.sendSlotPacket(mc, slot);
    }

    public static int findTotemSlot(class_310 mc) {
        if (mc.field_1724 == null) return -1;
        class_1661 inv = mc.field_1724.method_31548();
        for (int i = 0; i < 9; i++) {
            if (inv.method_5438(i).method_7909() != class_1802.field_8288) continue;
            return i;
        }
        return -1;
    }

    public static void ensureTotem(class_310 mc) {
        if (mc.field_1724 == null || mc.method_1562() == null) return;
        class_1661 inv = mc.field_1724.method_31548();
        int cur = getSelectedSlot(inv);
        if (inv.method_5438(cur).method_7909() == class_1802.field_8288) return;
        int t = findTotemSlot(mc);
        if (t != -1) {
            setSelectedSlot(inv, t);
            Movement.sendSlotPacket(mc, t);
        }
    }

    public static int getSelectedSlot(class_310 mc) {
        if (mc.field_1724 == null) return 0;
        return getSelectedSlot(mc.field_1724.method_31548());
    }

    public static int getSelectedSlot(class_1661 inv) {
        try {
            ensureField();
            return selectedSlotField.getInt(inv);
        } catch (Exception e) {
            return 0;
        }
    }

    public static void setSelectedSlot(class_1661 inv, int slot) {
        try {
            ensureField();
            selectedSlotField.setInt(inv, slot);
        } catch (Exception ignored) {
        }
    }

    private static void ensureField() throws NoSuchFieldException {
        if (selectedSlotField == null) {
            selectedSlotField = class_1661.class.getDeclaredField("selectedSlot");
            selectedSlotField.setAccessible(true);
        }
    }
}
