package com.macekill.addon.utils;

import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2873;
import net.minecraft.class_310;

/**
 * 创造模式物品工具 (照搬 Wurst InventoryUtils.setCreativeStack 逻辑)
 * 解决"幽灵物品"问题: 通过 CreativeInventoryActionC2SPacket 通知服务端
 */
public class CreativeGiveUtil {
    private static final class_310 mc = class_310.method_1551();

    /**
     * 把物品放进玩家背包
     * 1. 找第一个空槽
     * 2. 本地 inventory.setStack(slot, stack)
     * 3. 发送 CreativeInventoryActionC2SPacket(networkSlot, stack) 给服务端
     *
     * @return true 成功, false 背包已满
     */
    public static boolean give(class_1799 stack) {
        if (mc.field_1724 == null || mc.method_1562() == null) return false;
        int slot = mc.field_1724.method_31548().method_7376();
        if (slot < 0) {
            if (mc.field_1724 != null) {
                mc.field_1724.method_7353(class_2561.method_30163("§c[Qazr] Inventory full, cannot give item"), false);
            }
            return false;
        }
        mc.field_1724.method_31548().method_5447(slot, stack);
        int networkSlot = slot < 9 ? slot + 36 : slot;
        mc.method_1562().method_52787(new class_2873(networkSlot, stack));
        return true;
    }

    /** 警告消息 (只在内容变化时显示一次) */
    private static String lastError = "";
    public static void warn(String msg) {
        if (mc.field_1724 != null && !msg.equals(lastError)) {
            lastError = msg;
            mc.field_1724.method_7353(class_2561.method_30163("§c[Qazr] " + msg), false);
        }
    }

    public static void info(String msg) {
        if (mc.field_1724 != null)
            mc.field_1724.method_7353(class_2561.method_30163("§a[Qazr] " + msg), true);
    }

    public static void resetError() { lastError = ""; }
}
